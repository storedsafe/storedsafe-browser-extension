/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/scripts/background.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/axios/index.js":
/*!*************************************!*\
  !*** ./node_modules/axios/index.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./lib/axios */ "./node_modules/axios/lib/axios.js");

/***/ }),

/***/ "./node_modules/axios/lib/adapters/xhr.js":
/*!************************************************!*\
  !*** ./node_modules/axios/lib/adapters/xhr.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var settle = __webpack_require__(/*! ./../core/settle */ "./node_modules/axios/lib/core/settle.js");
var buildURL = __webpack_require__(/*! ./../helpers/buildURL */ "./node_modules/axios/lib/helpers/buildURL.js");
var buildFullPath = __webpack_require__(/*! ../core/buildFullPath */ "./node_modules/axios/lib/core/buildFullPath.js");
var parseHeaders = __webpack_require__(/*! ./../helpers/parseHeaders */ "./node_modules/axios/lib/helpers/parseHeaders.js");
var isURLSameOrigin = __webpack_require__(/*! ./../helpers/isURLSameOrigin */ "./node_modules/axios/lib/helpers/isURLSameOrigin.js");
var createError = __webpack_require__(/*! ../core/createError */ "./node_modules/axios/lib/core/createError.js");

module.exports = function xhrAdapter(config) {
  return new Promise(function dispatchXhrRequest(resolve, reject) {
    var requestData = config.data;
    var requestHeaders = config.headers;

    if (utils.isFormData(requestData)) {
      delete requestHeaders['Content-Type']; // Let the browser set it
    }

    var request = new XMLHttpRequest();

    // HTTP basic authentication
    if (config.auth) {
      var username = config.auth.username || '';
      var password = config.auth.password || '';
      requestHeaders.Authorization = 'Basic ' + btoa(username + ':' + password);
    }

    var fullPath = buildFullPath(config.baseURL, config.url);
    request.open(config.method.toUpperCase(), buildURL(fullPath, config.params, config.paramsSerializer), true);

    // Set the request timeout in MS
    request.timeout = config.timeout;

    // Listen for ready state
    request.onreadystatechange = function handleLoad() {
      if (!request || request.readyState !== 4) {
        return;
      }

      // The request errored out and we didn't get a response, this will be
      // handled by onerror instead
      // With one exception: request that using file: protocol, most browsers
      // will return status as 0 even though it's a successful request
      if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf('file:') === 0)) {
        return;
      }

      // Prepare the response
      var responseHeaders = 'getAllResponseHeaders' in request ? parseHeaders(request.getAllResponseHeaders()) : null;
      var responseData = !config.responseType || config.responseType === 'text' ? request.responseText : request.response;
      var response = {
        data: responseData,
        status: request.status,
        statusText: request.statusText,
        headers: responseHeaders,
        config: config,
        request: request
      };

      settle(resolve, reject, response);

      // Clean up request
      request = null;
    };

    // Handle browser request cancellation (as opposed to a manual cancellation)
    request.onabort = function handleAbort() {
      if (!request) {
        return;
      }

      reject(createError('Request aborted', config, 'ECONNABORTED', request));

      // Clean up request
      request = null;
    };

    // Handle low level network errors
    request.onerror = function handleError() {
      // Real errors are hidden from us by the browser
      // onerror should only fire if it's a network error
      reject(createError('Network Error', config, null, request));

      // Clean up request
      request = null;
    };

    // Handle timeout
    request.ontimeout = function handleTimeout() {
      var timeoutErrorMessage = 'timeout of ' + config.timeout + 'ms exceeded';
      if (config.timeoutErrorMessage) {
        timeoutErrorMessage = config.timeoutErrorMessage;
      }
      reject(createError(timeoutErrorMessage, config, 'ECONNABORTED',
        request));

      // Clean up request
      request = null;
    };

    // Add xsrf header
    // This is only done if running in a standard browser environment.
    // Specifically not if we're in a web worker, or react-native.
    if (utils.isStandardBrowserEnv()) {
      var cookies = __webpack_require__(/*! ./../helpers/cookies */ "./node_modules/axios/lib/helpers/cookies.js");

      // Add xsrf header
      var xsrfValue = (config.withCredentials || isURLSameOrigin(fullPath)) && config.xsrfCookieName ?
        cookies.read(config.xsrfCookieName) :
        undefined;

      if (xsrfValue) {
        requestHeaders[config.xsrfHeaderName] = xsrfValue;
      }
    }

    // Add headers to the request
    if ('setRequestHeader' in request) {
      utils.forEach(requestHeaders, function setRequestHeader(val, key) {
        if (typeof requestData === 'undefined' && key.toLowerCase() === 'content-type') {
          // Remove Content-Type if data is undefined
          delete requestHeaders[key];
        } else {
          // Otherwise add header to the request
          request.setRequestHeader(key, val);
        }
      });
    }

    // Add withCredentials to request if needed
    if (!utils.isUndefined(config.withCredentials)) {
      request.withCredentials = !!config.withCredentials;
    }

    // Add responseType to request if needed
    if (config.responseType) {
      try {
        request.responseType = config.responseType;
      } catch (e) {
        // Expected DOMException thrown by browsers not compatible XMLHttpRequest Level 2.
        // But, this can be suppressed for 'json' type as it can be parsed by default 'transformResponse' function.
        if (config.responseType !== 'json') {
          throw e;
        }
      }
    }

    // Handle progress if needed
    if (typeof config.onDownloadProgress === 'function') {
      request.addEventListener('progress', config.onDownloadProgress);
    }

    // Not all browsers support upload events
    if (typeof config.onUploadProgress === 'function' && request.upload) {
      request.upload.addEventListener('progress', config.onUploadProgress);
    }

    if (config.cancelToken) {
      // Handle cancellation
      config.cancelToken.promise.then(function onCanceled(cancel) {
        if (!request) {
          return;
        }

        request.abort();
        reject(cancel);
        // Clean up request
        request = null;
      });
    }

    if (requestData === undefined) {
      requestData = null;
    }

    // Send the request
    request.send(requestData);
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/axios.js":
/*!*****************************************!*\
  !*** ./node_modules/axios/lib/axios.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./utils */ "./node_modules/axios/lib/utils.js");
var bind = __webpack_require__(/*! ./helpers/bind */ "./node_modules/axios/lib/helpers/bind.js");
var Axios = __webpack_require__(/*! ./core/Axios */ "./node_modules/axios/lib/core/Axios.js");
var mergeConfig = __webpack_require__(/*! ./core/mergeConfig */ "./node_modules/axios/lib/core/mergeConfig.js");
var defaults = __webpack_require__(/*! ./defaults */ "./node_modules/axios/lib/defaults.js");

/**
 * Create an instance of Axios
 *
 * @param {Object} defaultConfig The default config for the instance
 * @return {Axios} A new instance of Axios
 */
function createInstance(defaultConfig) {
  var context = new Axios(defaultConfig);
  var instance = bind(Axios.prototype.request, context);

  // Copy axios.prototype to instance
  utils.extend(instance, Axios.prototype, context);

  // Copy context to instance
  utils.extend(instance, context);

  return instance;
}

// Create the default instance to be exported
var axios = createInstance(defaults);

// Expose Axios class to allow class inheritance
axios.Axios = Axios;

// Factory for creating new instances
axios.create = function create(instanceConfig) {
  return createInstance(mergeConfig(axios.defaults, instanceConfig));
};

// Expose Cancel & CancelToken
axios.Cancel = __webpack_require__(/*! ./cancel/Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");
axios.CancelToken = __webpack_require__(/*! ./cancel/CancelToken */ "./node_modules/axios/lib/cancel/CancelToken.js");
axios.isCancel = __webpack_require__(/*! ./cancel/isCancel */ "./node_modules/axios/lib/cancel/isCancel.js");

// Expose all/spread
axios.all = function all(promises) {
  return Promise.all(promises);
};
axios.spread = __webpack_require__(/*! ./helpers/spread */ "./node_modules/axios/lib/helpers/spread.js");

module.exports = axios;

// Allow use of default import syntax in TypeScript
module.exports.default = axios;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/Cancel.js":
/*!*************************************************!*\
  !*** ./node_modules/axios/lib/cancel/Cancel.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * A `Cancel` is an object that is thrown when an operation is canceled.
 *
 * @class
 * @param {string=} message The message.
 */
function Cancel(message) {
  this.message = message;
}

Cancel.prototype.toString = function toString() {
  return 'Cancel' + (this.message ? ': ' + this.message : '');
};

Cancel.prototype.__CANCEL__ = true;

module.exports = Cancel;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/CancelToken.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/cancel/CancelToken.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var Cancel = __webpack_require__(/*! ./Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");

/**
 * A `CancelToken` is an object that can be used to request cancellation of an operation.
 *
 * @class
 * @param {Function} executor The executor function.
 */
function CancelToken(executor) {
  if (typeof executor !== 'function') {
    throw new TypeError('executor must be a function.');
  }

  var resolvePromise;
  this.promise = new Promise(function promiseExecutor(resolve) {
    resolvePromise = resolve;
  });

  var token = this;
  executor(function cancel(message) {
    if (token.reason) {
      // Cancellation has already been requested
      return;
    }

    token.reason = new Cancel(message);
    resolvePromise(token.reason);
  });
}

/**
 * Throws a `Cancel` if cancellation has been requested.
 */
CancelToken.prototype.throwIfRequested = function throwIfRequested() {
  if (this.reason) {
    throw this.reason;
  }
};

/**
 * Returns an object that contains a new `CancelToken` and a function that, when called,
 * cancels the `CancelToken`.
 */
CancelToken.source = function source() {
  var cancel;
  var token = new CancelToken(function executor(c) {
    cancel = c;
  });
  return {
    token: token,
    cancel: cancel
  };
};

module.exports = CancelToken;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/isCancel.js":
/*!***************************************************!*\
  !*** ./node_modules/axios/lib/cancel/isCancel.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function isCancel(value) {
  return !!(value && value.__CANCEL__);
};


/***/ }),

/***/ "./node_modules/axios/lib/core/Axios.js":
/*!**********************************************!*\
  !*** ./node_modules/axios/lib/core/Axios.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var buildURL = __webpack_require__(/*! ../helpers/buildURL */ "./node_modules/axios/lib/helpers/buildURL.js");
var InterceptorManager = __webpack_require__(/*! ./InterceptorManager */ "./node_modules/axios/lib/core/InterceptorManager.js");
var dispatchRequest = __webpack_require__(/*! ./dispatchRequest */ "./node_modules/axios/lib/core/dispatchRequest.js");
var mergeConfig = __webpack_require__(/*! ./mergeConfig */ "./node_modules/axios/lib/core/mergeConfig.js");

/**
 * Create a new instance of Axios
 *
 * @param {Object} instanceConfig The default config for the instance
 */
function Axios(instanceConfig) {
  this.defaults = instanceConfig;
  this.interceptors = {
    request: new InterceptorManager(),
    response: new InterceptorManager()
  };
}

/**
 * Dispatch a request
 *
 * @param {Object} config The config specific for this request (merged with this.defaults)
 */
Axios.prototype.request = function request(config) {
  /*eslint no-param-reassign:0*/
  // Allow for axios('example/url'[, config]) a la fetch API
  if (typeof config === 'string') {
    config = arguments[1] || {};
    config.url = arguments[0];
  } else {
    config = config || {};
  }

  config = mergeConfig(this.defaults, config);

  // Set config.method
  if (config.method) {
    config.method = config.method.toLowerCase();
  } else if (this.defaults.method) {
    config.method = this.defaults.method.toLowerCase();
  } else {
    config.method = 'get';
  }

  // Hook up interceptors middleware
  var chain = [dispatchRequest, undefined];
  var promise = Promise.resolve(config);

  this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
    chain.unshift(interceptor.fulfilled, interceptor.rejected);
  });

  this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
    chain.push(interceptor.fulfilled, interceptor.rejected);
  });

  while (chain.length) {
    promise = promise.then(chain.shift(), chain.shift());
  }

  return promise;
};

Axios.prototype.getUri = function getUri(config) {
  config = mergeConfig(this.defaults, config);
  return buildURL(config.url, config.params, config.paramsSerializer).replace(/^\?/, '');
};

// Provide aliases for supported request methods
utils.forEach(['delete', 'get', 'head', 'options'], function forEachMethodNoData(method) {
  /*eslint func-names:0*/
  Axios.prototype[method] = function(url, config) {
    return this.request(utils.merge(config || {}, {
      method: method,
      url: url
    }));
  };
});

utils.forEach(['post', 'put', 'patch'], function forEachMethodWithData(method) {
  /*eslint func-names:0*/
  Axios.prototype[method] = function(url, data, config) {
    return this.request(utils.merge(config || {}, {
      method: method,
      url: url,
      data: data
    }));
  };
});

module.exports = Axios;


/***/ }),

/***/ "./node_modules/axios/lib/core/InterceptorManager.js":
/*!***********************************************************!*\
  !*** ./node_modules/axios/lib/core/InterceptorManager.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

function InterceptorManager() {
  this.handlers = [];
}

/**
 * Add a new interceptor to the stack
 *
 * @param {Function} fulfilled The function to handle `then` for a `Promise`
 * @param {Function} rejected The function to handle `reject` for a `Promise`
 *
 * @return {Number} An ID used to remove interceptor later
 */
InterceptorManager.prototype.use = function use(fulfilled, rejected) {
  this.handlers.push({
    fulfilled: fulfilled,
    rejected: rejected
  });
  return this.handlers.length - 1;
};

/**
 * Remove an interceptor from the stack
 *
 * @param {Number} id The ID that was returned by `use`
 */
InterceptorManager.prototype.eject = function eject(id) {
  if (this.handlers[id]) {
    this.handlers[id] = null;
  }
};

/**
 * Iterate over all the registered interceptors
 *
 * This method is particularly useful for skipping over any
 * interceptors that may have become `null` calling `eject`.
 *
 * @param {Function} fn The function to call for each interceptor
 */
InterceptorManager.prototype.forEach = function forEach(fn) {
  utils.forEach(this.handlers, function forEachHandler(h) {
    if (h !== null) {
      fn(h);
    }
  });
};

module.exports = InterceptorManager;


/***/ }),

/***/ "./node_modules/axios/lib/core/buildFullPath.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/core/buildFullPath.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var isAbsoluteURL = __webpack_require__(/*! ../helpers/isAbsoluteURL */ "./node_modules/axios/lib/helpers/isAbsoluteURL.js");
var combineURLs = __webpack_require__(/*! ../helpers/combineURLs */ "./node_modules/axios/lib/helpers/combineURLs.js");

/**
 * Creates a new URL by combining the baseURL with the requestedURL,
 * only when the requestedURL is not already an absolute URL.
 * If the requestURL is absolute, this function returns the requestedURL untouched.
 *
 * @param {string} baseURL The base URL
 * @param {string} requestedURL Absolute or relative URL to combine
 * @returns {string} The combined full path
 */
module.exports = function buildFullPath(baseURL, requestedURL) {
  if (baseURL && !isAbsoluteURL(requestedURL)) {
    return combineURLs(baseURL, requestedURL);
  }
  return requestedURL;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/createError.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/core/createError.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var enhanceError = __webpack_require__(/*! ./enhanceError */ "./node_modules/axios/lib/core/enhanceError.js");

/**
 * Create an Error with the specified message, config, error code, request and response.
 *
 * @param {string} message The error message.
 * @param {Object} config The config.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 * @returns {Error} The created error.
 */
module.exports = function createError(message, config, code, request, response) {
  var error = new Error(message);
  return enhanceError(error, config, code, request, response);
};


/***/ }),

/***/ "./node_modules/axios/lib/core/dispatchRequest.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/core/dispatchRequest.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var transformData = __webpack_require__(/*! ./transformData */ "./node_modules/axios/lib/core/transformData.js");
var isCancel = __webpack_require__(/*! ../cancel/isCancel */ "./node_modules/axios/lib/cancel/isCancel.js");
var defaults = __webpack_require__(/*! ../defaults */ "./node_modules/axios/lib/defaults.js");

/**
 * Throws a `Cancel` if cancellation has been requested.
 */
function throwIfCancellationRequested(config) {
  if (config.cancelToken) {
    config.cancelToken.throwIfRequested();
  }
}

/**
 * Dispatch a request to the server using the configured adapter.
 *
 * @param {object} config The config that is to be used for the request
 * @returns {Promise} The Promise to be fulfilled
 */
module.exports = function dispatchRequest(config) {
  throwIfCancellationRequested(config);

  // Ensure headers exist
  config.headers = config.headers || {};

  // Transform request data
  config.data = transformData(
    config.data,
    config.headers,
    config.transformRequest
  );

  // Flatten headers
  config.headers = utils.merge(
    config.headers.common || {},
    config.headers[config.method] || {},
    config.headers
  );

  utils.forEach(
    ['delete', 'get', 'head', 'post', 'put', 'patch', 'common'],
    function cleanHeaderConfig(method) {
      delete config.headers[method];
    }
  );

  var adapter = config.adapter || defaults.adapter;

  return adapter(config).then(function onAdapterResolution(response) {
    throwIfCancellationRequested(config);

    // Transform response data
    response.data = transformData(
      response.data,
      response.headers,
      config.transformResponse
    );

    return response;
  }, function onAdapterRejection(reason) {
    if (!isCancel(reason)) {
      throwIfCancellationRequested(config);

      // Transform response data
      if (reason && reason.response) {
        reason.response.data = transformData(
          reason.response.data,
          reason.response.headers,
          config.transformResponse
        );
      }
    }

    return Promise.reject(reason);
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/core/enhanceError.js":
/*!*****************************************************!*\
  !*** ./node_modules/axios/lib/core/enhanceError.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Update an Error with the specified config, error code, and response.
 *
 * @param {Error} error The error to update.
 * @param {Object} config The config.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 * @returns {Error} The error.
 */
module.exports = function enhanceError(error, config, code, request, response) {
  error.config = config;
  if (code) {
    error.code = code;
  }

  error.request = request;
  error.response = response;
  error.isAxiosError = true;

  error.toJSON = function() {
    return {
      // Standard
      message: this.message,
      name: this.name,
      // Microsoft
      description: this.description,
      number: this.number,
      // Mozilla
      fileName: this.fileName,
      lineNumber: this.lineNumber,
      columnNumber: this.columnNumber,
      stack: this.stack,
      // Axios
      config: this.config,
      code: this.code
    };
  };
  return error;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/mergeConfig.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/core/mergeConfig.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");

/**
 * Config-specific merge-function which creates a new config-object
 * by merging two configuration objects together.
 *
 * @param {Object} config1
 * @param {Object} config2
 * @returns {Object} New object resulting from merging config2 to config1
 */
module.exports = function mergeConfig(config1, config2) {
  // eslint-disable-next-line no-param-reassign
  config2 = config2 || {};
  var config = {};

  var valueFromConfig2Keys = ['url', 'method', 'params', 'data'];
  var mergeDeepPropertiesKeys = ['headers', 'auth', 'proxy'];
  var defaultToConfig2Keys = [
    'baseURL', 'url', 'transformRequest', 'transformResponse', 'paramsSerializer',
    'timeout', 'withCredentials', 'adapter', 'responseType', 'xsrfCookieName',
    'xsrfHeaderName', 'onUploadProgress', 'onDownloadProgress',
    'maxContentLength', 'validateStatus', 'maxRedirects', 'httpAgent',
    'httpsAgent', 'cancelToken', 'socketPath'
  ];

  utils.forEach(valueFromConfig2Keys, function valueFromConfig2(prop) {
    if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    }
  });

  utils.forEach(mergeDeepPropertiesKeys, function mergeDeepProperties(prop) {
    if (utils.isObject(config2[prop])) {
      config[prop] = utils.deepMerge(config1[prop], config2[prop]);
    } else if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    } else if (utils.isObject(config1[prop])) {
      config[prop] = utils.deepMerge(config1[prop]);
    } else if (typeof config1[prop] !== 'undefined') {
      config[prop] = config1[prop];
    }
  });

  utils.forEach(defaultToConfig2Keys, function defaultToConfig2(prop) {
    if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    } else if (typeof config1[prop] !== 'undefined') {
      config[prop] = config1[prop];
    }
  });

  var axiosKeys = valueFromConfig2Keys
    .concat(mergeDeepPropertiesKeys)
    .concat(defaultToConfig2Keys);

  var otherKeys = Object
    .keys(config2)
    .filter(function filterAxiosKeys(key) {
      return axiosKeys.indexOf(key) === -1;
    });

  utils.forEach(otherKeys, function otherKeysDefaultToConfig2(prop) {
    if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    } else if (typeof config1[prop] !== 'undefined') {
      config[prop] = config1[prop];
    }
  });

  return config;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/settle.js":
/*!***********************************************!*\
  !*** ./node_modules/axios/lib/core/settle.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var createError = __webpack_require__(/*! ./createError */ "./node_modules/axios/lib/core/createError.js");

/**
 * Resolve or reject a Promise based on response status.
 *
 * @param {Function} resolve A function that resolves the promise.
 * @param {Function} reject A function that rejects the promise.
 * @param {object} response The response.
 */
module.exports = function settle(resolve, reject, response) {
  var validateStatus = response.config.validateStatus;
  if (!validateStatus || validateStatus(response.status)) {
    resolve(response);
  } else {
    reject(createError(
      'Request failed with status code ' + response.status,
      response.config,
      null,
      response.request,
      response
    ));
  }
};


/***/ }),

/***/ "./node_modules/axios/lib/core/transformData.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/core/transformData.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

/**
 * Transform the data for a request or a response
 *
 * @param {Object|String} data The data to be transformed
 * @param {Array} headers The headers for the request or response
 * @param {Array|Function} fns A single function or Array of functions
 * @returns {*} The resulting transformed data
 */
module.exports = function transformData(data, headers, fns) {
  /*eslint no-param-reassign:0*/
  utils.forEach(fns, function transform(fn) {
    data = fn(data, headers);
  });

  return data;
};


/***/ }),

/***/ "./node_modules/axios/lib/defaults.js":
/*!********************************************!*\
  !*** ./node_modules/axios/lib/defaults.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

var utils = __webpack_require__(/*! ./utils */ "./node_modules/axios/lib/utils.js");
var normalizeHeaderName = __webpack_require__(/*! ./helpers/normalizeHeaderName */ "./node_modules/axios/lib/helpers/normalizeHeaderName.js");

var DEFAULT_CONTENT_TYPE = {
  'Content-Type': 'application/x-www-form-urlencoded'
};

function setContentTypeIfUnset(headers, value) {
  if (!utils.isUndefined(headers) && utils.isUndefined(headers['Content-Type'])) {
    headers['Content-Type'] = value;
  }
}

function getDefaultAdapter() {
  var adapter;
  if (typeof XMLHttpRequest !== 'undefined') {
    // For browsers use XHR adapter
    adapter = __webpack_require__(/*! ./adapters/xhr */ "./node_modules/axios/lib/adapters/xhr.js");
  } else if (typeof process !== 'undefined' && Object.prototype.toString.call(process) === '[object process]') {
    // For node use HTTP adapter
    adapter = __webpack_require__(/*! ./adapters/http */ "./node_modules/axios/lib/adapters/xhr.js");
  }
  return adapter;
}

var defaults = {
  adapter: getDefaultAdapter(),

  transformRequest: [function transformRequest(data, headers) {
    normalizeHeaderName(headers, 'Accept');
    normalizeHeaderName(headers, 'Content-Type');
    if (utils.isFormData(data) ||
      utils.isArrayBuffer(data) ||
      utils.isBuffer(data) ||
      utils.isStream(data) ||
      utils.isFile(data) ||
      utils.isBlob(data)
    ) {
      return data;
    }
    if (utils.isArrayBufferView(data)) {
      return data.buffer;
    }
    if (utils.isURLSearchParams(data)) {
      setContentTypeIfUnset(headers, 'application/x-www-form-urlencoded;charset=utf-8');
      return data.toString();
    }
    if (utils.isObject(data)) {
      setContentTypeIfUnset(headers, 'application/json;charset=utf-8');
      return JSON.stringify(data);
    }
    return data;
  }],

  transformResponse: [function transformResponse(data) {
    /*eslint no-param-reassign:0*/
    if (typeof data === 'string') {
      try {
        data = JSON.parse(data);
      } catch (e) { /* Ignore */ }
    }
    return data;
  }],

  /**
   * A timeout in milliseconds to abort a request. If set to 0 (default) a
   * timeout is not created.
   */
  timeout: 0,

  xsrfCookieName: 'XSRF-TOKEN',
  xsrfHeaderName: 'X-XSRF-TOKEN',

  maxContentLength: -1,

  validateStatus: function validateStatus(status) {
    return status >= 200 && status < 300;
  }
};

defaults.headers = {
  common: {
    'Accept': 'application/json, text/plain, */*'
  }
};

utils.forEach(['delete', 'get', 'head'], function forEachMethodNoData(method) {
  defaults.headers[method] = {};
});

utils.forEach(['post', 'put', 'patch'], function forEachMethodWithData(method) {
  defaults.headers[method] = utils.merge(DEFAULT_CONTENT_TYPE);
});

module.exports = defaults;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../process/browser.js */ "./node_modules/process/browser.js")))

/***/ }),

/***/ "./node_modules/axios/lib/helpers/bind.js":
/*!************************************************!*\
  !*** ./node_modules/axios/lib/helpers/bind.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function bind(fn, thisArg) {
  return function wrap() {
    var args = new Array(arguments.length);
    for (var i = 0; i < args.length; i++) {
      args[i] = arguments[i];
    }
    return fn.apply(thisArg, args);
  };
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/buildURL.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/helpers/buildURL.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

function encode(val) {
  return encodeURIComponent(val).
    replace(/%40/gi, '@').
    replace(/%3A/gi, ':').
    replace(/%24/g, '$').
    replace(/%2C/gi, ',').
    replace(/%20/g, '+').
    replace(/%5B/gi, '[').
    replace(/%5D/gi, ']');
}

/**
 * Build a URL by appending params to the end
 *
 * @param {string} url The base of the url (e.g., http://www.google.com)
 * @param {object} [params] The params to be appended
 * @returns {string} The formatted url
 */
module.exports = function buildURL(url, params, paramsSerializer) {
  /*eslint no-param-reassign:0*/
  if (!params) {
    return url;
  }

  var serializedParams;
  if (paramsSerializer) {
    serializedParams = paramsSerializer(params);
  } else if (utils.isURLSearchParams(params)) {
    serializedParams = params.toString();
  } else {
    var parts = [];

    utils.forEach(params, function serialize(val, key) {
      if (val === null || typeof val === 'undefined') {
        return;
      }

      if (utils.isArray(val)) {
        key = key + '[]';
      } else {
        val = [val];
      }

      utils.forEach(val, function parseValue(v) {
        if (utils.isDate(v)) {
          v = v.toISOString();
        } else if (utils.isObject(v)) {
          v = JSON.stringify(v);
        }
        parts.push(encode(key) + '=' + encode(v));
      });
    });

    serializedParams = parts.join('&');
  }

  if (serializedParams) {
    var hashmarkIndex = url.indexOf('#');
    if (hashmarkIndex !== -1) {
      url = url.slice(0, hashmarkIndex);
    }

    url += (url.indexOf('?') === -1 ? '?' : '&') + serializedParams;
  }

  return url;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/combineURLs.js":
/*!*******************************************************!*\
  !*** ./node_modules/axios/lib/helpers/combineURLs.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Creates a new URL by combining the specified URLs
 *
 * @param {string} baseURL The base URL
 * @param {string} relativeURL The relative URL
 * @returns {string} The combined URL
 */
module.exports = function combineURLs(baseURL, relativeURL) {
  return relativeURL
    ? baseURL.replace(/\/+$/, '') + '/' + relativeURL.replace(/^\/+/, '')
    : baseURL;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/cookies.js":
/*!***************************************************!*\
  !*** ./node_modules/axios/lib/helpers/cookies.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

module.exports = (
  utils.isStandardBrowserEnv() ?

  // Standard browser envs support document.cookie
    (function standardBrowserEnv() {
      return {
        write: function write(name, value, expires, path, domain, secure) {
          var cookie = [];
          cookie.push(name + '=' + encodeURIComponent(value));

          if (utils.isNumber(expires)) {
            cookie.push('expires=' + new Date(expires).toGMTString());
          }

          if (utils.isString(path)) {
            cookie.push('path=' + path);
          }

          if (utils.isString(domain)) {
            cookie.push('domain=' + domain);
          }

          if (secure === true) {
            cookie.push('secure');
          }

          document.cookie = cookie.join('; ');
        },

        read: function read(name) {
          var match = document.cookie.match(new RegExp('(^|;\\s*)(' + name + ')=([^;]*)'));
          return (match ? decodeURIComponent(match[3]) : null);
        },

        remove: function remove(name) {
          this.write(name, '', Date.now() - 86400000);
        }
      };
    })() :

  // Non standard browser env (web workers, react-native) lack needed support.
    (function nonStandardBrowserEnv() {
      return {
        write: function write() {},
        read: function read() { return null; },
        remove: function remove() {}
      };
    })()
);


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isAbsoluteURL.js":
/*!*********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isAbsoluteURL.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Determines whether the specified URL is absolute
 *
 * @param {string} url The URL to test
 * @returns {boolean} True if the specified URL is absolute, otherwise false
 */
module.exports = function isAbsoluteURL(url) {
  // A URL is considered absolute if it begins with "<scheme>://" or "//" (protocol-relative URL).
  // RFC 3986 defines scheme name as a sequence of characters beginning with a letter and followed
  // by any combination of letters, digits, plus, period, or hyphen.
  return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(url);
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isURLSameOrigin.js":
/*!***********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isURLSameOrigin.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

module.exports = (
  utils.isStandardBrowserEnv() ?

  // Standard browser envs have full support of the APIs needed to test
  // whether the request URL is of the same origin as current location.
    (function standardBrowserEnv() {
      var msie = /(msie|trident)/i.test(navigator.userAgent);
      var urlParsingNode = document.createElement('a');
      var originURL;

      /**
    * Parse a URL to discover it's components
    *
    * @param {String} url The URL to be parsed
    * @returns {Object}
    */
      function resolveURL(url) {
        var href = url;

        if (msie) {
        // IE needs attribute set twice to normalize properties
          urlParsingNode.setAttribute('href', href);
          href = urlParsingNode.href;
        }

        urlParsingNode.setAttribute('href', href);

        // urlParsingNode provides the UrlUtils interface - http://url.spec.whatwg.org/#urlutils
        return {
          href: urlParsingNode.href,
          protocol: urlParsingNode.protocol ? urlParsingNode.protocol.replace(/:$/, '') : '',
          host: urlParsingNode.host,
          search: urlParsingNode.search ? urlParsingNode.search.replace(/^\?/, '') : '',
          hash: urlParsingNode.hash ? urlParsingNode.hash.replace(/^#/, '') : '',
          hostname: urlParsingNode.hostname,
          port: urlParsingNode.port,
          pathname: (urlParsingNode.pathname.charAt(0) === '/') ?
            urlParsingNode.pathname :
            '/' + urlParsingNode.pathname
        };
      }

      originURL = resolveURL(window.location.href);

      /**
    * Determine if a URL shares the same origin as the current location
    *
    * @param {String} requestURL The URL to test
    * @returns {boolean} True if URL shares the same origin, otherwise false
    */
      return function isURLSameOrigin(requestURL) {
        var parsed = (utils.isString(requestURL)) ? resolveURL(requestURL) : requestURL;
        return (parsed.protocol === originURL.protocol &&
            parsed.host === originURL.host);
      };
    })() :

  // Non standard browser envs (web workers, react-native) lack needed support.
    (function nonStandardBrowserEnv() {
      return function isURLSameOrigin() {
        return true;
      };
    })()
);


/***/ }),

/***/ "./node_modules/axios/lib/helpers/normalizeHeaderName.js":
/*!***************************************************************!*\
  !*** ./node_modules/axios/lib/helpers/normalizeHeaderName.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");

module.exports = function normalizeHeaderName(headers, normalizedName) {
  utils.forEach(headers, function processHeader(value, name) {
    if (name !== normalizedName && name.toUpperCase() === normalizedName.toUpperCase()) {
      headers[normalizedName] = value;
      delete headers[name];
    }
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/parseHeaders.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/parseHeaders.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

// Headers whose duplicates are ignored by node
// c.f. https://nodejs.org/api/http.html#http_message_headers
var ignoreDuplicateOf = [
  'age', 'authorization', 'content-length', 'content-type', 'etag',
  'expires', 'from', 'host', 'if-modified-since', 'if-unmodified-since',
  'last-modified', 'location', 'max-forwards', 'proxy-authorization',
  'referer', 'retry-after', 'user-agent'
];

/**
 * Parse headers into an object
 *
 * ```
 * Date: Wed, 27 Aug 2014 08:58:49 GMT
 * Content-Type: application/json
 * Connection: keep-alive
 * Transfer-Encoding: chunked
 * ```
 *
 * @param {String} headers Headers needing to be parsed
 * @returns {Object} Headers parsed into an object
 */
module.exports = function parseHeaders(headers) {
  var parsed = {};
  var key;
  var val;
  var i;

  if (!headers) { return parsed; }

  utils.forEach(headers.split('\n'), function parser(line) {
    i = line.indexOf(':');
    key = utils.trim(line.substr(0, i)).toLowerCase();
    val = utils.trim(line.substr(i + 1));

    if (key) {
      if (parsed[key] && ignoreDuplicateOf.indexOf(key) >= 0) {
        return;
      }
      if (key === 'set-cookie') {
        parsed[key] = (parsed[key] ? parsed[key] : []).concat([val]);
      } else {
        parsed[key] = parsed[key] ? parsed[key] + ', ' + val : val;
      }
    }
  });

  return parsed;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/spread.js":
/*!**************************************************!*\
  !*** ./node_modules/axios/lib/helpers/spread.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Syntactic sugar for invoking a function and expanding an array for arguments.
 *
 * Common use case would be to use `Function.prototype.apply`.
 *
 *  ```js
 *  function f(x, y, z) {}
 *  var args = [1, 2, 3];
 *  f.apply(null, args);
 *  ```
 *
 * With `spread` this example can be re-written.
 *
 *  ```js
 *  spread(function(x, y, z) {})([1, 2, 3]);
 *  ```
 *
 * @param {Function} callback
 * @returns {Function}
 */
module.exports = function spread(callback) {
  return function wrap(arr) {
    return callback.apply(null, arr);
  };
};


/***/ }),

/***/ "./node_modules/axios/lib/utils.js":
/*!*****************************************!*\
  !*** ./node_modules/axios/lib/utils.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var bind = __webpack_require__(/*! ./helpers/bind */ "./node_modules/axios/lib/helpers/bind.js");

/*global toString:true*/

// utils is a library of generic helper functions non-specific to axios

var toString = Object.prototype.toString;

/**
 * Determine if a value is an Array
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Array, otherwise false
 */
function isArray(val) {
  return toString.call(val) === '[object Array]';
}

/**
 * Determine if a value is undefined
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if the value is undefined, otherwise false
 */
function isUndefined(val) {
  return typeof val === 'undefined';
}

/**
 * Determine if a value is a Buffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Buffer, otherwise false
 */
function isBuffer(val) {
  return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor)
    && typeof val.constructor.isBuffer === 'function' && val.constructor.isBuffer(val);
}

/**
 * Determine if a value is an ArrayBuffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an ArrayBuffer, otherwise false
 */
function isArrayBuffer(val) {
  return toString.call(val) === '[object ArrayBuffer]';
}

/**
 * Determine if a value is a FormData
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an FormData, otherwise false
 */
function isFormData(val) {
  return (typeof FormData !== 'undefined') && (val instanceof FormData);
}

/**
 * Determine if a value is a view on an ArrayBuffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a view on an ArrayBuffer, otherwise false
 */
function isArrayBufferView(val) {
  var result;
  if ((typeof ArrayBuffer !== 'undefined') && (ArrayBuffer.isView)) {
    result = ArrayBuffer.isView(val);
  } else {
    result = (val) && (val.buffer) && (val.buffer instanceof ArrayBuffer);
  }
  return result;
}

/**
 * Determine if a value is a String
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a String, otherwise false
 */
function isString(val) {
  return typeof val === 'string';
}

/**
 * Determine if a value is a Number
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Number, otherwise false
 */
function isNumber(val) {
  return typeof val === 'number';
}

/**
 * Determine if a value is an Object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Object, otherwise false
 */
function isObject(val) {
  return val !== null && typeof val === 'object';
}

/**
 * Determine if a value is a Date
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Date, otherwise false
 */
function isDate(val) {
  return toString.call(val) === '[object Date]';
}

/**
 * Determine if a value is a File
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a File, otherwise false
 */
function isFile(val) {
  return toString.call(val) === '[object File]';
}

/**
 * Determine if a value is a Blob
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Blob, otherwise false
 */
function isBlob(val) {
  return toString.call(val) === '[object Blob]';
}

/**
 * Determine if a value is a Function
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Function, otherwise false
 */
function isFunction(val) {
  return toString.call(val) === '[object Function]';
}

/**
 * Determine if a value is a Stream
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Stream, otherwise false
 */
function isStream(val) {
  return isObject(val) && isFunction(val.pipe);
}

/**
 * Determine if a value is a URLSearchParams object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a URLSearchParams object, otherwise false
 */
function isURLSearchParams(val) {
  return typeof URLSearchParams !== 'undefined' && val instanceof URLSearchParams;
}

/**
 * Trim excess whitespace off the beginning and end of a string
 *
 * @param {String} str The String to trim
 * @returns {String} The String freed of excess whitespace
 */
function trim(str) {
  return str.replace(/^\s*/, '').replace(/\s*$/, '');
}

/**
 * Determine if we're running in a standard browser environment
 *
 * This allows axios to run in a web worker, and react-native.
 * Both environments support XMLHttpRequest, but not fully standard globals.
 *
 * web workers:
 *  typeof window -> undefined
 *  typeof document -> undefined
 *
 * react-native:
 *  navigator.product -> 'ReactNative'
 * nativescript
 *  navigator.product -> 'NativeScript' or 'NS'
 */
function isStandardBrowserEnv() {
  if (typeof navigator !== 'undefined' && (navigator.product === 'ReactNative' ||
                                           navigator.product === 'NativeScript' ||
                                           navigator.product === 'NS')) {
    return false;
  }
  return (
    typeof window !== 'undefined' &&
    typeof document !== 'undefined'
  );
}

/**
 * Iterate over an Array or an Object invoking a function for each item.
 *
 * If `obj` is an Array callback will be called passing
 * the value, index, and complete array for each item.
 *
 * If 'obj' is an Object callback will be called passing
 * the value, key, and complete object for each property.
 *
 * @param {Object|Array} obj The object to iterate
 * @param {Function} fn The callback to invoke for each item
 */
function forEach(obj, fn) {
  // Don't bother if no value provided
  if (obj === null || typeof obj === 'undefined') {
    return;
  }

  // Force an array if not already something iterable
  if (typeof obj !== 'object') {
    /*eslint no-param-reassign:0*/
    obj = [obj];
  }

  if (isArray(obj)) {
    // Iterate over array values
    for (var i = 0, l = obj.length; i < l; i++) {
      fn.call(null, obj[i], i, obj);
    }
  } else {
    // Iterate over object keys
    for (var key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        fn.call(null, obj[key], key, obj);
      }
    }
  }
}

/**
 * Accepts varargs expecting each argument to be an object, then
 * immutably merges the properties of each object and returns result.
 *
 * When multiple objects contain the same key the later object in
 * the arguments list will take precedence.
 *
 * Example:
 *
 * ```js
 * var result = merge({foo: 123}, {foo: 456});
 * console.log(result.foo); // outputs 456
 * ```
 *
 * @param {Object} obj1 Object to merge
 * @returns {Object} Result of all merge properties
 */
function merge(/* obj1, obj2, obj3, ... */) {
  var result = {};
  function assignValue(val, key) {
    if (typeof result[key] === 'object' && typeof val === 'object') {
      result[key] = merge(result[key], val);
    } else {
      result[key] = val;
    }
  }

  for (var i = 0, l = arguments.length; i < l; i++) {
    forEach(arguments[i], assignValue);
  }
  return result;
}

/**
 * Function equal to merge with the difference being that no reference
 * to original objects is kept.
 *
 * @see merge
 * @param {Object} obj1 Object to merge
 * @returns {Object} Result of all merge properties
 */
function deepMerge(/* obj1, obj2, obj3, ... */) {
  var result = {};
  function assignValue(val, key) {
    if (typeof result[key] === 'object' && typeof val === 'object') {
      result[key] = deepMerge(result[key], val);
    } else if (typeof val === 'object') {
      result[key] = deepMerge({}, val);
    } else {
      result[key] = val;
    }
  }

  for (var i = 0, l = arguments.length; i < l; i++) {
    forEach(arguments[i], assignValue);
  }
  return result;
}

/**
 * Extends object a by mutably adding to it the properties of object b.
 *
 * @param {Object} a The object to be extended
 * @param {Object} b The object to copy properties from
 * @param {Object} thisArg The object to bind function to
 * @return {Object} The resulting value of object a
 */
function extend(a, b, thisArg) {
  forEach(b, function assignValue(val, key) {
    if (thisArg && typeof val === 'function') {
      a[key] = bind(val, thisArg);
    } else {
      a[key] = val;
    }
  });
  return a;
}

module.exports = {
  isArray: isArray,
  isArrayBuffer: isArrayBuffer,
  isBuffer: isBuffer,
  isFormData: isFormData,
  isArrayBufferView: isArrayBufferView,
  isString: isString,
  isNumber: isNumber,
  isObject: isObject,
  isUndefined: isUndefined,
  isDate: isDate,
  isFile: isFile,
  isBlob: isBlob,
  isFunction: isFunction,
  isStream: isStream,
  isURLSearchParams: isURLSearchParams,
  isStandardBrowserEnv: isStandardBrowserEnv,
  forEach: forEach,
  merge: merge,
  deepMerge: deepMerge,
  extend: extend,
  trim: trim
};


/***/ }),

/***/ "./node_modules/process/browser.js":
/*!*****************************************!*\
  !*** ./node_modules/process/browser.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),

/***/ "./node_modules/storedsafe/dist/index.js":
/*!***********************************************!*\
  !*** ./node_modules/storedsafe/dist/index.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable @typescript-eslint/member-delimiter-style */
var axios_1 = __importDefault(__webpack_require__(/*! axios */ "./node_modules/axios/index.js"));
var LoginType;
(function (LoginType) {
    LoginType["TOTP"] = "totp";
    LoginType["SMARTCARD"] = "smc_rest";
})(LoginType = exports.LoginType || (exports.LoginType = {}));
var StoredSafe = /** @class */ (function () {
    function StoredSafe(_a, version) {
        var host = _a.host, apikey = _a.apikey, token = _a.token;
        if (version === void 0) { version = '1.0'; }
        this.axios = axios_1.default.create({
            baseURL: "https://" + host + "/api/" + version + "/",
            timeout: 5000
        });
        this.apikey = apikey;
        this.token = token;
    }
    StoredSafe.prototype.assertApikeyExists = function () {
        if (this.apikey === undefined) {
            throw new Error('Path requires apikey, apikey is undefined.');
        }
    };
    StoredSafe.prototype.assertTokenExists = function () {
        if (this.token === undefined) {
            throw new Error('Path requires token, token is undefined.');
        }
    };
    StoredSafe.prototype.loginYubikey = function (username, passphrase, otp) {
        var _this = this;
        this.assertApikeyExists();
        return this.axios
            .post('/auth', {
            username: username,
            keys: "" + passphrase + this.apikey + otp
        })
            .then(function (response) {
            _this.token = response.data.CALLINFO.token;
            return response;
        });
    };
    StoredSafe.prototype.loginTotp = function (username, passphrase, otp) {
        var _this = this;
        this.assertApikeyExists();
        return this.axios
            .post('/auth', {
            username: username,
            passphrase: passphrase,
            otp: otp,
            logintype: LoginType.TOTP,
            apikey: this.apikey
        })
            .then(function (response) {
            _this.token = response.data.CALLINFO.token;
            return response;
        });
    };
    StoredSafe.prototype.logout = function () {
        var _this = this;
        this.assertTokenExists();
        return this.axios
            .get('/auth/logout', {
            headers: { 'X-Http-Token': this.token }
        })
            .then(function (response) {
            _this.token = undefined;
            return response;
        });
    };
    StoredSafe.prototype.check = function () {
        this.assertTokenExists();
        return this.axios.post('/auth/check', {}, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.listVaults = function () {
        this.assertTokenExists();
        return this.axios.get('/vault', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.vaultObjects = function (id) {
        this.assertTokenExists();
        return this.axios.get("/vault/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.vaultMembers = function (id) {
        this.assertTokenExists();
        return this.axios.get("/vault/" + id + "/members", {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.createVault = function (params) {
        this.assertTokenExists();
        return this.axios.post('/vault', __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.editVault = function (id, params) {
        this.assertTokenExists();
        return this.axios.put("/vault/" + id, __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.deleteVault = function (id) {
        this.assertTokenExists();
        return this.axios.delete("/vault/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.getObject = function (id, children) {
        if (children === void 0) { children = false; }
        this.assertTokenExists();
        return this.axios.get("/object/" + id, {
            params: { children: children },
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.decryptObject = function (id) {
        this.assertTokenExists();
        return this.axios.get("/object/" + id, {
            params: { decrypt: true },
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.createObject = function (params) {
        this.assertTokenExists();
        return this.axios.post('/object', __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.editObject = function (id, params) {
        this.assertTokenExists();
        return this.axios.put("/object/" + id, __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.deleteObject = function (id) {
        this.assertTokenExists();
        return this.axios.delete("/object/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.find = function (needle) {
        this.assertTokenExists();
        return this.axios.get('/find', {
            params: { needle: needle },
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.listTemplates = function () {
        this.assertTokenExists();
        return this.axios.get('/template', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.getTemplate = function (id) {
        this.assertTokenExists();
        return this.axios.get("/template/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.statusValues = function () {
        this.assertTokenExists();
        return this.axios.get('/utils/statusvalues', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.passwordPolicies = function () {
        this.assertTokenExists();
        return this.axios.get('/utils/policies', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.version = function () {
        this.assertTokenExists();
        return this.axios.get('/utils/version', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.generatePassword = function (params) {
        if (params === void 0) { params = {}; }
        this.assertTokenExists();
        return this.axios.get('utils/pwgen', {
            headers: { 'X-Http-Token': this.token },
            params: params
        });
    };
    return StoredSafe;
}());
exports.default = StoredSafe;


/***/ }),

/***/ "./src/model/storage/Ignore.ts":
/*!*************************************!*\
  !*** ./src/model/storage/Ignore.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting sites where
 * the extension should not offer to save login information.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
const userStorage = browser.storage.sync;
/**
 * Get ignored sites from user storage.
 * @returns List of ignored sites.
 * */
async function get() {
    const { ignore } = await userStorage.get('ignore');
    return ignore === undefined ? [] : ignore;
}
/**
 * Commit new ignore list to user storage.
 * @param ignore - New ignore list.
 * */
async function set(ignore) {
    return await userStorage.set({ ignore });
}
/// /////////////////////////////////////////////////////////
// Actions
/**
 * Add new host to ignore.
 * @param host - New ignore entry.
 * @returns New ignore.
 * */
async function add(host) {
    const ignore = await get();
    if (ignore.includes(host)) {
        return ignore;
    }
    const newIgnore = [...ignore];
    newIgnore.push(host);
    return await set(newIgnore).then(get);
}
/**
 * Remove host from ignore.
 * @param host - Host to remove.
 * @returns New ignore list.
 * */
async function remove(host) {
    const ignore = await get();
    const newIgnore = ignore.filter(listedHost => listedHost !== host);
    return await set(newIgnore).then(get);
}
/**
 * Clear ignore.
 * @returns Updated ignore list (empty).
 * */
async function clear() {
    return await set([]).then(get);
}
exports.actions = {
    add,
    remove,
    clear,
    fetch: get
};


/***/ }),

/***/ "./src/model/storage/Preferences.ts":
/*!******************************************!*\
  !*** ./src/model/storage/Preferences.ts ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting user
 * preferences based on how the user interacts with the extension.
 * Examples of this is when the user decides to save a username or remembering
 * which site the user logged into last.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * @returns Promise containing the user preferences.
 * */
async function get() {
    const { preferences } = await browser.storage.local.get('preferences');
    return preferences === undefined ? { sites: {} } : preferences;
}
/**
 * Commit user preferences to local storage.
 * @param preferences - New user preferences.
 * */
async function set(preferences) {
    return await browser.storage.local.set({ preferences });
}
/// /////////////////////////////////////////////////////////
// Actions
/**
 * Set the last used site.
 * @param host - The last used site host.
 * @returns New user preferences.
 * */
async function setLastUsedSite(host) {
    const preferences = await get();
    return await set(Object.assign(Object.assign({}, preferences), { lastUsedSite: host })).then(get);
}
/**
 * Update user preferences for the given host.
 * Will create an entry for the host if one doesn't exist.
 * @param host - The host associated with the preferences.
 * @param sitePreferences - New user preferences for the specified host.
 * @returns New user preferences.
 * */
async function updateSitePreferences(host, sitePreferences) {
    const preferences = await get();
    const newSitePreferences = Object.assign(Object.assign({}, preferences), { sites: Object.assign(Object.assign({}, preferences.sites), { [host]: sitePreferences }) });
    return await set(newSitePreferences).then(get);
}
/**
 * Set the last used result on a particular site so that this result can
 * be used for autofill-scenarios.
 * @param url - URL of page where result was used.
 * @param host - StoredSafe host where the used result was fetched from.
 * @param objectId - StoredSafe obejct id of the used result.
 */
async function setLastUsedResult(url, host, objectId) {
    var _a;
    const preferences = await get();
    const lastUsedResults = (_a = new Map(preferences.lastUsedResults)) !== null && _a !== void 0 ? _a : new Map();
    lastUsedResults.set(url, { host, objectId });
    return await set(Object.assign(Object.assign({}, preferences), { lastUsedResults: [...lastUsedResults] })).then(get);
}
/**
 * Clear user preferences.
 * @returns New user preferences.
 * */
async function clear() {
    return await set({ sites: {} }).then(get);
}
exports.actions = {
    setLastUsedResult,
    setLastUsedSite,
    updateSitePreferences,
    clear,
    fetch: get
};


/***/ }),

/***/ "./src/model/storage/Sessions.ts":
/*!***************************************!*\
  !*** ./src/model/storage/Sessions.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting StoredSafe
 * sessions as a means of indicating whether a user is logged into a site or
 * not. The extension background script is expected to set/clear this storage
 * area as a user performs a login/logout action or when a session times out.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = exports.parse = void 0;
const storageTools_1 = __webpack_require__(/*! ./storageTools */ "./src/model/storage/storageTools.ts");
/**
 * Parse serialized sessions from storage.
 * @param sessions - Serializable sessions from storage
 */
function parse(sessions) {
    return new Map(sessions === undefined ? [] : sessions);
}
exports.parse = parse;
/**
 * Get sessions from local storage.
 * @returns Promise containing all currently active sessions.
 * */
async function get() {
    const { sessions } = await browser.storage.local.get('sessions');
    return parse(sessions);
}
/**
 * Commit Sessions object to sync storage.
 * @param sessions - All currently active sessions.
 * @returns Empty promise.
 * */
async function set(sessions) {
    return await browser.storage.local.set({
        sessions: [...sessions]
    });
}
/// /////////////////////////////////////////////////////////
// Actions
/**
 * Add new session to storage.
 * @param host - Host that the session is associated with.
 * @param session - New session data.
 * @returns Updated active sessions.
 * */
async function add(host, session) {
    const sessions = await get();
    const newSessions = new Map([...sessions, [host, session]]);
    return await set(newSessions).then(get);
}
/**
 * Remove sessions from storage.
 * @param hosts - Hosts that the sessions are associated with.
 * @returns Updated active sessions.
 * */
async function remove(...hosts) {
    const sessions = await get();
    const newSessions = new Map(sessions);
    for (const host of hosts) {
        newSessions.delete(host);
    }
    return await set(newSessions).then(get);
}
const onChanged = new storageTools_1.StorageChangeListener('sessions', get, ['local']);
/**
 * Clear all sessions.
 * @returns Updated active sessions (empty).
 * */
async function clear() {
    return await set(new Map([])).then(get);
}
exports.actions = {
    add,
    remove,
    clear,
    fetch: get,
    onChanged
};


/***/ }),

/***/ "./src/model/storage/Settings.ts":
/*!***************************************!*\
  !*** ./src/model/storage/Settings.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting options set
 * by the user or by the system administrator. User settings are persisted in
 * sync storage which syncs with your browser account if you're logged in.
 * Administrators can add custom default or enforced values using a managed
 * storage manifest which is loaded by this module.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 *
 * Sync storage and managed storage as well as application defaults are merged
 * in this module per field using the following priority:
 * 1. Managed enforced
 * 2. Sync
 * 3. Managed defaults
 * 4. Application defaults
 *
 * When updating settings, all managed fields are silently ignored. The module
 * will however not prevent the setting of fields in sync storage that also exist
 * in managed enforced storage because when fetching settings, any such overlapping
 * fields will simply be ignored in favor of higher priority settings.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = exports.merge = exports.defaults = void 0;
const storageTools_1 = __webpack_require__(/*! ./storageTools */ "./src/model/storage/storageTools.ts");
const systemStorage = browser.storage.managed;
const userStorage = browser.storage.sync;
/**
 * Default values for settings.
 * @param idleMax - Number of minutes a user can be idle before being logged out.
 * @param autoFill - Whether or not to automatically fill forms when possible.
 * @param maxTokenLife - Number of hours a session is allowed to be maintained.
 * */
exports.defaults = {
    idleMax: 20,
    autoFill: false,
    maxTokenLife: 8
};
/**
 * Merge one or more unparsed settings objects into a single Settings object.
 * @param settingsObjects - Settings objects in descending order of priority.
 */
function merge(...settingsObjects) {
    const settings = new Map();
    for (const [settingsObject, managed] of settingsObjects) {
        if (settingsObject !== undefined) {
            populate(settings, settingsObject, managed);
        }
    }
    return settings;
}
exports.merge = merge;
/**
 * Populates given Settings object in-place.
 * @param settings - Existing settings to merge with.
 * @param values - Values to populate settings with.
 * @param managed - Whether or not the values are managed.
 * */
const populate = (settings, values, managed = false) => {
    Object.keys(values).forEach(key => {
        if (!settings.has(key)) {
            settings.set(key, { managed, value: values[key] });
        }
    });
};
/**
 * Get settings from managed and sync storage and convert
 * into Settings object where enforced values from managed
 * storage are set as managed.
 * @returns Merged user and system settings.
 * */
async function get() {
    var _a;
    let systemSettings = {};
    try {
        const { settings } = await systemStorage.get('settings');
        systemSettings = settings === undefined ? {} : settings;
    }
    catch (error) {
        if ((_a = error.message) === null || _a === void 0 ? void 0 : _a.includes('storage manifest')) {
            console.warn('No managed storage manifest found.');
        }
        else {
            throw error;
        }
    }
    const { settings: userSettings } = await userStorage.get('settings');
    return merge([systemSettings === null || systemSettings === void 0 ? void 0 : systemSettings.enforced, true], [userSettings, false], [systemSettings === null || systemSettings === void 0 ? void 0 : systemSettings.defaults, false], [exports.defaults, false]);
}
/**
 * Commit user settings to sync storage.
 * @param settings - New user settings.
 * */
async function set(settings) {
    const userSettings = {};
    for (const [key, field] of settings) {
        if (!field.managed) {
            userSettings[key] = field.value;
        }
    }
    return await userStorage.set({ settings: userSettings });
}
/**
 * Update user settings. Managed fields will be ignored.
 * @param settings - Updated settings.
 * @returns New merged user and system settings.
 * */
async function update(updatedSettings) {
    const settings = await get();
    const newSettings = new Map([...settings, ...updatedSettings]);
    return await set(newSettings).then(get);
}
async function clear() {
    return await set(new Map()).then(get);
}
const onChanged = new storageTools_1.StorageChangeListener('settings', get, ['sync', 'managed']);
exports.actions = {
    update,
    clear,
    fetch: get,
    onChanged
};


/***/ }),

/***/ "./src/model/storage/storageTools.ts":
/*!*******************************************!*\
  !*** ./src/model/storage/storageTools.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StorageChangeListener = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../../utils/Logger */ "./src/utils/Logger.ts"));
class StorageChangeListener {
    constructor(key, get, areas = ['local', 'sync', 'managed']) {
        this.listeners = [];
        // Make sure JS remembers what `this` is
        this.notify = this.notify.bind(this);
        this.onChanged = this.onChanged.bind(this);
        this.addListener = this.addListener.bind(this);
        this.removeListener = this.removeListener.bind(this);
        this.logger = new Logger_1.default(`StorageChange - ${key}`);
        this.key = key;
        this.areas = areas;
        this.get = get;
        // Subscribe to changes in storage
        browser.storage.onChanged.addListener(this.onChanged);
    }
    async notify() {
        try {
            const values = await this.get();
            for (const listener of this.listeners) {
                listener(values);
            }
        }
        catch (error) {
            this.logger.error('Error pushing `%s` change from storage. %o', this.key, error);
        }
    }
    onChanged(changes, areaName) {
        if (this.areas.includes(areaName) && changes.hasOwnProperty(this.key)) {
            void (async () => {
                await this.notify();
            })();
        }
    }
    addListener(listener) {
        if (!this.listeners.includes(listener))
            this.listeners.push(listener);
    }
    removeListener(listener) {
        const index = this.listeners.indexOf(listener);
        if (index !== -1) {
            this.listeners.splice(index, 1);
        }
    }
}
exports.StorageChangeListener = StorageChangeListener;


/***/ }),

/***/ "./src/model/storedsafe/AuthHandler.ts":
/*!*********************************************!*\
  !*** ./src/model/storedsafe/AuthHandler.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * Login to StoredSafe.
 * @param request - Request callback function.
 * @param fields - Credentials and specification of login type.
 * @returns Session created from response if successful.
 * */
async function login(request, fields) {
    const data = (await request(async (handler) => {
        let promise;
        if (fields.loginType === 'yubikey') {
            const { username, keys } = fields;
            const passphrase = keys.slice(0, -44);
            const otp = keys.slice(-44);
            promise = handler.loginYubikey(username, passphrase, otp);
        }
        else {
            // if (fields.loginType === 'totp') {
            const { username, passphrase, otp } = fields;
            promise = handler.loginTotp(username, passphrase, otp);
        }
        return await promise;
    }));
    const { token, audit, timeout } = data.CALLINFO;
    const violations = Array.isArray(audit.violations) ? {} : audit.violations;
    const warnings = Array.isArray(audit.warnings) ? {} : audit.warnings;
    return {
        token,
        createdAt: Date.now(),
        violations,
        warnings,
        timeout
    };
}
/**
 * Logout from StoredSafe
 * @param request - Request callback function.
 * @param host - Host related to the session to invalidate.
 * */
async function logout(request) {
    await request(async (handler) => await handler.logout());
}
/**
 * Check if token is still valid and refresh the token if it is.
 * @param request - Request callback function.
 * @returns True if token is still valid, otherwise false.
 * */
async function check(request) {
    try {
        await request(async (handler) => await handler.check());
        return true;
    }
    catch (error) {
        if (error.message.match('StoredSafe') !== null) {
            return false;
        }
        throw error;
    }
}
exports.actions = {
    login,
    logout,
    check
};


/***/ }),

/***/ "./src/model/storedsafe/MiscHandler.ts":
/*!*********************************************!*\
  !*** ./src/model/storedsafe/MiscHandler.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * Get the available vaults from the given site.
 * @param request - Request callback function.
 * @returns All available StoredSafe vaults on the host.
 * */
async function getVaults(request) {
    var _a, _b;
    let data;
    try {
        data = (await request(async (handler) => await handler.listVaults()));
    }
    catch (error) {
        // NOTE: If vault list is empty, StoredSafe sends 404
        if (((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) !== undefined) {
            data = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data;
        }
        else {
            throw error;
        }
    }
    return data.VAULTS.map(vault => ({
        id: vault.id,
        name: vault.groupname,
        canWrite: ['2', '4'].includes(vault.status) // Write or Admin
    }));
}
/**
 * Get the available templates from the given site.
 * @param request - Request callback function.
 * @returns All available StoredSafe templates on the host.
 * */
async function getTemplates(request) {
    const data = (await request(async (handler) => await handler.listTemplates()));
    const templates = [];
    for (const template of data.TEMPLATE) {
        if (template.INFO.file !== undefined)
            continue;
        templates.push({
            id: template.INFO.id,
            name: template.INFO.name,
            icon: template.INFO.ico,
            structure: Object.keys(template.STRUCTURE).map(fieldName => {
                const field = template.STRUCTURE[fieldName];
                return {
                    title: field.translation,
                    name: fieldName,
                    type: field.type,
                    isEncrypted: field.encrypted
                };
            })
        });
    }
    return templates;
}
/**
 * Generate a new password.
 * @param request - Request callback function.
 * @param params - Optional parameters for password generation.
 * @returns Generated password.
 * */
async function generatePassword(request, params) {
    const data = (await request(async (handler) => await handler.generatePassword(params)));
    return data.CALLINFO.passphrase;
}
exports.actions = {
    getVaults,
    getTemplates,
    generatePassword
};


/***/ }),

/***/ "./src/model/storedsafe/ObjectHandler.ts":
/*!***********************************************!*\
  !*** ./src/model/storedsafe/ObjectHandler.ts ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * Helper function to parse objects and templates returned from a find request.
 * @param ssObject StoredSafe object.
 * @param @ssTemplate StoredSafe template.
 * @param isDecrypted Whether the object has just been decrypted.
 * @returns Parsed representation of object and template info.
 * */
const parseSearchResult = (host, ssObject, ssTemplate, isDecrypted = false) => {
    // Extract general object info
    const name = ssObject.objectname;
    const { id, templateid: templateId, groupid: vaultId } = ssObject;
    const { name: type, ico: icon } = ssTemplate.info;
    const fields = [];
    // Extract field info from template
    ssTemplate.structure.forEach(field => {
        const { fieldname: fieldName, translation: title, encrypted: isEncrypted, policy: isPassword } = field;
        // Value may be undefined if the field is encrypted
        const value = isEncrypted
            ? isDecrypted
                ? ssObject.crypted[field.fieldname]
                : undefined
            : ssObject.public[field.fieldname];
        // Add field to object fields
        fields.push({
            name: fieldName,
            title,
            value,
            isEncrypted,
            isPassword
        });
    });
    // Compile all parsed information
    return {
        host,
        id,
        templateId,
        vaultId,
        name,
        type,
        icon,
        isDecrypted,
        fields
    };
};
// Only include templates that contain these fields
const includeFields = ['password', 'pincode'];
// Exclude templates that contain these fields
const excludeFields = ['file1'];
/**
 * Find and parse StoredSafe objects matching the provided needle.
 * @param request - Request callback function.
 * @param needle - Search string to match against in StoredSafe.
 * @returns Results matching needle.
 * */
async function find(request, needle, host) {
    const data = (await request(async (handler) => await handler.find(needle)));
    const results = [];
    for (let i = 0; i < data.OBJECT.length; i++) {
        const ssObject = data.OBJECT[i];
        const ssTemplate = data.TEMPLATES.find(template => template.id === ssObject.templateid);
        if (ssTemplate.structure.findIndex(field => includeFields.includes(field.fieldname)) === -1 ||
            ssTemplate.structure.findIndex(field => excludeFields.includes(field.fieldname)) !== -1) {
            continue;
        }
        results.push(parseSearchResult(host, ssObject, ssTemplate));
    }
    return results;
}
/**
 * Decrypt StoredSafe object.
 * @param request - Request callback function.
 * @param objectId - ID in StoredSafe of object to decrypt.
 * @returns The decrypted object.
 * */
async function decrypt(request, objectId, host) {
    const data = (await request(async (handler) => await handler.decryptObject(objectId)));
    const ssObject = data.OBJECT.find(obj => obj.id === objectId);
    const ssTemplate = data.TEMPLATES.find(template => template.id === ssObject.templateid);
    return parseSearchResult(host, ssObject, ssTemplate, true);
}
/**
 * Add object to StoredSafe.
 * @param request - Request callback function.
 * @param params - Object parameters based on the chosen StoredSafe template.
 * */
async function add(request, params) {
    await request(async (handler) => await handler.createObject(params));
}
exports.actions = {
    find,
    decrypt,
    add
};


/***/ }),

/***/ "./src/model/storedsafe/StoredSafe.ts":
/*!********************************************!*\
  !*** ./src/model/storedsafe/StoredSafe.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for the StoredSafe API wrapper to handle writing
 * relevant data to storage and parsing the raw StoredSafe response into
 * the more relevant application data structures.
 * - actions object provides the public interface for the model.
 * */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
const storedsafe_1 = __importDefault(__webpack_require__(/*! storedsafe */ "./node_modules/storedsafe/dist/index.js"));
const Sessions_1 = __webpack_require__(/*! ../storage/Sessions */ "./src/model/storage/Sessions.ts");
const ObjectHandler_1 = __webpack_require__(/*! ./ObjectHandler */ "./src/model/storedsafe/ObjectHandler.ts");
const AuthHandler_1 = __webpack_require__(/*! ./AuthHandler */ "./src/model/storedsafe/AuthHandler.ts");
const MiscHandler_1 = __webpack_require__(/*! ./MiscHandler */ "./src/model/storedsafe/MiscHandler.ts");
/**
 * Helper function to handle errors when interacting with the StoredSafe API.
 * All StoredSafe requests with errors will look similar and therefore be
 * handled the same way.
 * @param promise - Promise returned by StoredSafe request.
 * @returns Data returned by StoredSafe or promise with error.
 * */
async function handleErrors(promise) {
    var _a, _b, _c;
    try {
        const response = await promise;
        return response.data;
    }
    catch (error) {
        if (((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) !== undefined) {
            const data = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data;
            if (((_c = data.ERRORS) === null || _c === void 0 ? void 0 : _c.length) > 0) {
                const errors = data.ERRORS.join(' | ');
                throw new Error(`StoredSafe Error: ${errors}`);
            }
            if (data.ERRORCODES !== undefined && Object.keys(data.ERRORCODES).length > 0) {
                const errors = Object.values(data.ERRORCODES).join(' | ');
                throw new Error(`StoredSafe Error: ${errors}`);
            }
            // Server sent error code but no error response (see 404 for empty vaults)
            throw error;
        }
        else if (error.request !== undefined) {
            const { status, statusText } = error.request;
            console.error('StoredSafe network error: ', error);
            throw new Error(`Network Error, unable to connect to host.`);
        }
        const message = error.message;
        throw new Error(`Unexpected Error: ${message}`);
    }
}
/**
 * Get StoredSafe handler for the given host.
 * @param host - Host to connect to.
 * @returns StoredSafe handler or promise with error if no session was found.
 * */
async function getHandler(host) {
    const sessions = await Sessions_1.actions.fetch();
    if (sessions.get(host) === undefined) {
        throw new Error(`No active session for ${host}`);
    }
    const { token } = sessions.get(host);
    return new storedsafe_1.default({ host, token });
}
/**
 * Create and perform initial handling of request.
 * @param host - Host to create handler callback for.
 * @returns Request function to be passed to sub-handlers.
 * */
function makeRequest(host) {
    return async (cb) => await handleErrors(getHandler(host).then(async (handler) => await cb(handler)));
}
/// /////////////////////////////////////////////////////////
// auth
/**
 * Attempt login with given site.
 * @param site - Site to attempt login with.
 * @param fields - Credentials and specification of login type.
 * @returns Updated list of active sessions (if login is successful).
 * */
async function login({ host, apikey }, fields) {
    const handler = new storedsafe_1.default({ host, apikey });
    const request = async (cb) => await handleErrors(cb(handler));
    const session = await AuthHandler_1.actions.login(request, fields);
    return await Sessions_1.actions.add(host, session);
}
/**
 * Logout from given site.
 * Will silently remove session even if logout fails.
 * @param host - Host related to the session to invalidate.
 * @returns Updated list of active sessions.
 * */
async function logout(host) {
    try {
        await AuthHandler_1.actions.logout(makeRequest(host));
    }
    catch (error) {
        console.error('StoredSafe Logout Error', error);
    }
    return await Sessions_1.actions.remove(host);
}
/**
 * Logout from all sites.
 * Will silently remove sessions even if logout fails.
 * @returns Updated list of active sessions (empty).
 * */
async function logoutAll() {
    const sessions = await Sessions_1.actions.fetch();
    [...sessions.keys()].forEach(host => {
        AuthHandler_1.actions.logout(makeRequest(host)).catch(error => {
            console.error('StoredSafe Logout Error', error);
        });
    });
    return await Sessions_1.actions.clear();
}
/**
 * Check if session is still valid, remove it if it's not.
 * @param host - Host related to the session to validate.
 * @returns Updated list of active sessions.
 * */
async function check(host) {
    const isValid = await AuthHandler_1.actions.check(makeRequest(host));
    return isValid
        ? await Sessions_1.actions.fetch()
        : await Sessions_1.actions.remove(host);
}
/**
 * Check if sessions are still valid, remove those that are not.
 * @returns Updated list of active sessions.
 * */
async function checkAll() {
    const sessions = await Sessions_1.actions.fetch();
    const invalidHosts = [];
    for (const host of sessions.keys()) {
        const isValid = await AuthHandler_1.actions.check(makeRequest(host));
        if (!isValid) {
            invalidHosts.push(host);
        }
    }
    if (invalidHosts.length > 0) {
        return await Sessions_1.actions.remove(...invalidHosts);
    }
    return sessions;
}
/// /////////////////////////////////////////////////////////
// object
/**
 * Find search results from given sites.
 * @param host - Host to perform search on.
 * @param needle - Search string to match against in StoredSafe.
 * @returns Matched results from host.
 * */
async function find(host, needle) {
    return await ObjectHandler_1.actions.find(makeRequest(host), needle, host);
}
/**
 * Decrypt StoredSafe object.
 * @param host - Host to request decryption from.
 * @param objectId - ID in StoredSafe of object to decrypt.
 * @returns The decrypted object.
 * */
async function decrypt(host, objectId) {
    return await ObjectHandler_1.actions.decrypt(makeRequest(host), objectId, host);
}
/**
 * Add object to StoredSafe.
 * @param host - Host to add object to.
 * @param params - Object parameters based on the chosen StoredSafe template.
 * */
async function addObject(host, params) {
    return await ObjectHandler_1.actions.add(makeRequest(host), params);
}
/// /////////////////////////////////////////////////////////
// misc
/**
 * Get info about site structure and capabilities.
 * @param host - Host to retreive info about.
 * @returns - Info regarding the structure of the site.
 * */
async function getSiteInfo(host) {
    const handler = await getHandler(host);
    const request = async (cb) => await handleErrors(cb(handler));
    const vaults = await MiscHandler_1.actions.getVaults(request);
    const templates = await MiscHandler_1.actions.getTemplates(request);
    return { vaults, templates };
}
/**
 * Generate a new password.
 * @param host - Host to request a password from.
 * @param params - Optional parameters for password generation.
 * @returns Generated password.
 * */
async function generatePassword(host, params) {
    return await MiscHandler_1.actions.generatePassword(makeRequest(host), params);
}
exports.actions = {
    login,
    logout,
    logoutAll,
    check,
    checkAll,
    find,
    decrypt,
    addObject,
    getSiteInfo,
    generatePassword
};


/***/ }),

/***/ "./src/scripts/background.ts":
/*!***********************************!*\
  !*** ./src/scripts/background.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
/**
 * This script is run in the background by the browser as defined in the extension
 * manifest. In chromium-based browsers it will run as an event page whereas in
 * firefox it will be persistent as firefox does not supportevent pages.
 *
 * All handling of browser events should be handled in this module to the
 * extent that it's possible. Messages can be passed through the background
 * script to enable communication between the content script and iframes or
 * the popup and the content script.
 * */
const Logger_1 = __importDefault(__webpack_require__(/*! ../utils/Logger */ "./src/utils/Logger.ts"));
exports.logger = new Logger_1.default('Background');
const StoredSafe_1 = __webpack_require__(/*! ../model/storedsafe/StoredSafe */ "./src/model/storedsafe/StoredSafe.ts");
const Settings_1 = __webpack_require__(/*! ../model/storage/Settings */ "./src/model/storage/Settings.ts");
/**
 * START REFACTORED CODE
 * TODO: Remove comment
 */
const sessions_1 = __webpack_require__(/*! ./background/sessions */ "./src/scripts/background/sessions/index.ts");
const messages_1 = __webpack_require__(/*! ./background/messages */ "./src/scripts/background/messages/index.ts");
const search_1 = __webpack_require__(/*! ./background/search */ "./src/scripts/background/search/index.ts");
exports.logger.log('Background script initialized: ', new Date(Date.now()));
// Invalidate sessions after being idle for some time
const idleHandler = new sessions_1.IdleHandler();
browser.idle.onStateChanged.addListener(idleHandler.onIdleChange);
sessions_1.KeepAliveHandler.StartTracking();
sessions_1.TimeoutHandler.StartTracking();
sessions_1.OnlineStatusHandler.StartTracking();
messages_1.PortHandler.StartTracking();
search_1.TabHandler.StartTracking();
/**
 * END REFACTORED CODE
 * TODO: Remove comment
 */
/**
 * Decrypt result if needed.
 * */
async function decryptResult(host, result) {
    if (result.isDecrypted)
        return result;
    const hasEncrypted = result.fields.reduce((acc, field) => acc || field.isEncrypted, false);
    if (hasEncrypted) {
        return await StoredSafe_1.actions.decrypt(host, result.id);
    }
    return result;
}
/**
 * Perform a fill operation on the currently active tab.
 */
async function fillTab() {
    // Get currently active tab
    const [tab] = await browser.tabs.query({
        currentWindow: true,
        active: true
    });
    const results = await search_1.TabHandler.GetResults(tab.id);
    messages_1.PortHandler.SendFill(results);
}
/**
 * Copy text to clipboard and clear clipboard after some amount of time.
 * @param value - Value to be copied to clipboard.
 * @param clearTimer - Time to clear clipboard in ms.
 * TODO: Fix clear timer when not focused.
 * */
async function copyToClipboard(value, clearTimer = 10e5) {
    await navigator.clipboard.writeText(value);
    setTimeout(() => {
        navigator.clipboard.writeText('').catch(console.error);
    }, clearTimer);
}
/**
 * Mapped responses to message types.
 * */
const messageHandlers = {
    copyToClipboard: async (value) => await copyToClipboard(value),
    getTabResults: async () => {
        const [tab] = await browser.tabs.query({
            currentWindow: true,
            active: true
        });
        return await search_1.TabHandler.GetResults(tab.id);
    },
    autoFill: async () => {
        const settings = await Settings_1.actions.fetch();
        if (settings.get('autoFill').value === true) {
            await fillTab();
        }
    }
};
/**
 * Handle messages received from other scripts.
 * */
async function onMessage(message, sender) {
    const handler = messageHandlers[message.type];
    if (handler !== undefined) {
        return await handler(message.data, sender);
    }
}
function onCommand(command) {
    if (command === 'fill') {
        fillTab().catch(console.error);
    }
}
// React to messages from other parts of the extension
browser.runtime.onMessage.addListener(onMessage);
// React to keyboard commands defined in the extension manifest
browser.commands.onCommand.addListener(onCommand);


/***/ }),

/***/ "./src/scripts/background/messages/FillFlow.ts":
/*!*****************************************************!*\
  !*** ./src/scripts/background/messages/FillFlow.ts ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FillFlow = void 0;
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const _1 = __webpack_require__(/*! . */ "./src/scripts/background/messages/index.ts");
const constants_1 = __webpack_require__(/*! ../../content_script/messages/constants */ "./src/scripts/content_script/messages/constants.ts");
const messageTools_1 = __webpack_require__(/*! ./messageTools */ "./src/scripts/background/messages/messageTools.ts");
const flowLogger = new Logger_1.default('Fill', _1.logger);
class StoredSafeFillFlowError extends StoredSafeError_1.default {
}
/**
 * Initiate a fill flow to attempt to fill forms on page.
 */
class FillFlow {
    /**
     * Start a new fill flow.
     * @param initPort Port for the content script on the currently active tab.
     * @param results StoredSafe results availble for fill
     */
    constructor(contentPort, results) {
        this.contentPort = null;
        this.onContentDisconnect = this.onContentDisconnect.bind(this);
        this.onIframeConnect = this.onIframeConnect.bind(this);
        this.onIframeDisconnect = this.onIframeDisconnect.bind(this);
        this.onIframeMessage = this.onIframeMessage.bind(this);
        this.onConnect = this.onConnect.bind(this);
        this.cancel = this.cancel.bind(this);
        this.contentPort = contentPort;
        this.results = results;
        this.tabId = this.contentPort.sender.tab.id;
        this.contentPort.onDisconnect.addListener(this.onContentDisconnect);
        this.logger = new Logger_1.default(`(${contentPort.sender.tab.url}) [${contentPort.sender.tab.id}]`, flowLogger);
        this.contentPort.postMessage({
            type: `${constants_1.FLOW_FILL}.${constants_1.ACTION_OPEN}`
        });
        browser.runtime.onConnect.addListener(this.onConnect);
    }
    /**
     * Create a new fill flow for the active tab.
     * @param contentPort - Port for the content script on the currently active tab.
     * @param results - StoredSafe data to fill forms with.
     */
    static Create(contentPort, results) {
        var _a, _b;
        if (((_b = (_a = contentPort === null || contentPort === void 0 ? void 0 : contentPort.sender) === null || _a === void 0 ? void 0 : _a.tab) === null || _b === void 0 ? void 0 : _b.id) === undefined)
            throw new StoredSafeFillFlowError('Sender has no tab ID.');
        // No results, do nothing
        if (results.length < 1)
            return;
        // Single result, fill
        if (results.length === 1) {
            messageTools_1.setLastUsedResult(contentPort.sender.url, results[0]);
            contentPort.postMessage({
                type: `${constants_1.FLOW_FILL}.${constants_1.ACTION_FILL}`,
                data: results[0]
            });
            return;
        }
        messageTools_1.getLastUsedResult(contentPort.sender.url).then(lastUsed => {
            if (lastUsed !== undefined) {
                const { host, objectId } = lastUsed;
                const result = results.find(result => result.host === host && result.id === objectId);
                if (result !== undefined) {
                    // Preferred result from preferences
                    contentPort.postMessage({
                        type: `${constants_1.FLOW_FILL}.${constants_1.ACTION_FILL}`,
                        data: result
                    });
                    return;
                }
            }
            // Present choice
            const tab = contentPort.sender.tab;
            const flow = FillFlow.flows.get(tab.id);
            if (flow !== undefined) {
                flow.cancel();
            }
            FillFlow.flows.set(tab.id, new FillFlow(contentPort, results));
        });
    }
    /**
     * Tear-down procedure for when content page disconnectes (on reload)
     */
    onContentDisconnect() {
        this.contentPort.onDisconnect.removeListener(this.onContentDisconnect);
        this.contentPort = null;
        this.cancel();
    }
    /**
     * When the iframe connects, it is ready to recieve the flow data.
     */
    onIframeConnect(port) {
        this.logger.debug('Connected to iframe port %s', port.name);
        if (port.name === constants_1.PORT_FILL_CONNECTED) {
            port.postMessage({
                type: `${constants_1.FLOW_FILL}.${constants_1.ACTION_POPULATE}`,
                data: this.results
            });
        }
        else if (port.name === constants_1.PORT_FILL_CLOSE ||
            port.name === constants_1.PORT_FILL_RESIZE ||
            port.name === constants_1.PORT_FILL_FILL) {
            port.onDisconnect.addListener(this.onIframeDisconnect);
            port.onMessage.addListener(this.onIframeMessage);
        }
    }
    /**
     * Tear-down procedure for when iframe disconnects (on close frame / reload).
     */
    onIframeDisconnect(port) {
        port.onDisconnect.removeListener(this.onIframeDisconnect);
        port.onMessage.removeListener(this.onIframeMessage);
    }
    /**
     * Receive messages from iframe port to change the state of the iframe,
     * which can only be done from outside the frame.
     * @param message Message from iframe.
     */
    onIframeMessage(message) {
        const [flow, action] = message.type.split('.');
        if (flow !== constants_1.FLOW_FILL) {
            return; // Other flow from same tab
        }
        if (action === constants_1.ACTION_CLOSE) {
            this.cancel();
        }
        else if (action === constants_1.ACTION_RESIZE) {
            this.contentPort.postMessage(message); // Forward message to content_script
        }
        else if (action === constants_1.ACTION_FILL) {
            messageTools_1.setLastUsedResult(this.contentPort.sender.url, message.data);
            this.contentPort.postMessage(message);
        }
        else {
            throw new StoredSafeFillFlowError(`Unknown message ${flow}.${action}`);
        }
    }
    /**
     * Handle incoming connections from other scripts.
     * Will only handle incoming connections from the same tab that started the flow.
     * @param port Connecting port.
     */
    onConnect(port) {
        var _a, _b, _c, _d;
        if (((_b = (_a = port.sender) === null || _a === void 0 ? void 0 : _a.tab) === null || _b === void 0 ? void 0 : _b.id) === ((_d = (_c = this.contentPort.sender) === null || _c === void 0 ? void 0 : _c.tab) === null || _d === void 0 ? void 0 : _d.id)) {
            if (port.name.match(constants_1.PORT_FILL_PREFIX) !== null) {
                this.onIframeConnect(port);
            }
        }
    }
    /**
     * Cancel fill flow and discard FillFlow object.
     */
    cancel() {
        browser.runtime.onConnect.removeListener(this.onConnect);
        if (this.contentPort !== null) {
            this.contentPort.postMessage({
                type: `${constants_1.FLOW_FILL}.${constants_1.ACTION_CLOSE}`
            });
        }
        FillFlow.flows.delete(this.tabId);
    }
}
exports.FillFlow = FillFlow;
FillFlow.flows = new Map();


/***/ }),

/***/ "./src/scripts/background/messages/PortHandler.ts":
/*!********************************************************!*\
  !*** ./src/scripts/background/messages/PortHandler.ts ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PortHandler = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const _1 = __webpack_require__(/*! . */ "./src/scripts/background/messages/index.ts");
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const constants_1 = __webpack_require__(/*! ../../content_script/messages/constants */ "./src/scripts/content_script/messages/constants.ts");
const SaveFlow_1 = __webpack_require__(/*! ./SaveFlow */ "./src/scripts/background/messages/SaveFlow.ts");
const FillFlow_1 = __webpack_require__(/*! ./FillFlow */ "./src/scripts/background/messages/FillFlow.ts");
class StoredSafePortHandlerError extends StoredSafeError_1.default {
}
const logger = new Logger_1.default('Ports', _1.logger);
class PortHandler {
    constructor(port) {
        this.port = null;
        // Make sure JS remembers what `this` is
        this.startListening = this.startListening.bind(this);
        this.stopListening = this.stopListening.bind(this);
        this.disconnect = this.disconnect.bind(this);
        this.onDisconnect = this.onDisconnect.bind(this);
        this.onMessage = this.onMessage.bind(this);
        this.port = port;
    }
    static StartTracking() {
        browser.runtime.onConnect.addListener(PortHandler.onConnect);
    }
    static StopTracking() {
        browser.runtime.onConnect.removeListener(PortHandler.onConnect);
    }
    static SendFill(data) {
        browser.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
            if (tab === undefined)
                return;
            const contentPortHandler = PortHandler.tabHandlers.get(tab.id);
            FillFlow_1.FillFlow.Create(contentPortHandler.port, data);
        });
    }
    static onConnect(port) {
        var _a, _b;
        if (((_b = (_a = port.sender) === null || _a === void 0 ? void 0 : _a.tab) === null || _b === void 0 ? void 0 : _b.id) === undefined) {
            logger.debug('Connected to %s', port.name);
        }
        else {
            logger.debug('Connected to %s on tab [%d]', port.name, port.sender.tab.id);
        }
        const handler = new PortHandler(port);
        handler.startListening();
        if (port.name === constants_1.PORT_CONTENT) {
            PortHandler.tabHandlers.set(port.sender.tab.id, handler);
        }
    }
    startListening() {
        if (this.port === null) {
            throw new StoredSafePortHandlerError('Port is null, cannot start listening.');
        }
        this.port.onMessage.addListener(this.onMessage);
        this.port.onDisconnect.addListener(this.onDisconnect);
    }
    stopListening() {
        if (this.port === null) {
            throw new StoredSafePortHandlerError('Port is null, cannot stop listening.');
        }
        this.port.onMessage.removeListener(this.onMessage);
        this.port.onDisconnect.removeListener(this.onDisconnect);
        if (this.port.name === constants_1.PORT_CONTENT) {
            PortHandler.tabHandlers.delete(this.port.sender.tab.id);
        }
        this.port = null;
    }
    disconnect() {
        this.port.disconnect();
    }
    onDisconnect() {
        var _a, _b;
        if (((_b = (_a = this.port.sender) === null || _a === void 0 ? void 0 : _a.tab) === null || _b === void 0 ? void 0 : _b.id) === undefined) {
            logger.debug('Disconnected from %s', this.port.name);
        }
        else {
            logger.debug('Disconnected from %s on tab [%d]', this.port.name, this.port.sender.tab.id);
        }
        this.stopListening();
    }
    onMessage({ type, data }) {
        logger.debug('Incoming message %s', type);
        const [flow, action] = type.split('.');
        switch (flow) {
            case constants_1.FLOW_SAVE: {
                if (action === constants_1.ACTION_INIT) {
                    SaveFlow_1.SaveFlow.Create(this.port, data);
                }
                break;
            }
            case constants_1.FLOW_FILL: {
                if (action === constants_1.ACTION_INIT) {
                    function createFillFlow(contentPort) {
                        FillFlow_1.FillFlow.Create(contentPort, data);
                    }
                    if (this.port.name !== constants_1.PORT_CONTENT) {
                        browser.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
                            const contentPortHandler = PortHandler.tabHandlers.get(tab.id);
                            createFillFlow(contentPortHandler.port);
                        });
                    }
                    else {
                        createFillFlow(this.port);
                    }
                }
                break;
            }
            default: {
                throw new StoredSafePortHandlerError(`Unknown message flow: ${flow}.${action}`);
            }
        }
    }
}
exports.PortHandler = PortHandler;
PortHandler.tabHandlers = new Map();


/***/ }),

/***/ "./src/scripts/background/messages/SaveFlow.ts":
/*!*****************************************************!*\
  !*** ./src/scripts/background/messages/SaveFlow.ts ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SaveFlow = void 0;
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const _1 = __webpack_require__(/*! . */ "./src/scripts/background/messages/index.ts");
const constants_1 = __webpack_require__(/*! ../../content_script/messages/constants */ "./src/scripts/content_script/messages/constants.ts");
const messageTools_1 = __webpack_require__(/*! ./messageTools */ "./src/scripts/background/messages/messageTools.ts");
const sessions_1 = __webpack_require__(/*! ../sessions */ "./src/scripts/background/sessions/index.ts");
const flowLogger = new Logger_1.default('Save', _1.logger);
// Stop trying to open save prompt after `SAVE_RETRIES` attempts
const SAVE_RETRIES = 3;
// Stop trying to open save prompt after `SAVE_TIMEOUT` ms
const SAVE_TIMEOUT = 10e3;
// Don't count retry if it has been less than `SAVE_RETRY_TIME` ms has passed since the last attempt.
const SAVE_RETRY_TIME = 1e3;
class StoredSafeSaveFlowError extends StoredSafeError_1.default {
}
/**
 * Initiate a save flow where the user is prompted to save data from
 * a submitted form. This function will only handle the passing of messages
 * to and from the involved scripts and not the actual saving of data.
 *
 * The content script which initiated the flow will handle frame-related actions
 * whereas the script that runs inside the injected frame will handle the actual
 * UI prompt and functions for saving the data in StoredSafe.
 *
 * As a measure against redirects and hasty user navigation, the save prompt
 * will keep appearing until `SAVE_RETRIES` number of attempts have been performed.
 * In addition to the retries, if more than `SAVE_TIMEOUT` ms passes since the flow
 * was started, it is assumed the user has seen the prompt and decided not to
 * interact with it. Therefore it will not appear again on the next connection
 * after the timeout has been reached.
 * @param initPort Port where the init action came from.
 * @param data Form data to be saved.
 */
class SaveFlow {
    /**
     * Start a new save flow.
     * @param initPort Port which initiated the save flow.
     * @param data Submitted form data.
     */
    constructor(initPort, data) {
        this.contentPort = null;
        this.promptCount = 0;
        this.hasTimedOut = false;
        this.timeoutId = null;
        this.lastTry = 0;
        this.onContentConnect = this.onContentConnect.bind(this);
        this.onContentDisconnect = this.onContentDisconnect.bind(this);
        this.onIframeConnect = this.onIframeConnect.bind(this);
        this.onIframeDisconnect = this.onIframeDisconnect.bind(this);
        this.onIframeMessage = this.onIframeMessage.bind(this);
        this.onConnect = this.onConnect.bind(this);
        this.cancel = this.cancel.bind(this);
        this.initPort = initPort;
        this.data = data;
        this.logger = new Logger_1.default(`(${initPort.sender.tab.url}) [${initPort.sender.tab.id}]`, flowLogger);
        this.onContentConnect(this.initPort);
        this.timeoutId = window.setTimeout(() => {
            sessions_1.logger.debug('Flow timed out');
            this.hasTimedOut = true;
        }, SAVE_TIMEOUT);
        browser.runtime.onConnect.addListener(this.onConnect);
    }
    /**
     * Create a new save flow for the active tab. Will cancel any previous flow
     * on that same tab if it exists.
     *
     * The save flow will stop short if the user is not logged in, if the url
     * of the active tab is in the ignore list or if there is a cached search
     * result with the same url and username as the submitted data.
     *
     * @param initPort Port which initiated the save flow.
     * @param data Form data associated with the current flow.
     */
    static Create(initPort, data) {
        var _a, _b;
        if (((_b = (_a = initPort.sender) === null || _a === void 0 ? void 0 : _a.tab) === null || _b === void 0 ? void 0 : _b.id) === undefined)
            throw new StoredSafeSaveFlowError('Sender has no tab ID.');
        const tab = initPort.sender.tab;
        const flow = SaveFlow.flows.get(tab.id);
        if (flow !== undefined) {
            flow.cancel();
        }
        messageTools_1.shouldSave(tab, data)
            .then(save => {
            if (save)
                SaveFlow.flows.set(tab.id, new SaveFlow(initPort, data));
        })
            .catch(() => {
            throw new StoredSafeSaveFlowError('Failed to check whether the save flow should be started.');
        });
    }
    /**
     * When the content_script connects, the save prompt should be opened if the
     * `SAVE_RETRIES` threshold has not been exceeded.
     * @param port Connecting content_script port.
     */
    onContentConnect(port) {
        this.logger.debug('Connected to content port');
        port.onDisconnect.addListener(this.onContentDisconnect);
        this.contentPort = port;
        if (this.promptCount < SAVE_RETRIES && this.hasTimedOut === false) {
            if (Date.now() - this.lastTry > SAVE_RETRY_TIME)
                this.promptCount++;
            this.lastTry = Date.now();
            this.contentPort.postMessage({
                type: `${constants_1.FLOW_SAVE}.${constants_1.ACTION_OPEN}`
            });
        }
        else {
            this.cancel();
        }
    }
    /**
     * Tear-down procedure for when iframe disconnects (reload).
     */
    onContentDisconnect(port) {
        port.onDisconnect.removeListener(this.onContentDisconnect);
        this.contentPort = null;
    }
    /**
     * When the iframe connects, it is ready to recieve the flow data.
     */
    onIframeConnect(port) {
        var _a, _b, _c;
        this.logger.debug('Connected to iframe port');
        if (port.name === constants_1.PORT_SAVE_CONNECTED) {
            const values = {
                url: messageTools_1.simplifyUrl((_a = this.initPort.sender) === null || _a === void 0 ? void 0 : _a.url),
                name: (_c = (_b = this.initPort.sender) === null || _b === void 0 ? void 0 : _b.tab) === null || _c === void 0 ? void 0 : _c.title
            };
            for (const [key, value] of this.data) {
                values[key] = value;
            }
            port.postMessage({
                type: `${constants_1.FLOW_SAVE}.${constants_1.ACTION_POPULATE}`,
                data: values
            });
        }
        else if (port.name === constants_1.PORT_SAVE_CLOSE ||
            port.name === constants_1.PORT_SAVE_RESIZE) {
            port.onDisconnect.addListener(this.onIframeDisconnect);
            port.onMessage.addListener(this.onIframeMessage);
        }
    }
    /**
     * Tear-down procedure for when iframe disconnects (on close frame / reload).
     */
    onIframeDisconnect(port) {
        port.onDisconnect.removeListener(this.onIframeDisconnect);
        port.onMessage.removeListener(this.onIframeMessage);
    }
    /**
     * Receive messages from iframe port to change the state of the iframe,
     * which can only be done from outside the frame.
     * @param message Message from iframe.
     */
    onIframeMessage(message) {
        const [flow, action] = message.type.split('.');
        if (flow !== constants_1.FLOW_SAVE) {
            return; // Other flow from same tab
        }
        if (action === constants_1.ACTION_CLOSE) {
            this.cancel();
        }
        else if (action === constants_1.ACTION_RESIZE) {
            this.contentPort.postMessage(message); // Forward message to content_script
        }
        else {
            throw new StoredSafeSaveFlowError(`Unknown message ${flow}.${action}`);
        }
    }
    /**
     * Handle incoming connections from other scripts.
     * Will only handle incoming connections from the same tab that started the flow.
     * @param port Connecting port.
     */
    onConnect(port) {
        var _a, _b, _c, _d;
        if (((_b = (_a = port.sender) === null || _a === void 0 ? void 0 : _a.tab) === null || _b === void 0 ? void 0 : _b.id) === ((_d = (_c = this.initPort.sender) === null || _c === void 0 ? void 0 : _c.tab) === null || _d === void 0 ? void 0 : _d.id)) {
            if (port.name === constants_1.PORT_CONTENT) {
                this.onContentConnect(port);
            }
            else if (port.name.match(constants_1.PORT_SAVE_PREFIX) !== null) {
                this.onIframeConnect(port);
            }
        }
    }
    /**
     * Cancel save flow and discard SaveFlow object.
     */
    cancel() {
        browser.runtime.onConnect.removeListener(this.onConnect);
        window.clearTimeout(this.timeoutId);
        if (this.contentPort !== null) {
            this.contentPort.postMessage({
                type: `${constants_1.FLOW_SAVE}.${constants_1.ACTION_CLOSE}`
            });
        }
        SaveFlow.flows.delete(this.initPort.sender.tab.id);
    }
}
exports.SaveFlow = SaveFlow;
SaveFlow.flows = new Map();


/***/ }),

/***/ "./src/scripts/background/messages/index.ts":
/*!**************************************************!*\
  !*** ./src/scripts/background/messages/index.ts ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const background_1 = __webpack_require__(/*! ../../background */ "./src/scripts/background.ts");
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
exports.logger = new Logger_1.default('Messages', background_1.logger);
var PortHandler_1 = __webpack_require__(/*! ./PortHandler */ "./src/scripts/background/messages/PortHandler.ts");
Object.defineProperty(exports, "PortHandler", { enumerable: true, get: function () { return PortHandler_1.PortHandler; } });


/***/ }),

/***/ "./src/scripts/background/messages/messageTools.ts":
/*!*********************************************************!*\
  !*** ./src/scripts/background/messages/messageTools.ts ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.setLastUsedResult = exports.getLastUsedResult = exports.shouldSave = exports.stripUrlPath = exports.simplifyUrl = void 0;
const Ignore_1 = __webpack_require__(/*! ../../../model/storage/Ignore */ "./src/model/storage/Ignore.ts");
const Preferences_1 = __webpack_require__(/*! ../../../model/storage/Preferences */ "./src/model/storage/Preferences.ts");
const sessionTools_1 = __webpack_require__(/*! ../sessions/sessionTools */ "./src/scripts/background/sessions/sessionTools.ts");
const search_1 = __webpack_require__(/*! ../search */ "./src/scripts/background/search/index.ts");
/**
 * Convert the URL from the tab that initiated the flow to a more
 * easily identifiable version.
 *
 * Attempts to strip random elements of the URL such as URL parameters.
 *
 * @param url URL of tab that initiated save flow.
 */
function simplifyUrl(url) {
    return url.split('?')[0];
}
exports.simplifyUrl = simplifyUrl;
function stripUrlPath(url) {
    var _a, _b;
    const match = (_b = (_a = url.match(/(?:.+?:\/\/)?.*\//)) === null || _a === void 0 ? void 0 : _a[0]) !== null && _b !== void 0 ? _b : url;
    console.log('STRIP URL', url, match);
    return match;
}
exports.stripUrlPath = stripUrlPath;
async function shouldSave(tab, data) {
    // Don't save if there is no password/pincode
    if (data.findIndex(([key, value]) => (key === 'password' || key === 'pincode') && (value === null || value === void 0 ? void 0 : value.length) > 0) === -1)
        return;
    // Don't save if the user is offline
    const isOnline = await sessionTools_1.checkOnlineStatus();
    if (!isOnline)
        return false;
    // Don't save if the URL is in the ignore list
    const url = tab.url;
    const ignoreList = await Ignore_1.actions.fetch();
    const isIgnore = ignoreList.reduce((isIgnore, host) => isIgnore || new RegExp(host).test(url), false);
    if (isIgnore)
        return false;
    const values = new Map(data);
    // Don't save if a matching result already exists
    // TODO: Consider an option to save next time popup is opened
    const results = await search_1.TabHandler.GetResults(tab.id);
    for (const result of results) {
        for (const { value } of result.fields) {
            if (value === undefined)
                continue;
            const fieldURL = simplifyUrl(url);
            // Check both ways if one is more specific than the other
            if (value.match(fieldURL) !== null || fieldURL.match(value) !== null) {
                const username = result.fields.find(({ name }) => name === 'username')
                    .value;
                if (username === values.get('username')) {
                    return false;
                }
            }
        }
    }
    return true;
}
exports.shouldSave = shouldSave;
/**
 * Get the identifiers for the last result used on the provided URL.
 * @param url URL related to the fill flow.
 */
async function getLastUsedResult(url) {
    const preferences = await Preferences_1.actions.fetch();
    const lastUsedResults = new Map(preferences.lastUsedResults);
    return lastUsedResults.get(stripUrlPath(url));
}
exports.getLastUsedResult = getLastUsedResult;
/**
 * Remember which result was used for fill so that the same result can be used
 * for automatic fill on later visits.
 * @param url URL related to the fill flow.
 * @param result Chosen result to use for fill.
 */
async function setLastUsedResult(url, result) {
    Preferences_1.actions.setLastUsedResult(stripUrlPath(url), result.host, result.id);
}
exports.setLastUsedResult = setLastUsedResult;


/***/ }),

/***/ "./src/scripts/background/search/TabHandler.ts":
/*!*****************************************************!*\
  !*** ./src/scripts/background/search/TabHandler.ts ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TabHandler = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const _1 = __webpack_require__(/*! . */ "./src/scripts/background/search/index.ts");
const searchTools_1 = __webpack_require__(/*! ./searchTools */ "./src/scripts/background/search/searchTools.ts");
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const logger = new Logger_1.default('Tab', _1.logger);
class StoredSafeTabHandlerError extends StoredSafeError_1.default {
}
class TabHandler {
    constructor(tabId) {
        this.isLoading = true;
        this.find = this.find.bind(this);
        this.tabId = tabId;
    }
    static StartTracking() {
        browser.tabs.onActivated.addListener(({ tabId }) => {
            if (TabHandler.handlers.has(tabId))
                return;
            browser.tabs.get(tabId).then(tab => {
                TabHandler.OnUpdated(tabId, { status: 'complete' }, tab);
            });
        });
        browser.tabs.onUpdated.addListener(TabHandler.OnUpdated);
        browser.tabs.onRemoved.addListener(TabHandler.OnRemoved);
    }
    static Clear() {
        for (const handler of TabHandler.handlers.values()) {
            handler.results = [];
        }
    }
    static PurgeHost(purgeHost) {
        for (const handler of TabHandler.handlers.values()) {
            handler.results.filter(({ host }) => host === purgeHost);
        }
    }
    static OnUpdated(tabId, changeInfo, tab) {
        // Skip updates if status hasn't updated
        if (changeInfo.status !== 'complete')
            return;
        // Skip updates when there is no url
        if (tab.url === undefined || tab.url.length === 0)
            return;
        let handler = TabHandler.handlers.get(tabId);
        if (handler === undefined) {
            handler = new TabHandler(tabId);
            TabHandler.handlers.set(tabId, handler);
        }
        handler.find(tab.url);
    }
    static OnRemoved(tabId) {
        let handler = TabHandler.handlers.get(tabId);
        if (handler === undefined) {
            return;
        }
    }
    static GetResults(tabId, timeout = 5000) {
        return new Promise((resolve, reject) => {
            // Set timeout for failure
            const timeoutId = window.setTimeout(() => {
                reject(new StoredSafeTabHandlerError('Timeout getting results from tab.'));
            }, timeout);
            let handler = TabHandler.handlers.get(tabId);
            if (handler === undefined || handler.isLoading) {
                // If handler doesn't exist yet or is loading, start polling
                const intervalId = window.setInterval(() => {
                    handler = TabHandler.handlers.get(tabId);
                    if (handler !== undefined && !handler.isLoading) {
                        resolve(handler.results);
                        window.clearInterval(intervalId);
                        window.clearTimeout(timeoutId);
                    }
                });
            }
            else {
                // Return results if handler is done
                resolve(handler.results);
            }
        });
    }
    updateBadge() {
        const text = this.results.length === 0 ? '' : this.results.length.toString();
        browser.browserAction
            .setBadgeText({
            text,
            tabId: this.tabId
        })
            .catch(error => {
            throw new StoredSafeTabHandlerError('Unable to update badge text with search results.', error);
        });
    }
    find(url) {
        this.isLoading = true;
        searchTools_1.find(url)
            .then(results => {
            this.results = results;
            this.updateBadge();
        })
            .catch(error => {
            throw new StoredSafeTabHandlerError('Unable to fetch search results from StoredSafe.');
        })
            .then(() => (this.isLoading = false));
    }
}
exports.TabHandler = TabHandler;
TabHandler.handlers = new Map();


/***/ }),

/***/ "./src/scripts/background/search/index.ts":
/*!************************************************!*\
  !*** ./src/scripts/background/search/index.ts ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const background_1 = __webpack_require__(/*! ../../background */ "./src/scripts/background.ts");
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
exports.logger = new Logger_1.default('Search', background_1.logger);
var TabHandler_1 = __webpack_require__(/*! ./TabHandler */ "./src/scripts/background/search/TabHandler.ts");
Object.defineProperty(exports, "TabHandler", { enumerable: true, get: function () { return TabHandler_1.TabHandler; } });


/***/ }),

/***/ "./src/scripts/background/search/searchTools.ts":
/*!******************************************************!*\
  !*** ./src/scripts/background/search/searchTools.ts ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.find = exports.urlToNeedle = void 0;
const Sessions_1 = __webpack_require__(/*! ../../../model/storage/Sessions */ "./src/model/storage/Sessions.ts");
const StoredSafe_1 = __webpack_require__(/*! ../../../model/storedsafe/StoredSafe */ "./src/model/storedsafe/StoredSafe.ts");
const _1 = __webpack_require__(/*! . */ "./src/scripts/background/search/index.ts");
function getFQDN(url) {
    const match = url.match(/(?:\w+:\/\/)?(?:www\.)?(?<fqdn>[\w\.]+)/);
    return match === null || match === void 0 ? void 0 : match.groups['fqdn'];
}
/**
 * Extract a search string from the url so that relevant results can be
 * searched for in StoredSafe.
 *
 * Uses special hardcoded case for two two-part TLDs.
 * For potential refactor in the future, take a look at https://github.com/lupomontero/psl
 *
 * Returns the original URL if no match was found.
 * @param url Full URL
 */
function urlToNeedle(url) {
    const fqdn = getFQDN(url);
    if (fqdn === undefined)
        return url;
    const parts = fqdn.split('.');
    if (parts.length === 1)
        return fqdn;
    const tld = [];
    tld.push(parts.pop());
    if (['org', 'co'].includes(parts[parts.length - 1]))
        tld.push(parts.pop());
    const domain = [parts[parts.length - 1], ...tld].join('.');
    return domain;
}
exports.urlToNeedle = urlToNeedle;
function getParts(url) {
    let parts, protocol, subdomain, domain, tld, port, path, params;
    [url, params] = url.split('?');
    params = params || '';
    // Extract protocol
    parts = url.split('://');
    if (parts.length > 1)
        [protocol, url] = parts;
    protocol = protocol || '';
    [url, ...parts] = url.split('/');
    path = parts.join('/') || '';
    [url, ...parts] = url.split(':');
    port = parts[0] || '';
    // Extract tld
    parts = url.split('.');
    let last = parts.length - 1;
    if (parts.length > 1) {
        ;
        [tld] = parts.splice(last--);
        // Add secondary tld part if it exists
        if (['co', 'org'].includes(parts[last])) {
            tld = [parts.splice(last--)[0], tld].join('.');
        }
    }
    tld = tld || '';
    // Split subdomain and domain
    domain = parts.splice(last--)[0] || '';
    subdomain = parts.join('.') || '';
    return { protocol, subdomain, domain, tld, port, path, params };
}
/**
 * Create a comparator function to match against a given URL.
 *
 * Compatible with Array.sort, returns a negative number if the first URL is
 * a better match and a positive number if the other URL is the better match
 * or 0 if they're both equally good matches.
 *
 * @param url URL or partial URL to be matched against in the comparator.
 */
function urlComparator(url) {
    return function (a, b) {
        let [partsA, partsB, partsUrl] = [a, b, url].map(getParts);
        let scoreA = 0, scoreB = 0;
        for (const prop in partsUrl) {
            // If url part is undefined but compare part is not
            if (partsUrl[prop] === undefined || partsUrl[prop].length === 0) {
                if (partsA[prop] !== undefined && partsA[prop].length > 0)
                    scoreA -= 0.9;
                if (partsB[prop] !== undefined && partsB[prop].length > 0)
                    scoreB -= 0.9;
                continue;
            }
            // If url part is defined, add if match, subtract if not
            if (partsA[prop] === partsUrl[prop])
                scoreA++;
            else if (partsA[prop] !== undefined && partsA[prop].length > 0)
                scoreA -= 0.9;
            if (partsB[prop] === partsUrl[prop])
                scoreB++;
            else if (partsB[prop] !== undefined && partsB[prop].length > 0)
                scoreB -= 0.9;
        }
        return scoreB - scoreA;
    };
}
/**
 * Find matching URLs in the provided fields.
 * @param fields Fields of the result object.
 * @param needle The needle that was used for the search.
 */
function getURL(fields, url) {
    const needle = urlToNeedle(url);
    const comparator = urlComparator(url);
    const values = [];
    for (const field of fields) {
        if (field.value === undefined)
            continue;
        // Get matched value with surrounding non-whitespace
        const matches = field.value.match(new RegExp(`\\S*${needle}\\S*`, 'ig'));
        // If there is no match in the field, continue
        if (matches === null)
            continue;
        // Filter out values that contain only matches with e-mails
        if (matches.reduce((isEmail, match) => isEmail && match.match('@') !== null, true))
            continue;
        // Extract URL-like elements
        const urlMatcher = /(?:\w+:\/\/)?(?:www\w*\.)?(?:[\w\-\.]+)+(?:\/[\w\-]+)*/gi;
        const urls = [];
        for (const match of matches) {
            const urlMatch = match.match(urlMatcher);
            if (urlMatch !== null)
                urls.push(urlMatch[0]);
        }
        // Push the URL-like elements that match the needle
        values.push(...urls.filter(url => url.match(needle) !== null));
    }
    return values.sort(comparator)[0] || '';
}
function resultComparator(url) {
    const needle = urlToNeedle(url);
    const comparator = urlComparator(url);
    return function (a, b) {
        const valueA = getURL(a.fields, url);
        const valueB = getURL(b.fields, url);
        if (valueA === valueB)
            return 0;
        if (valueA === undefined)
            return 1;
        if (valueB === undefined)
            return -1;
        return comparator(valueA, valueB);
    };
}
/**
 * Filter out results that have a different subdomain than the provided URL.
 * Will keep URLs that don't have a subdomain.
 * @param results All StoredSafe results matching the needle.
 * @param url The url used to generate the needle.
 */
function filterOtherSubdomain(results, url) {
    const parts = getParts(url);
    return results.filter(result => {
        const fieldURL = getURL(result.fields, url);
        const fieldParts = getParts(fieldURL);
        const isMatch = fieldParts.subdomain === ''
            ? true
            : fieldParts.subdomain === parts.subdomain;
        if (isMatch)
            return isMatch;
    });
}
async function find(url) {
    const needle = urlToNeedle(url);
    const sessions = await Sessions_1.actions.fetch();
    let results = [];
    for (const [host] of sessions) {
        try {
            results = [...results, ...(await StoredSafe_1.actions.find(host, needle))];
        }
        catch (error) {
            _1.logger.error('Unable to perform search on %s, %o', host, error);
        }
    }
    results = results.filter(result => result.fields.findIndex(field => field.name === 'username') !== -1);
    results = results.filter(result => getURL(result.fields, url).length > 0);
    results = filterOtherSubdomain(results, url);
    const comparator = resultComparator(url);
    return results.sort(comparator);
}
exports.find = find;


/***/ }),

/***/ "./src/scripts/background/sessions/IdleHandler.ts":
/*!********************************************************!*\
  !*** ./src/scripts/background/sessions/IdleHandler.ts ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdleHandler = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const _1 = __webpack_require__(/*! . */ "./src/scripts/background/sessions/index.ts");
const sessionTools_1 = __webpack_require__(/*! ./sessionTools */ "./src/scripts/background/sessions/sessionTools.ts");
const logger = new Logger_1.default('Idle', _1.logger);
class StoredSafeIdleError extends StoredSafeError_1.default {
}
/**
 * Handles changes in idle state so that sessions can be invalidated
 * after a user is set as idle. The time to trigger the idle state is
 * based on the user settings for the extension.
 */
class IdleHandler {
    constructor() {
        // Make sure JS remembers what `this` is
        this.onIdleMaxChanged = this.onIdleMaxChanged.bind(this);
        this.setDetectionInterval = this.setDetectionInterval.bind(this);
        this.onIdleChange = this.onIdleChange.bind(this);
        sessionTools_1.subscribeToSettingsField('idleMax', this.onIdleMaxChanged, error => {
            logger.error('Error while setting up idle handler, could not fetch settings. %o', error);
        });
    }
    /**
     * Get idle interval from the updated user settings and adjust the idle detection interval.
     * @param settings Updated settings object.
     */
    onIdleMaxChanged(idleMax) {
        // Convert timeout duration from minutes to milliseconds
        const intervalInSeconds = idleMax * 60;
        this.setDetectionInterval(intervalInSeconds);
    }
    /**
     * Set the time in seconds of inactivity required for the browser to be considered to be in an
     * idle state.
     * @param intervalInSeconds Seconds of inactivity until idle.
     */
    setDetectionInterval(intervalInSeconds) {
        intervalInSeconds = Math.floor(intervalInSeconds);
        intervalInSeconds = Math.max(15, intervalInSeconds);
        logger.log('Setting idle detection interval to %ds (%dm).', intervalInSeconds, intervalInSeconds / 60);
        browser.idle.setDetectionInterval(intervalInSeconds);
    }
    /**
     * Handle changes in the idle state.
     * @param state New idle state.
     */
    onIdleChange(state) {
        if (state === 'idle') {
            logger.log('Idle state triggered, invalidate all sessions.');
            sessionTools_1.invalidateAllSessions();
        }
    }
}
exports.IdleHandler = IdleHandler;


/***/ }),

/***/ "./src/scripts/background/sessions/KeepAliveHandler.ts":
/*!*************************************************************!*\
  !*** ./src/scripts/background/sessions/KeepAliveHandler.ts ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KeepAliveHandler = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const _1 = __webpack_require__(/*! . */ "./src/scripts/background/sessions/index.ts");
const sessionTools_1 = __webpack_require__(/*! ./sessionTools */ "./src/scripts/background/sessions/sessionTools.ts");
const logger = new Logger_1.default('KeepAlive', _1.logger);
class StoredSafeKeepAliveError extends StoredSafeError_1.default {
}
/**
 * Handles keeping StoredSafe sessions alive to circumvent the server timeout
 * in favor of the idle state / max lifetime timeouts generated by the extension.
 *
 * Will also automatically discard dead sessions as a consequence of performing a
 * check request as part of initialization.
 *
 * The reason for implementing this workaround is in part the difference in workflow
 * between the extension and the web interface, but also the added capabilities of
 * user monitoring in the browser extension. Basically it's easier to track whether
 * a user is active and it's more convenient for the user to stay logged in for a
 * longer time while they're using their computer for other things.
 */
class KeepAliveHandler {
    constructor(host, timeout) {
        this.intervalId = null;
        // Make sure JS remembers what `this` is
        this.start = this.start.bind(this);
        this.stop = this.stop.bind(this);
        this.keepAlive = this.keepAlive.bind(this);
        this.host = host;
        this.timeout = timeout * 0.75; // Leave a little margin
        // Perform initial check to ensure time until next check is within the timeout.
        this.keepAlive();
        // Start interval
        this.start();
    }
    /**
     * Set up/remove keep alive from active hosts when the list
     * of active sessions changes.
     * @param sessions Updated list of active sessions.
     */
    static updateKeepAliveHandlers(sessions) {
        for (const [host, keepAliveHandler] of KeepAliveHandler.handlers) {
            if (!sessions.has(host)) {
                keepAliveHandler.stop();
                KeepAliveHandler.handlers.delete(host);
            }
        }
        for (const [host, session] of sessions) {
            if (!KeepAliveHandler.handlers.has(host)) {
                KeepAliveHandler.handlers.set(host, new KeepAliveHandler(host, session.timeout));
            }
        }
    }
    static StartTracking() {
        // Initialize keep alive objects
        sessionTools_1.subscribeToSessions(KeepAliveHandler.updateKeepAliveHandlers);
    }
    static StopTracking() {
        sessionTools_1.unsubscribeFromSessions(KeepAliveHandler.updateKeepAliveHandlers);
    }
    /**
     * Perform check request to keep the token alive.
     */
    keepAlive() {
        logger.log('Keep alive triggered for %s', this.host);
        sessionTools_1.checkSessionToken(this.host);
    }
    /**
     * Start interval for keeping token alive.
     */
    start() {
        if (this.intervalId !== null) {
            throw new StoredSafeKeepAliveError(`can't start keep alive interval for '${this.host}', interval already exists.`);
        }
        logger.log('Scheduled keep alive for %s in %dms (%d minutes)', this.host, this.timeout, this.timeout / 6e4);
        this.intervalId = window.setInterval(this.keepAlive, this.timeout);
    }
    /**
     * Stop interval for keeping token alive.
     */
    stop() {
        if (this.intervalId === null) {
            throw new StoredSafeKeepAliveError(`can't stop keep alive interval for '${this.host}', no interval exists.`);
        }
        else {
            clearInterval(this.intervalId);
            logger.log('Unregistered keep alive for %s', this.host);
        }
    }
}
exports.KeepAliveHandler = KeepAliveHandler;
KeepAliveHandler.handlers = new Map();


/***/ }),

/***/ "./src/scripts/background/sessions/OnlineStatusHandler.ts":
/*!****************************************************************!*\
  !*** ./src/scripts/background/sessions/OnlineStatusHandler.ts ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OnlineStatusHandler = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const _1 = __webpack_require__(/*! . */ "./src/scripts/background/sessions/index.ts");
const sessionTools_1 = __webpack_require__(/*! ./sessionTools */ "./src/scripts/background/sessions/sessionTools.ts");
const ICON_ONLINE = 'ico/icon.png';
const ICON_OFFLINE = 'ico/icon-inactive.png';
const logger = new Logger_1.default('OnlineStatus', _1.logger);
class StoredSafeOnlineStatusError extends StoredSafeError_1.default {
}
/**
 * Handles changes in idle state so that sessions can be invalidated
 * after a user is set as idle. The time to trigger the idle state is
 * based on the user settings for the extension.
 */
class OnlineStatusHandler {
    constructor() {
        // Reference to see if online status has actually changed
        this.isOnline = null;
        // Make sure JS remembers what `this` is
        this.onSessionsChanged = this.onSessionsChanged.bind(this);
        this.setOnlineStatus = this.setOnlineStatus.bind(this);
    }
    /**
     * Start tracking online status.
     */
    static StartTracking() {
        if (OnlineStatusHandler.handler === null) {
            OnlineStatusHandler.handler = new OnlineStatusHandler();
        }
        OnlineStatusHandler.handler.start();
    }
    /**
     * Stop tracking online status.
     */
    static StopTracking() {
        if (OnlineStatusHandler.handler === null) {
            throw new StoredSafeOnlineStatusError('No handler available to stop.');
        }
        OnlineStatusHandler.handler.stop();
    }
    /**
     * Start tracking online status.
     */
    start() {
        sessionTools_1.subscribeToSessions(this.onSessionsChanged);
    }
    /**
     * Stop tracking online status.
     */
    stop() {
        sessionTools_1.unsubscribeFromSessions(this.onSessionsChanged);
    }
    /**
     * Set the online status, indicated by the icon used for the popup.
     * @param isOnline New online status, true if online.
     */
    setOnlineStatus(isOnline) {
        const path = isOnline ? ICON_ONLINE : ICON_OFFLINE;
        browser.browserAction
            .setIcon({ path })
            .then(() => {
            logger.log('Set online status to %s.', isOnline ? 'online' : 'offline');
        })
            .catch(error => {
            throw new StoredSafeOnlineStatusError(`Failed to update online status icon. ${error.message}`);
        });
    }
    /**
     * Update online status based on changes in the list of active sessions.
     * @param settings Updated settings object.
     */
    onSessionsChanged(sessions) {
        const isOnline = sessions.size > 0;
        if (isOnline !== this.isOnline) {
            this.setOnlineStatus(sessions.size > 0);
            this.isOnline = isOnline;
        }
    }
}
exports.OnlineStatusHandler = OnlineStatusHandler;
OnlineStatusHandler.handler = null;


/***/ }),

/***/ "./src/scripts/background/sessions/TimeoutHandler.ts":
/*!***********************************************************!*\
  !*** ./src/scripts/background/sessions/TimeoutHandler.ts ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimeoutHandler = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const _1 = __webpack_require__(/*! . */ "./src/scripts/background/sessions/index.ts");
const sessionTools_1 = __webpack_require__(/*! ./sessionTools */ "./src/scripts/background/sessions/sessionTools.ts");
const logger = new Logger_1.default('Timeout', _1.logger);
class StoredSafeTimeoutError extends StoredSafeError_1.default {
}
/**
 * Handles hard timeouts for tokens after the max token life from the user settings
 * is reached.
 *
 * This can be set either as a security measure, to prevent perpetual sessions, or to
 * force the user to log in more often, helping them remember their master password.
 */
class TimeoutHandler {
    constructor(host, createdAt) {
        this.timeoutId = null;
        // Make sure JS remembers what `this` is
        this.setSessionTimeout = this.setSessionTimeout.bind(this);
        this.clearSessionTimeout = this.clearSessionTimeout.bind(this);
        this.onTimeout = this.onTimeout.bind(this);
        this.onMaxTokenLifeChange = this.onMaxTokenLifeChange.bind(this);
        this.host = host;
        this.createdAt = createdAt;
        this.start();
    }
    /**
     * Set up/remove session timeout handlers when the list of active sessions changes.
     * @param sessions Updated list of active sessions.
     */
    static updateTimeoutHandlers(sessions) {
        for (const [host, timeoutHandler] of TimeoutHandler.handlers) {
            if (!sessions.has(host)) {
                timeoutHandler.stop();
                TimeoutHandler.handlers.delete(host);
            }
        }
        for (const [host, session] of sessions) {
            if (!TimeoutHandler.handlers.has(host)) {
                TimeoutHandler.handlers.set(host, new TimeoutHandler(host, session.createdAt));
            }
        }
    }
    /**
     * Start tracking sessions to set up timeout handlers for active sessions.
     */
    static StartTracking() {
        // Initialize keep alive objects
        sessionTools_1.subscribeToSessions(TimeoutHandler.updateTimeoutHandlers);
    }
    /**
     * Stop tracking sessions and cancel timeouts for active sessions.
     */
    static StopTracking() {
        sessionTools_1.unsubscribeFromSessions(TimeoutHandler.updateTimeoutHandlers);
        for (const handler of TimeoutHandler.handlers.values()) {
            handler.stop();
        }
        TimeoutHandler.handlers.clear();
    }
    /**
     * Start timeout and start tracking changes in settings.
     */
    start() {
        sessionTools_1.subscribeToSettingsField('maxTokenLife', this.onMaxTokenLifeChange, error => {
            logger.error('Could not update session timeout. %o', error);
        });
    }
    /**
     * Stop timeout and stop tracking changes in settings.
     */
    stop() {
        sessionTools_1.unsubscribeFromSettingsField(this.onMaxTokenLifeChange);
        this.clearSessionTimeout();
    }
    /**
     * Invalidate timed out session.
     */
    onTimeout() {
        logger.log('Session for %s timed out.', this.host);
        sessionTools_1.invalidateSession(this.host);
    }
    /**
     * Start interval for keeping token alive.
     * @param timeout Milliseconds until session times out.
     */
    setSessionTimeout(timeout) {
        if (this.timeoutId !== null) {
            this.clearSessionTimeout();
        }
        logger.log('Scheduled session timeout for %s in %dms (%d minutes / %d hours)', this.host, timeout, timeout / 6e4, timeout / 36e5);
        this.timeoutId = window.setTimeout(this.onTimeout, timeout);
    }
    /**
     * Cancel session timeout.
     */
    clearSessionTimeout() {
        if (this.timeoutId === null) {
            throw new StoredSafeTimeoutError(`can't cancel timeout for '${this.host}', no timeout exists.`);
        }
        else {
            window.clearTimeout(this.timeoutId);
            this.timeoutId = null;
            logger.log('Removed session timeout for %s', this.host);
        }
    }
    /**
     * React to changes in the maxTokenLife value of the user settings and adjust timers
     * accordingly.
     * @param maxTokenLife The new max amount of hours a session is able to stay valid.
     */
    onMaxTokenLifeChange(maxTokenLife) {
        if (maxTokenLife === 0) {
            if (this.timeoutId !== null) {
                this.clearSessionTimeout();
            }
            return;
        }
        const tokenLife = Date.now() - this.createdAt;
        const maxTokenLifeMs = maxTokenLife * 36e5; // hours to ms
        const timeout = maxTokenLifeMs - tokenLife;
        this.setSessionTimeout(timeout);
    }
}
exports.TimeoutHandler = TimeoutHandler;
TimeoutHandler.handlers = new Map();


/***/ }),

/***/ "./src/scripts/background/sessions/index.ts":
/*!**************************************************!*\
  !*** ./src/scripts/background/sessions/index.ts ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const background_1 = __webpack_require__(/*! ../../background */ "./src/scripts/background.ts");
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
exports.logger = new Logger_1.default('Sessions', background_1.logger);
var IdleHandler_1 = __webpack_require__(/*! ./IdleHandler */ "./src/scripts/background/sessions/IdleHandler.ts");
Object.defineProperty(exports, "IdleHandler", { enumerable: true, get: function () { return IdleHandler_1.IdleHandler; } });
var KeepAliveHandler_1 = __webpack_require__(/*! ./KeepAliveHandler */ "./src/scripts/background/sessions/KeepAliveHandler.ts");
Object.defineProperty(exports, "KeepAliveHandler", { enumerable: true, get: function () { return KeepAliveHandler_1.KeepAliveHandler; } });
var OnlineStatusHandler_1 = __webpack_require__(/*! ./OnlineStatusHandler */ "./src/scripts/background/sessions/OnlineStatusHandler.ts");
Object.defineProperty(exports, "OnlineStatusHandler", { enumerable: true, get: function () { return OnlineStatusHandler_1.OnlineStatusHandler; } });
var TimeoutHandler_1 = __webpack_require__(/*! ./TimeoutHandler */ "./src/scripts/background/sessions/TimeoutHandler.ts");
Object.defineProperty(exports, "TimeoutHandler", { enumerable: true, get: function () { return TimeoutHandler_1.TimeoutHandler; } });


/***/ }),

/***/ "./src/scripts/background/sessions/sessionTools.ts":
/*!*********************************************************!*\
  !*** ./src/scripts/background/sessions/sessionTools.ts ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unsubscribeFromSettingsField = exports.subscribeToSettingsField = exports.unsubscribeFromSessions = exports.subscribeToSessions = exports.checkSessionToken = exports.invalidateAllSessions = exports.invalidateSession = exports.checkOnlineStatus = void 0;
const Settings_1 = __webpack_require__(/*! ../../../model/storage/Settings */ "./src/model/storage/Settings.ts");
const StoredSafe_1 = __webpack_require__(/*! ../../../model/storedsafe/StoredSafe */ "./src/model/storedsafe/StoredSafe.ts");
const Sessions_1 = __webpack_require__(/*! ../../../model/storage/Sessions */ "./src/model/storage/Sessions.ts");
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const search_1 = __webpack_require__(/*! ../search */ "./src/scripts/background/search/index.ts");
class StoredSafeSessionToolsError extends StoredSafeError_1.default {
}
/**
 * Returns true if there are any active sessions, otherwise false.
 */
async function checkOnlineStatus() {
    return Sessions_1.actions.fetch().then(sessions => sessions.size > 0);
}
exports.checkOnlineStatus = checkOnlineStatus;
/**
 * Invalidate a single session and destroy all cached search results for
 * that host.
 * @param host - Host of session to invalidate.
 * */
async function invalidateSession(host) {
    const logoutPromise = StoredSafe_1.actions.logout(host);
    const purgePromise = search_1.TabHandler.PurgeHost(host);
    await logoutPromise;
    await purgePromise;
}
exports.invalidateSession = invalidateSession;
/**
 * Invalidate all sessions and clear search results.
 * */
async function invalidateAllSessions() {
    const logoutPromise = StoredSafe_1.actions.logoutAll();
    const clearPromise = search_1.TabHandler.Clear();
    await logoutPromise;
    await clearPromise;
}
exports.invalidateAllSessions = invalidateAllSessions;
/**
 * Check whether the token (if any) related to the host is still active.
 * @param host Host to check token status for.
 */
async function checkSessionToken(host) {
    await StoredSafe_1.actions.check(host);
}
exports.checkSessionToken = checkSessionToken;
/**
 * Subscribe to changes in the list of active sessions and optionally trigger an initial fetch.
 * @param listener Callback function listening for changes in active sessions.
 */
async function subscribeToSessions(listener, initialize = true) {
    Sessions_1.actions.onChanged.addListener(listener);
    if (initialize) {
        Sessions_1.actions.fetch().then(listener);
    }
}
exports.subscribeToSessions = subscribeToSessions;
/**
 * Unregister listener from updates to the list of active sessions.
 * @param listener Previously registered listener (see `subscribeToSessions`).
 */
async function unsubscribeFromSessions(listener) {
    Sessions_1.actions.onChanged.removeListener(listener);
}
exports.unsubscribeFromSessions = unsubscribeFromSessions;
const settingsListeners = new Map();
/**
 * Subscribe to changes of specific fields in the user settings.
 * @param key The key in the settings object to observe changes on.
 * @param listener Callback function for when the value has changed.
 * @param onError Callback function for when an error occurs.
 * @param initialize Whether or not to fetch an initial state (default: `true`).
 */
async function subscribeToSettingsField(key, listener, onError, initialize = true) {
    // Reference to previous value in case settings update is due to another field changing
    let prevValue = null;
    // Subscribe to changes in settings
    Settings_1.actions.onChanged.addListener(onSettingsChanged);
    // Save reference to listener for unsubscribing
    settingsListeners.set(listener, onSettingsChanged);
    if (initialize) {
        // Perform initial setup
        Settings_1.actions.fetch()
            .then(onSettingsChanged)
            .catch(onError);
    }
    /**
     * Middleware function to parse settings updates before sending back the
     * actual value to the listener if it was changed.
     * @param settings Updated settings object.
     */
    function onSettingsChanged(settings) {
        try {
            // Get requested value from settings object
            const value = settings.get(key).value;
            // Other value in settings was most likely changed
            if (prevValue === value)
                return;
            // Throw an error if the requested value doesn't exist (shouldn't happen)
            if (value === undefined) {
                throw new StoredSafeSessionToolsError(`'${key}' property of Settings is undefined.`);
            }
            // Update previous value reference
            prevValue = value;
            // Send new value to the listener
            listener(value);
        }
        catch (error) {
            onError(error);
        }
    }
}
exports.subscribeToSettingsField = subscribeToSettingsField;
/**
 * Unregister listener from updates to settings field.
 * @param listener Previously registered listener (see `subscribeToSettingsField`).
 */
function unsubscribeFromSettingsField(listener) {
    const onSettingsChanged = settingsListeners.get(listener);
    if (onSettingsChanged === undefined) {
        throw new StoredSafeSessionToolsError('listener is not registered, cannot unregister.');
    }
    Settings_1.actions.onChanged.removeListener(onSettingsChanged);
}
exports.unsubscribeFromSettingsField = unsubscribeFromSettingsField;


/***/ }),

/***/ "./src/scripts/content_script/messages/constants.ts":
/*!**********************************************************!*\
  !*** ./src/scripts/content_script/messages/constants.ts ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.ACTION_FILL = exports.ACTION_INIT = exports.ACTION_POPULATE = exports.ACTION_RESIZE = exports.ACTION_CLOSE = exports.ACTION_OPEN = exports.FLOW_FILL = exports.FLOW_SAVE = exports.FILL_FRAME_ID = exports.SAVE_FRAME_ID = exports.PORT_CONTENT = exports.PORT_FILL_FILL = exports.PORT_FILL_RESIZE = exports.PORT_FILL_CLOSE = exports.PORT_FILL_CONNECTED = exports.PORT_FILL_PREFIX = exports.PORT_SAVE_RESIZE = exports.PORT_SAVE_CLOSE = exports.PORT_SAVE_CONNECTED = exports.PORT_SAVE_PREFIX = void 0;
// Unique IDs for identifying message origins
exports.PORT_SAVE_PREFIX = 'save_';
exports.PORT_SAVE_CONNECTED = `${exports.PORT_SAVE_PREFIX}connected`;
exports.PORT_SAVE_CLOSE = `${exports.PORT_SAVE_PREFIX}close`;
exports.PORT_SAVE_RESIZE = `${exports.PORT_SAVE_PREFIX}resize`;
exports.PORT_FILL_PREFIX = 'fill_';
exports.PORT_FILL_CONNECTED = `${exports.PORT_FILL_PREFIX}connected`;
exports.PORT_FILL_CLOSE = `${exports.PORT_FILL_PREFIX}close`;
exports.PORT_FILL_RESIZE = `${exports.PORT_FILL_PREFIX}resize`;
exports.PORT_FILL_FILL = `${exports.PORT_FILL_PREFIX}fill`;
exports.PORT_CONTENT = 'content_script';
// Unique IDs used for identifying iframes
exports.SAVE_FRAME_ID = 'com-storedsafe-save';
exports.FILL_FRAME_ID = 'com-storedsafe-fill';
// The available user flows.
// Message types should hold the form <flow>.<action>, for example save.open
exports.FLOW_SAVE = 'save';
exports.FLOW_FILL = 'fill';
//// Common actions
// background -> content_script
exports.ACTION_OPEN = 'open'; // Open iframe
// iframe -> background -> content_script
exports.ACTION_CLOSE = 'close'; // Close iframe
exports.ACTION_RESIZE = 'resize'; // Resize iframe
// background -> iframe
exports.ACTION_POPULATE = 'populate'; // Pass background data to iframe after open
// content_script -> background or popup -> background
exports.ACTION_INIT = 'init'; // Initiate flow with data
// background -> content_script
exports.ACTION_FILL = 'fill';


/***/ }),

/***/ "./src/utils/Logger.ts":
/*!*****************************!*\
  !*** ./src/utils/Logger.ts ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * This module provides a custom logger to be used throughout the application.
 * It adds two primary features:
 *   1. Colored messages per logger instance with assigned names for increased
 *      readability. Uses a hash value of the assigned name to generate a color
 *      so that the same name will always have the same color for consistency.
 *   2. Single point of entry for logging, allows logging levels to be adjusted
 *      more easily later on so that logging can be toggled instead of being
 *      added/removed as needed.
 *
 * The console.log function can be used in two different ways. Either in a printf-like
 * manner where the first parameter is the message and subsequent parameters are variables;
 * or in a way where each parameter gets printed after the other.
 *   Since this logger uses the printf style to achieve colors, modules that use the logger
 * are also resticted to the printf-style. Meaning the first parameter is always the message
 * and subsequent parameters are variables which are injected into special characters in the
 * messages such as %o for object, %s for string and %d for number.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.StoredSafeLogger = void 0;
// Print this in front of all log messages
const PREFIX = 'StoredSafe';
// Base style for colored messages
const baseStyle = [
    'color: #fff',
    'background-color: #526A78',
    'padding: 2px 4px',
    'border-radius: 2px'
].join(';');
// Specific coloring for special tags, extends base style
const depthStyle = [baseStyle, 'background-color: #f59815'].join(';');
const tableStyle = [baseStyle, 'background-color: #D65780'].join(';');
/**
 * Wraps logging to print more informative messages to the console.
 */
class Logger {
    constructor(name, parent = exports.StoredSafeLogger) {
        this.groupDepth = 0;
        this.parent = null;
        this.name = name;
        this.parent = parent;
        this.enabled = this.parent === null ? true : this.parent.enabled;
        if (this.parent === null) {
            this.nameStyle = baseStyle;
        }
        else {
            // Generate a color based on the name to make it easy to identify
            const hash = this.name.split('').reduce((a, x) => a + x.charCodeAt(0), 0);
            const h = `${hash % 360}`;
            const s = `${(hash % 25) + 25}%`;
            const l = `${(hash % 20) + 40}%`;
            const color = `hsl(${h}, ${s}, ${l})`;
            this.nameStyle = [baseStyle, `background-color: ${color}`].join(';');
        }
    }
    /**
     * Helper function to determine whether an open console.group is active.
     */
    _isGrouped() {
        return this.groupDepth > 0;
    }
    _namePrefix() {
        let parentPrefix = '', parentStyle = [];
        if (this.parent !== null) {
            ;
            [parentPrefix, parentStyle] = this.parent._namePrefix();
        }
        return [`${parentPrefix}%c${this.name}`, [...parentStyle, this.nameStyle]];
    }
    /**
     * Helper function to generate colored tags.
     * Prints the application name, the module name and optionally a tag name and
     * then resets the style (or applies the provided style) for the actual message.
     * @param tag Extra tag to be added before message.
     * @param tagStyle Style for extra tag.
     * @param style Style of the message.
     */
    _prefix(tag = '', tagStyle = '', style = '') {
        const [namePrefix, nameStyle] = this._namePrefix();
        return [`${namePrefix}%c${tag}%c `, [...nameStyle, tagStyle, style]];
    }
    /**
     * Start a console group, causing an indented block for subsequent log messages.
     * Cancel with Logger.groupEnd.
     * @param title Title of the group for better readability.
     */
    group(title = '') {
        if (!this.enabled)
            return;
        this.groupDepth += 1;
        const [prefix, styles] = this._prefix(`G${this.groupDepth} - ${title}`, depthStyle);
        console.group(prefix, ...styles);
    }
    /**
     * Same as Logger.group, but start the group collapsed.
     * Cancel with Logger.groupEnd.
     * @param title Title of the group for better readability.
     */
    groupCollapsed(title = '') {
        if (!this.enabled)
            return;
        this.groupDepth += 1;
        const [prefix, styles] = this._prefix(`G${this.groupDepth} - ${title}`, depthStyle);
        console.groupCollapsed(prefix, ...styles);
    }
    /**
     * End a console group, reverting indentation of Logger.group.
     */
    groupEnd() {
        if (!this.enabled)
            return;
        if (this._isGrouped()) {
            this.groupDepth -= 1;
            console.groupEnd();
        }
    }
    /**
     * Send a standard log message to the console.
     * @param message Message to be logged.
     * @param variables Values to be injected into message.
     */
    log(message, ...variables) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix();
        console.log(prefix + message, ...styles, ...variables);
    }
    /**
     * Send an info message to the console.
     * @param message Message to be logged.
     * @param variables Values to be injected into message.
     */
    info(message, ...variables) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix();
        console.info(prefix + message, ...styles, ...variables);
    }
    /**
     * Send a warning message to the console.
     * @param message Message to be logged.
     * @param variables Values to be injected into message.
     */
    warn(message, ...variables) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix();
        console.warn(prefix + message, ...styles, ...variables);
    }
    /**
     * Send an error message to the console.
     * @param message Message to be logged.
     * @param variables Values to be injected into message.
     */
    error(message, ...variables) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix();
        console.error(prefix + message, ...styles, ...variables);
    }
    /**
     * Send a debug message to the console.
     * @param message Message to be logged.
     * @param variables Values to be injected into message.
     */
    debug(message, ...variables) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix();
        console.debug(prefix + message, ...styles, ...variables);
    }
    /**
     * Present an object as a table in the console.
     * @param obj Object to be presented.
     */
    table(obj) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix('table', tableStyle);
        console.log(prefix, ...styles);
        console.table(obj);
    }
    enable() {
        this.enabled = true;
    }
    disable() {
        this.enabled = false;
    }
}
exports.StoredSafeLogger = new Logger(PREFIX, null);
if (false) {}
exports.default = Logger;


/***/ }),

/***/ "./src/utils/StoredSafeError.ts":
/*!**************************************!*\
  !*** ./src/utils/StoredSafeError.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Wraps the standard Error to automatically name the error after
 * the extending class, providing more informative error messages.
 */
class StoredSafeError extends Error {
    constructor(message, error) {
        super(message);
        this.name = this.constructor.name;
        this.stack = error === null || error === void 0 ? void 0 : error.stack;
    }
}
exports.default = StoredSafeError;


/***/ })

/******/ });
//# sourceMappingURL=background.js.map