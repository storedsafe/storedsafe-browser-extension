/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/scripts/content_script.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/axios/index.js":
/*!*************************************!*\
  !*** ./node_modules/axios/index.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./lib/axios */ "./node_modules/axios/lib/axios.js");

/***/ }),

/***/ "./node_modules/axios/lib/adapters/xhr.js":
/*!************************************************!*\
  !*** ./node_modules/axios/lib/adapters/xhr.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var settle = __webpack_require__(/*! ./../core/settle */ "./node_modules/axios/lib/core/settle.js");
var buildURL = __webpack_require__(/*! ./../helpers/buildURL */ "./node_modules/axios/lib/helpers/buildURL.js");
var buildFullPath = __webpack_require__(/*! ../core/buildFullPath */ "./node_modules/axios/lib/core/buildFullPath.js");
var parseHeaders = __webpack_require__(/*! ./../helpers/parseHeaders */ "./node_modules/axios/lib/helpers/parseHeaders.js");
var isURLSameOrigin = __webpack_require__(/*! ./../helpers/isURLSameOrigin */ "./node_modules/axios/lib/helpers/isURLSameOrigin.js");
var createError = __webpack_require__(/*! ../core/createError */ "./node_modules/axios/lib/core/createError.js");

module.exports = function xhrAdapter(config) {
  return new Promise(function dispatchXhrRequest(resolve, reject) {
    var requestData = config.data;
    var requestHeaders = config.headers;

    if (utils.isFormData(requestData)) {
      delete requestHeaders['Content-Type']; // Let the browser set it
    }

    var request = new XMLHttpRequest();

    // HTTP basic authentication
    if (config.auth) {
      var username = config.auth.username || '';
      var password = config.auth.password || '';
      requestHeaders.Authorization = 'Basic ' + btoa(username + ':' + password);
    }

    var fullPath = buildFullPath(config.baseURL, config.url);
    request.open(config.method.toUpperCase(), buildURL(fullPath, config.params, config.paramsSerializer), true);

    // Set the request timeout in MS
    request.timeout = config.timeout;

    // Listen for ready state
    request.onreadystatechange = function handleLoad() {
      if (!request || request.readyState !== 4) {
        return;
      }

      // The request errored out and we didn't get a response, this will be
      // handled by onerror instead
      // With one exception: request that using file: protocol, most browsers
      // will return status as 0 even though it's a successful request
      if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf('file:') === 0)) {
        return;
      }

      // Prepare the response
      var responseHeaders = 'getAllResponseHeaders' in request ? parseHeaders(request.getAllResponseHeaders()) : null;
      var responseData = !config.responseType || config.responseType === 'text' ? request.responseText : request.response;
      var response = {
        data: responseData,
        status: request.status,
        statusText: request.statusText,
        headers: responseHeaders,
        config: config,
        request: request
      };

      settle(resolve, reject, response);

      // Clean up request
      request = null;
    };

    // Handle browser request cancellation (as opposed to a manual cancellation)
    request.onabort = function handleAbort() {
      if (!request) {
        return;
      }

      reject(createError('Request aborted', config, 'ECONNABORTED', request));

      // Clean up request
      request = null;
    };

    // Handle low level network errors
    request.onerror = function handleError() {
      // Real errors are hidden from us by the browser
      // onerror should only fire if it's a network error
      reject(createError('Network Error', config, null, request));

      // Clean up request
      request = null;
    };

    // Handle timeout
    request.ontimeout = function handleTimeout() {
      var timeoutErrorMessage = 'timeout of ' + config.timeout + 'ms exceeded';
      if (config.timeoutErrorMessage) {
        timeoutErrorMessage = config.timeoutErrorMessage;
      }
      reject(createError(timeoutErrorMessage, config, 'ECONNABORTED',
        request));

      // Clean up request
      request = null;
    };

    // Add xsrf header
    // This is only done if running in a standard browser environment.
    // Specifically not if we're in a web worker, or react-native.
    if (utils.isStandardBrowserEnv()) {
      var cookies = __webpack_require__(/*! ./../helpers/cookies */ "./node_modules/axios/lib/helpers/cookies.js");

      // Add xsrf header
      var xsrfValue = (config.withCredentials || isURLSameOrigin(fullPath)) && config.xsrfCookieName ?
        cookies.read(config.xsrfCookieName) :
        undefined;

      if (xsrfValue) {
        requestHeaders[config.xsrfHeaderName] = xsrfValue;
      }
    }

    // Add headers to the request
    if ('setRequestHeader' in request) {
      utils.forEach(requestHeaders, function setRequestHeader(val, key) {
        if (typeof requestData === 'undefined' && key.toLowerCase() === 'content-type') {
          // Remove Content-Type if data is undefined
          delete requestHeaders[key];
        } else {
          // Otherwise add header to the request
          request.setRequestHeader(key, val);
        }
      });
    }

    // Add withCredentials to request if needed
    if (!utils.isUndefined(config.withCredentials)) {
      request.withCredentials = !!config.withCredentials;
    }

    // Add responseType to request if needed
    if (config.responseType) {
      try {
        request.responseType = config.responseType;
      } catch (e) {
        // Expected DOMException thrown by browsers not compatible XMLHttpRequest Level 2.
        // But, this can be suppressed for 'json' type as it can be parsed by default 'transformResponse' function.
        if (config.responseType !== 'json') {
          throw e;
        }
      }
    }

    // Handle progress if needed
    if (typeof config.onDownloadProgress === 'function') {
      request.addEventListener('progress', config.onDownloadProgress);
    }

    // Not all browsers support upload events
    if (typeof config.onUploadProgress === 'function' && request.upload) {
      request.upload.addEventListener('progress', config.onUploadProgress);
    }

    if (config.cancelToken) {
      // Handle cancellation
      config.cancelToken.promise.then(function onCanceled(cancel) {
        if (!request) {
          return;
        }

        request.abort();
        reject(cancel);
        // Clean up request
        request = null;
      });
    }

    if (requestData === undefined) {
      requestData = null;
    }

    // Send the request
    request.send(requestData);
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/axios.js":
/*!*****************************************!*\
  !*** ./node_modules/axios/lib/axios.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./utils */ "./node_modules/axios/lib/utils.js");
var bind = __webpack_require__(/*! ./helpers/bind */ "./node_modules/axios/lib/helpers/bind.js");
var Axios = __webpack_require__(/*! ./core/Axios */ "./node_modules/axios/lib/core/Axios.js");
var mergeConfig = __webpack_require__(/*! ./core/mergeConfig */ "./node_modules/axios/lib/core/mergeConfig.js");
var defaults = __webpack_require__(/*! ./defaults */ "./node_modules/axios/lib/defaults.js");

/**
 * Create an instance of Axios
 *
 * @param {Object} defaultConfig The default config for the instance
 * @return {Axios} A new instance of Axios
 */
function createInstance(defaultConfig) {
  var context = new Axios(defaultConfig);
  var instance = bind(Axios.prototype.request, context);

  // Copy axios.prototype to instance
  utils.extend(instance, Axios.prototype, context);

  // Copy context to instance
  utils.extend(instance, context);

  return instance;
}

// Create the default instance to be exported
var axios = createInstance(defaults);

// Expose Axios class to allow class inheritance
axios.Axios = Axios;

// Factory for creating new instances
axios.create = function create(instanceConfig) {
  return createInstance(mergeConfig(axios.defaults, instanceConfig));
};

// Expose Cancel & CancelToken
axios.Cancel = __webpack_require__(/*! ./cancel/Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");
axios.CancelToken = __webpack_require__(/*! ./cancel/CancelToken */ "./node_modules/axios/lib/cancel/CancelToken.js");
axios.isCancel = __webpack_require__(/*! ./cancel/isCancel */ "./node_modules/axios/lib/cancel/isCancel.js");

// Expose all/spread
axios.all = function all(promises) {
  return Promise.all(promises);
};
axios.spread = __webpack_require__(/*! ./helpers/spread */ "./node_modules/axios/lib/helpers/spread.js");

module.exports = axios;

// Allow use of default import syntax in TypeScript
module.exports.default = axios;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/Cancel.js":
/*!*************************************************!*\
  !*** ./node_modules/axios/lib/cancel/Cancel.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * A `Cancel` is an object that is thrown when an operation is canceled.
 *
 * @class
 * @param {string=} message The message.
 */
function Cancel(message) {
  this.message = message;
}

Cancel.prototype.toString = function toString() {
  return 'Cancel' + (this.message ? ': ' + this.message : '');
};

Cancel.prototype.__CANCEL__ = true;

module.exports = Cancel;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/CancelToken.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/cancel/CancelToken.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var Cancel = __webpack_require__(/*! ./Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");

/**
 * A `CancelToken` is an object that can be used to request cancellation of an operation.
 *
 * @class
 * @param {Function} executor The executor function.
 */
function CancelToken(executor) {
  if (typeof executor !== 'function') {
    throw new TypeError('executor must be a function.');
  }

  var resolvePromise;
  this.promise = new Promise(function promiseExecutor(resolve) {
    resolvePromise = resolve;
  });

  var token = this;
  executor(function cancel(message) {
    if (token.reason) {
      // Cancellation has already been requested
      return;
    }

    token.reason = new Cancel(message);
    resolvePromise(token.reason);
  });
}

/**
 * Throws a `Cancel` if cancellation has been requested.
 */
CancelToken.prototype.throwIfRequested = function throwIfRequested() {
  if (this.reason) {
    throw this.reason;
  }
};

/**
 * Returns an object that contains a new `CancelToken` and a function that, when called,
 * cancels the `CancelToken`.
 */
CancelToken.source = function source() {
  var cancel;
  var token = new CancelToken(function executor(c) {
    cancel = c;
  });
  return {
    token: token,
    cancel: cancel
  };
};

module.exports = CancelToken;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/isCancel.js":
/*!***************************************************!*\
  !*** ./node_modules/axios/lib/cancel/isCancel.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function isCancel(value) {
  return !!(value && value.__CANCEL__);
};


/***/ }),

/***/ "./node_modules/axios/lib/core/Axios.js":
/*!**********************************************!*\
  !*** ./node_modules/axios/lib/core/Axios.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var buildURL = __webpack_require__(/*! ../helpers/buildURL */ "./node_modules/axios/lib/helpers/buildURL.js");
var InterceptorManager = __webpack_require__(/*! ./InterceptorManager */ "./node_modules/axios/lib/core/InterceptorManager.js");
var dispatchRequest = __webpack_require__(/*! ./dispatchRequest */ "./node_modules/axios/lib/core/dispatchRequest.js");
var mergeConfig = __webpack_require__(/*! ./mergeConfig */ "./node_modules/axios/lib/core/mergeConfig.js");

/**
 * Create a new instance of Axios
 *
 * @param {Object} instanceConfig The default config for the instance
 */
function Axios(instanceConfig) {
  this.defaults = instanceConfig;
  this.interceptors = {
    request: new InterceptorManager(),
    response: new InterceptorManager()
  };
}

/**
 * Dispatch a request
 *
 * @param {Object} config The config specific for this request (merged with this.defaults)
 */
Axios.prototype.request = function request(config) {
  /*eslint no-param-reassign:0*/
  // Allow for axios('example/url'[, config]) a la fetch API
  if (typeof config === 'string') {
    config = arguments[1] || {};
    config.url = arguments[0];
  } else {
    config = config || {};
  }

  config = mergeConfig(this.defaults, config);

  // Set config.method
  if (config.method) {
    config.method = config.method.toLowerCase();
  } else if (this.defaults.method) {
    config.method = this.defaults.method.toLowerCase();
  } else {
    config.method = 'get';
  }

  // Hook up interceptors middleware
  var chain = [dispatchRequest, undefined];
  var promise = Promise.resolve(config);

  this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
    chain.unshift(interceptor.fulfilled, interceptor.rejected);
  });

  this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
    chain.push(interceptor.fulfilled, interceptor.rejected);
  });

  while (chain.length) {
    promise = promise.then(chain.shift(), chain.shift());
  }

  return promise;
};

Axios.prototype.getUri = function getUri(config) {
  config = mergeConfig(this.defaults, config);
  return buildURL(config.url, config.params, config.paramsSerializer).replace(/^\?/, '');
};

// Provide aliases for supported request methods
utils.forEach(['delete', 'get', 'head', 'options'], function forEachMethodNoData(method) {
  /*eslint func-names:0*/
  Axios.prototype[method] = function(url, config) {
    return this.request(utils.merge(config || {}, {
      method: method,
      url: url
    }));
  };
});

utils.forEach(['post', 'put', 'patch'], function forEachMethodWithData(method) {
  /*eslint func-names:0*/
  Axios.prototype[method] = function(url, data, config) {
    return this.request(utils.merge(config || {}, {
      method: method,
      url: url,
      data: data
    }));
  };
});

module.exports = Axios;


/***/ }),

/***/ "./node_modules/axios/lib/core/InterceptorManager.js":
/*!***********************************************************!*\
  !*** ./node_modules/axios/lib/core/InterceptorManager.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

function InterceptorManager() {
  this.handlers = [];
}

/**
 * Add a new interceptor to the stack
 *
 * @param {Function} fulfilled The function to handle `then` for a `Promise`
 * @param {Function} rejected The function to handle `reject` for a `Promise`
 *
 * @return {Number} An ID used to remove interceptor later
 */
InterceptorManager.prototype.use = function use(fulfilled, rejected) {
  this.handlers.push({
    fulfilled: fulfilled,
    rejected: rejected
  });
  return this.handlers.length - 1;
};

/**
 * Remove an interceptor from the stack
 *
 * @param {Number} id The ID that was returned by `use`
 */
InterceptorManager.prototype.eject = function eject(id) {
  if (this.handlers[id]) {
    this.handlers[id] = null;
  }
};

/**
 * Iterate over all the registered interceptors
 *
 * This method is particularly useful for skipping over any
 * interceptors that may have become `null` calling `eject`.
 *
 * @param {Function} fn The function to call for each interceptor
 */
InterceptorManager.prototype.forEach = function forEach(fn) {
  utils.forEach(this.handlers, function forEachHandler(h) {
    if (h !== null) {
      fn(h);
    }
  });
};

module.exports = InterceptorManager;


/***/ }),

/***/ "./node_modules/axios/lib/core/buildFullPath.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/core/buildFullPath.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var isAbsoluteURL = __webpack_require__(/*! ../helpers/isAbsoluteURL */ "./node_modules/axios/lib/helpers/isAbsoluteURL.js");
var combineURLs = __webpack_require__(/*! ../helpers/combineURLs */ "./node_modules/axios/lib/helpers/combineURLs.js");

/**
 * Creates a new URL by combining the baseURL with the requestedURL,
 * only when the requestedURL is not already an absolute URL.
 * If the requestURL is absolute, this function returns the requestedURL untouched.
 *
 * @param {string} baseURL The base URL
 * @param {string} requestedURL Absolute or relative URL to combine
 * @returns {string} The combined full path
 */
module.exports = function buildFullPath(baseURL, requestedURL) {
  if (baseURL && !isAbsoluteURL(requestedURL)) {
    return combineURLs(baseURL, requestedURL);
  }
  return requestedURL;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/createError.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/core/createError.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var enhanceError = __webpack_require__(/*! ./enhanceError */ "./node_modules/axios/lib/core/enhanceError.js");

/**
 * Create an Error with the specified message, config, error code, request and response.
 *
 * @param {string} message The error message.
 * @param {Object} config The config.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 * @returns {Error} The created error.
 */
module.exports = function createError(message, config, code, request, response) {
  var error = new Error(message);
  return enhanceError(error, config, code, request, response);
};


/***/ }),

/***/ "./node_modules/axios/lib/core/dispatchRequest.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/core/dispatchRequest.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var transformData = __webpack_require__(/*! ./transformData */ "./node_modules/axios/lib/core/transformData.js");
var isCancel = __webpack_require__(/*! ../cancel/isCancel */ "./node_modules/axios/lib/cancel/isCancel.js");
var defaults = __webpack_require__(/*! ../defaults */ "./node_modules/axios/lib/defaults.js");

/**
 * Throws a `Cancel` if cancellation has been requested.
 */
function throwIfCancellationRequested(config) {
  if (config.cancelToken) {
    config.cancelToken.throwIfRequested();
  }
}

/**
 * Dispatch a request to the server using the configured adapter.
 *
 * @param {object} config The config that is to be used for the request
 * @returns {Promise} The Promise to be fulfilled
 */
module.exports = function dispatchRequest(config) {
  throwIfCancellationRequested(config);

  // Ensure headers exist
  config.headers = config.headers || {};

  // Transform request data
  config.data = transformData(
    config.data,
    config.headers,
    config.transformRequest
  );

  // Flatten headers
  config.headers = utils.merge(
    config.headers.common || {},
    config.headers[config.method] || {},
    config.headers
  );

  utils.forEach(
    ['delete', 'get', 'head', 'post', 'put', 'patch', 'common'],
    function cleanHeaderConfig(method) {
      delete config.headers[method];
    }
  );

  var adapter = config.adapter || defaults.adapter;

  return adapter(config).then(function onAdapterResolution(response) {
    throwIfCancellationRequested(config);

    // Transform response data
    response.data = transformData(
      response.data,
      response.headers,
      config.transformResponse
    );

    return response;
  }, function onAdapterRejection(reason) {
    if (!isCancel(reason)) {
      throwIfCancellationRequested(config);

      // Transform response data
      if (reason && reason.response) {
        reason.response.data = transformData(
          reason.response.data,
          reason.response.headers,
          config.transformResponse
        );
      }
    }

    return Promise.reject(reason);
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/core/enhanceError.js":
/*!*****************************************************!*\
  !*** ./node_modules/axios/lib/core/enhanceError.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Update an Error with the specified config, error code, and response.
 *
 * @param {Error} error The error to update.
 * @param {Object} config The config.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 * @returns {Error} The error.
 */
module.exports = function enhanceError(error, config, code, request, response) {
  error.config = config;
  if (code) {
    error.code = code;
  }

  error.request = request;
  error.response = response;
  error.isAxiosError = true;

  error.toJSON = function() {
    return {
      // Standard
      message: this.message,
      name: this.name,
      // Microsoft
      description: this.description,
      number: this.number,
      // Mozilla
      fileName: this.fileName,
      lineNumber: this.lineNumber,
      columnNumber: this.columnNumber,
      stack: this.stack,
      // Axios
      config: this.config,
      code: this.code
    };
  };
  return error;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/mergeConfig.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/core/mergeConfig.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");

/**
 * Config-specific merge-function which creates a new config-object
 * by merging two configuration objects together.
 *
 * @param {Object} config1
 * @param {Object} config2
 * @returns {Object} New object resulting from merging config2 to config1
 */
module.exports = function mergeConfig(config1, config2) {
  // eslint-disable-next-line no-param-reassign
  config2 = config2 || {};
  var config = {};

  var valueFromConfig2Keys = ['url', 'method', 'params', 'data'];
  var mergeDeepPropertiesKeys = ['headers', 'auth', 'proxy'];
  var defaultToConfig2Keys = [
    'baseURL', 'url', 'transformRequest', 'transformResponse', 'paramsSerializer',
    'timeout', 'withCredentials', 'adapter', 'responseType', 'xsrfCookieName',
    'xsrfHeaderName', 'onUploadProgress', 'onDownloadProgress',
    'maxContentLength', 'validateStatus', 'maxRedirects', 'httpAgent',
    'httpsAgent', 'cancelToken', 'socketPath'
  ];

  utils.forEach(valueFromConfig2Keys, function valueFromConfig2(prop) {
    if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    }
  });

  utils.forEach(mergeDeepPropertiesKeys, function mergeDeepProperties(prop) {
    if (utils.isObject(config2[prop])) {
      config[prop] = utils.deepMerge(config1[prop], config2[prop]);
    } else if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    } else if (utils.isObject(config1[prop])) {
      config[prop] = utils.deepMerge(config1[prop]);
    } else if (typeof config1[prop] !== 'undefined') {
      config[prop] = config1[prop];
    }
  });

  utils.forEach(defaultToConfig2Keys, function defaultToConfig2(prop) {
    if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    } else if (typeof config1[prop] !== 'undefined') {
      config[prop] = config1[prop];
    }
  });

  var axiosKeys = valueFromConfig2Keys
    .concat(mergeDeepPropertiesKeys)
    .concat(defaultToConfig2Keys);

  var otherKeys = Object
    .keys(config2)
    .filter(function filterAxiosKeys(key) {
      return axiosKeys.indexOf(key) === -1;
    });

  utils.forEach(otherKeys, function otherKeysDefaultToConfig2(prop) {
    if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    } else if (typeof config1[prop] !== 'undefined') {
      config[prop] = config1[prop];
    }
  });

  return config;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/settle.js":
/*!***********************************************!*\
  !*** ./node_modules/axios/lib/core/settle.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var createError = __webpack_require__(/*! ./createError */ "./node_modules/axios/lib/core/createError.js");

/**
 * Resolve or reject a Promise based on response status.
 *
 * @param {Function} resolve A function that resolves the promise.
 * @param {Function} reject A function that rejects the promise.
 * @param {object} response The response.
 */
module.exports = function settle(resolve, reject, response) {
  var validateStatus = response.config.validateStatus;
  if (!validateStatus || validateStatus(response.status)) {
    resolve(response);
  } else {
    reject(createError(
      'Request failed with status code ' + response.status,
      response.config,
      null,
      response.request,
      response
    ));
  }
};


/***/ }),

/***/ "./node_modules/axios/lib/core/transformData.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/core/transformData.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

/**
 * Transform the data for a request or a response
 *
 * @param {Object|String} data The data to be transformed
 * @param {Array} headers The headers for the request or response
 * @param {Array|Function} fns A single function or Array of functions
 * @returns {*} The resulting transformed data
 */
module.exports = function transformData(data, headers, fns) {
  /*eslint no-param-reassign:0*/
  utils.forEach(fns, function transform(fn) {
    data = fn(data, headers);
  });

  return data;
};


/***/ }),

/***/ "./node_modules/axios/lib/defaults.js":
/*!********************************************!*\
  !*** ./node_modules/axios/lib/defaults.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

var utils = __webpack_require__(/*! ./utils */ "./node_modules/axios/lib/utils.js");
var normalizeHeaderName = __webpack_require__(/*! ./helpers/normalizeHeaderName */ "./node_modules/axios/lib/helpers/normalizeHeaderName.js");

var DEFAULT_CONTENT_TYPE = {
  'Content-Type': 'application/x-www-form-urlencoded'
};

function setContentTypeIfUnset(headers, value) {
  if (!utils.isUndefined(headers) && utils.isUndefined(headers['Content-Type'])) {
    headers['Content-Type'] = value;
  }
}

function getDefaultAdapter() {
  var adapter;
  if (typeof XMLHttpRequest !== 'undefined') {
    // For browsers use XHR adapter
    adapter = __webpack_require__(/*! ./adapters/xhr */ "./node_modules/axios/lib/adapters/xhr.js");
  } else if (typeof process !== 'undefined' && Object.prototype.toString.call(process) === '[object process]') {
    // For node use HTTP adapter
    adapter = __webpack_require__(/*! ./adapters/http */ "./node_modules/axios/lib/adapters/xhr.js");
  }
  return adapter;
}

var defaults = {
  adapter: getDefaultAdapter(),

  transformRequest: [function transformRequest(data, headers) {
    normalizeHeaderName(headers, 'Accept');
    normalizeHeaderName(headers, 'Content-Type');
    if (utils.isFormData(data) ||
      utils.isArrayBuffer(data) ||
      utils.isBuffer(data) ||
      utils.isStream(data) ||
      utils.isFile(data) ||
      utils.isBlob(data)
    ) {
      return data;
    }
    if (utils.isArrayBufferView(data)) {
      return data.buffer;
    }
    if (utils.isURLSearchParams(data)) {
      setContentTypeIfUnset(headers, 'application/x-www-form-urlencoded;charset=utf-8');
      return data.toString();
    }
    if (utils.isObject(data)) {
      setContentTypeIfUnset(headers, 'application/json;charset=utf-8');
      return JSON.stringify(data);
    }
    return data;
  }],

  transformResponse: [function transformResponse(data) {
    /*eslint no-param-reassign:0*/
    if (typeof data === 'string') {
      try {
        data = JSON.parse(data);
      } catch (e) { /* Ignore */ }
    }
    return data;
  }],

  /**
   * A timeout in milliseconds to abort a request. If set to 0 (default) a
   * timeout is not created.
   */
  timeout: 0,

  xsrfCookieName: 'XSRF-TOKEN',
  xsrfHeaderName: 'X-XSRF-TOKEN',

  maxContentLength: -1,

  validateStatus: function validateStatus(status) {
    return status >= 200 && status < 300;
  }
};

defaults.headers = {
  common: {
    'Accept': 'application/json, text/plain, */*'
  }
};

utils.forEach(['delete', 'get', 'head'], function forEachMethodNoData(method) {
  defaults.headers[method] = {};
});

utils.forEach(['post', 'put', 'patch'], function forEachMethodWithData(method) {
  defaults.headers[method] = utils.merge(DEFAULT_CONTENT_TYPE);
});

module.exports = defaults;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../process/browser.js */ "./node_modules/process/browser.js")))

/***/ }),

/***/ "./node_modules/axios/lib/helpers/bind.js":
/*!************************************************!*\
  !*** ./node_modules/axios/lib/helpers/bind.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function bind(fn, thisArg) {
  return function wrap() {
    var args = new Array(arguments.length);
    for (var i = 0; i < args.length; i++) {
      args[i] = arguments[i];
    }
    return fn.apply(thisArg, args);
  };
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/buildURL.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/helpers/buildURL.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

function encode(val) {
  return encodeURIComponent(val).
    replace(/%40/gi, '@').
    replace(/%3A/gi, ':').
    replace(/%24/g, '$').
    replace(/%2C/gi, ',').
    replace(/%20/g, '+').
    replace(/%5B/gi, '[').
    replace(/%5D/gi, ']');
}

/**
 * Build a URL by appending params to the end
 *
 * @param {string} url The base of the url (e.g., http://www.google.com)
 * @param {object} [params] The params to be appended
 * @returns {string} The formatted url
 */
module.exports = function buildURL(url, params, paramsSerializer) {
  /*eslint no-param-reassign:0*/
  if (!params) {
    return url;
  }

  var serializedParams;
  if (paramsSerializer) {
    serializedParams = paramsSerializer(params);
  } else if (utils.isURLSearchParams(params)) {
    serializedParams = params.toString();
  } else {
    var parts = [];

    utils.forEach(params, function serialize(val, key) {
      if (val === null || typeof val === 'undefined') {
        return;
      }

      if (utils.isArray(val)) {
        key = key + '[]';
      } else {
        val = [val];
      }

      utils.forEach(val, function parseValue(v) {
        if (utils.isDate(v)) {
          v = v.toISOString();
        } else if (utils.isObject(v)) {
          v = JSON.stringify(v);
        }
        parts.push(encode(key) + '=' + encode(v));
      });
    });

    serializedParams = parts.join('&');
  }

  if (serializedParams) {
    var hashmarkIndex = url.indexOf('#');
    if (hashmarkIndex !== -1) {
      url = url.slice(0, hashmarkIndex);
    }

    url += (url.indexOf('?') === -1 ? '?' : '&') + serializedParams;
  }

  return url;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/combineURLs.js":
/*!*******************************************************!*\
  !*** ./node_modules/axios/lib/helpers/combineURLs.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Creates a new URL by combining the specified URLs
 *
 * @param {string} baseURL The base URL
 * @param {string} relativeURL The relative URL
 * @returns {string} The combined URL
 */
module.exports = function combineURLs(baseURL, relativeURL) {
  return relativeURL
    ? baseURL.replace(/\/+$/, '') + '/' + relativeURL.replace(/^\/+/, '')
    : baseURL;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/cookies.js":
/*!***************************************************!*\
  !*** ./node_modules/axios/lib/helpers/cookies.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

module.exports = (
  utils.isStandardBrowserEnv() ?

  // Standard browser envs support document.cookie
    (function standardBrowserEnv() {
      return {
        write: function write(name, value, expires, path, domain, secure) {
          var cookie = [];
          cookie.push(name + '=' + encodeURIComponent(value));

          if (utils.isNumber(expires)) {
            cookie.push('expires=' + new Date(expires).toGMTString());
          }

          if (utils.isString(path)) {
            cookie.push('path=' + path);
          }

          if (utils.isString(domain)) {
            cookie.push('domain=' + domain);
          }

          if (secure === true) {
            cookie.push('secure');
          }

          document.cookie = cookie.join('; ');
        },

        read: function read(name) {
          var match = document.cookie.match(new RegExp('(^|;\\s*)(' + name + ')=([^;]*)'));
          return (match ? decodeURIComponent(match[3]) : null);
        },

        remove: function remove(name) {
          this.write(name, '', Date.now() - 86400000);
        }
      };
    })() :

  // Non standard browser env (web workers, react-native) lack needed support.
    (function nonStandardBrowserEnv() {
      return {
        write: function write() {},
        read: function read() { return null; },
        remove: function remove() {}
      };
    })()
);


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isAbsoluteURL.js":
/*!*********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isAbsoluteURL.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Determines whether the specified URL is absolute
 *
 * @param {string} url The URL to test
 * @returns {boolean} True if the specified URL is absolute, otherwise false
 */
module.exports = function isAbsoluteURL(url) {
  // A URL is considered absolute if it begins with "<scheme>://" or "//" (protocol-relative URL).
  // RFC 3986 defines scheme name as a sequence of characters beginning with a letter and followed
  // by any combination of letters, digits, plus, period, or hyphen.
  return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(url);
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isURLSameOrigin.js":
/*!***********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isURLSameOrigin.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

module.exports = (
  utils.isStandardBrowserEnv() ?

  // Standard browser envs have full support of the APIs needed to test
  // whether the request URL is of the same origin as current location.
    (function standardBrowserEnv() {
      var msie = /(msie|trident)/i.test(navigator.userAgent);
      var urlParsingNode = document.createElement('a');
      var originURL;

      /**
    * Parse a URL to discover it's components
    *
    * @param {String} url The URL to be parsed
    * @returns {Object}
    */
      function resolveURL(url) {
        var href = url;

        if (msie) {
        // IE needs attribute set twice to normalize properties
          urlParsingNode.setAttribute('href', href);
          href = urlParsingNode.href;
        }

        urlParsingNode.setAttribute('href', href);

        // urlParsingNode provides the UrlUtils interface - http://url.spec.whatwg.org/#urlutils
        return {
          href: urlParsingNode.href,
          protocol: urlParsingNode.protocol ? urlParsingNode.protocol.replace(/:$/, '') : '',
          host: urlParsingNode.host,
          search: urlParsingNode.search ? urlParsingNode.search.replace(/^\?/, '') : '',
          hash: urlParsingNode.hash ? urlParsingNode.hash.replace(/^#/, '') : '',
          hostname: urlParsingNode.hostname,
          port: urlParsingNode.port,
          pathname: (urlParsingNode.pathname.charAt(0) === '/') ?
            urlParsingNode.pathname :
            '/' + urlParsingNode.pathname
        };
      }

      originURL = resolveURL(window.location.href);

      /**
    * Determine if a URL shares the same origin as the current location
    *
    * @param {String} requestURL The URL to test
    * @returns {boolean} True if URL shares the same origin, otherwise false
    */
      return function isURLSameOrigin(requestURL) {
        var parsed = (utils.isString(requestURL)) ? resolveURL(requestURL) : requestURL;
        return (parsed.protocol === originURL.protocol &&
            parsed.host === originURL.host);
      };
    })() :

  // Non standard browser envs (web workers, react-native) lack needed support.
    (function nonStandardBrowserEnv() {
      return function isURLSameOrigin() {
        return true;
      };
    })()
);


/***/ }),

/***/ "./node_modules/axios/lib/helpers/normalizeHeaderName.js":
/*!***************************************************************!*\
  !*** ./node_modules/axios/lib/helpers/normalizeHeaderName.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");

module.exports = function normalizeHeaderName(headers, normalizedName) {
  utils.forEach(headers, function processHeader(value, name) {
    if (name !== normalizedName && name.toUpperCase() === normalizedName.toUpperCase()) {
      headers[normalizedName] = value;
      delete headers[name];
    }
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/parseHeaders.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/parseHeaders.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

// Headers whose duplicates are ignored by node
// c.f. https://nodejs.org/api/http.html#http_message_headers
var ignoreDuplicateOf = [
  'age', 'authorization', 'content-length', 'content-type', 'etag',
  'expires', 'from', 'host', 'if-modified-since', 'if-unmodified-since',
  'last-modified', 'location', 'max-forwards', 'proxy-authorization',
  'referer', 'retry-after', 'user-agent'
];

/**
 * Parse headers into an object
 *
 * ```
 * Date: Wed, 27 Aug 2014 08:58:49 GMT
 * Content-Type: application/json
 * Connection: keep-alive
 * Transfer-Encoding: chunked
 * ```
 *
 * @param {String} headers Headers needing to be parsed
 * @returns {Object} Headers parsed into an object
 */
module.exports = function parseHeaders(headers) {
  var parsed = {};
  var key;
  var val;
  var i;

  if (!headers) { return parsed; }

  utils.forEach(headers.split('\n'), function parser(line) {
    i = line.indexOf(':');
    key = utils.trim(line.substr(0, i)).toLowerCase();
    val = utils.trim(line.substr(i + 1));

    if (key) {
      if (parsed[key] && ignoreDuplicateOf.indexOf(key) >= 0) {
        return;
      }
      if (key === 'set-cookie') {
        parsed[key] = (parsed[key] ? parsed[key] : []).concat([val]);
      } else {
        parsed[key] = parsed[key] ? parsed[key] + ', ' + val : val;
      }
    }
  });

  return parsed;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/spread.js":
/*!**************************************************!*\
  !*** ./node_modules/axios/lib/helpers/spread.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Syntactic sugar for invoking a function and expanding an array for arguments.
 *
 * Common use case would be to use `Function.prototype.apply`.
 *
 *  ```js
 *  function f(x, y, z) {}
 *  var args = [1, 2, 3];
 *  f.apply(null, args);
 *  ```
 *
 * With `spread` this example can be re-written.
 *
 *  ```js
 *  spread(function(x, y, z) {})([1, 2, 3]);
 *  ```
 *
 * @param {Function} callback
 * @returns {Function}
 */
module.exports = function spread(callback) {
  return function wrap(arr) {
    return callback.apply(null, arr);
  };
};


/***/ }),

/***/ "./node_modules/axios/lib/utils.js":
/*!*****************************************!*\
  !*** ./node_modules/axios/lib/utils.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var bind = __webpack_require__(/*! ./helpers/bind */ "./node_modules/axios/lib/helpers/bind.js");

/*global toString:true*/

// utils is a library of generic helper functions non-specific to axios

var toString = Object.prototype.toString;

/**
 * Determine if a value is an Array
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Array, otherwise false
 */
function isArray(val) {
  return toString.call(val) === '[object Array]';
}

/**
 * Determine if a value is undefined
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if the value is undefined, otherwise false
 */
function isUndefined(val) {
  return typeof val === 'undefined';
}

/**
 * Determine if a value is a Buffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Buffer, otherwise false
 */
function isBuffer(val) {
  return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor)
    && typeof val.constructor.isBuffer === 'function' && val.constructor.isBuffer(val);
}

/**
 * Determine if a value is an ArrayBuffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an ArrayBuffer, otherwise false
 */
function isArrayBuffer(val) {
  return toString.call(val) === '[object ArrayBuffer]';
}

/**
 * Determine if a value is a FormData
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an FormData, otherwise false
 */
function isFormData(val) {
  return (typeof FormData !== 'undefined') && (val instanceof FormData);
}

/**
 * Determine if a value is a view on an ArrayBuffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a view on an ArrayBuffer, otherwise false
 */
function isArrayBufferView(val) {
  var result;
  if ((typeof ArrayBuffer !== 'undefined') && (ArrayBuffer.isView)) {
    result = ArrayBuffer.isView(val);
  } else {
    result = (val) && (val.buffer) && (val.buffer instanceof ArrayBuffer);
  }
  return result;
}

/**
 * Determine if a value is a String
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a String, otherwise false
 */
function isString(val) {
  return typeof val === 'string';
}

/**
 * Determine if a value is a Number
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Number, otherwise false
 */
function isNumber(val) {
  return typeof val === 'number';
}

/**
 * Determine if a value is an Object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Object, otherwise false
 */
function isObject(val) {
  return val !== null && typeof val === 'object';
}

/**
 * Determine if a value is a Date
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Date, otherwise false
 */
function isDate(val) {
  return toString.call(val) === '[object Date]';
}

/**
 * Determine if a value is a File
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a File, otherwise false
 */
function isFile(val) {
  return toString.call(val) === '[object File]';
}

/**
 * Determine if a value is a Blob
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Blob, otherwise false
 */
function isBlob(val) {
  return toString.call(val) === '[object Blob]';
}

/**
 * Determine if a value is a Function
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Function, otherwise false
 */
function isFunction(val) {
  return toString.call(val) === '[object Function]';
}

/**
 * Determine if a value is a Stream
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Stream, otherwise false
 */
function isStream(val) {
  return isObject(val) && isFunction(val.pipe);
}

/**
 * Determine if a value is a URLSearchParams object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a URLSearchParams object, otherwise false
 */
function isURLSearchParams(val) {
  return typeof URLSearchParams !== 'undefined' && val instanceof URLSearchParams;
}

/**
 * Trim excess whitespace off the beginning and end of a string
 *
 * @param {String} str The String to trim
 * @returns {String} The String freed of excess whitespace
 */
function trim(str) {
  return str.replace(/^\s*/, '').replace(/\s*$/, '');
}

/**
 * Determine if we're running in a standard browser environment
 *
 * This allows axios to run in a web worker, and react-native.
 * Both environments support XMLHttpRequest, but not fully standard globals.
 *
 * web workers:
 *  typeof window -> undefined
 *  typeof document -> undefined
 *
 * react-native:
 *  navigator.product -> 'ReactNative'
 * nativescript
 *  navigator.product -> 'NativeScript' or 'NS'
 */
function isStandardBrowserEnv() {
  if (typeof navigator !== 'undefined' && (navigator.product === 'ReactNative' ||
                                           navigator.product === 'NativeScript' ||
                                           navigator.product === 'NS')) {
    return false;
  }
  return (
    typeof window !== 'undefined' &&
    typeof document !== 'undefined'
  );
}

/**
 * Iterate over an Array or an Object invoking a function for each item.
 *
 * If `obj` is an Array callback will be called passing
 * the value, index, and complete array for each item.
 *
 * If 'obj' is an Object callback will be called passing
 * the value, key, and complete object for each property.
 *
 * @param {Object|Array} obj The object to iterate
 * @param {Function} fn The callback to invoke for each item
 */
function forEach(obj, fn) {
  // Don't bother if no value provided
  if (obj === null || typeof obj === 'undefined') {
    return;
  }

  // Force an array if not already something iterable
  if (typeof obj !== 'object') {
    /*eslint no-param-reassign:0*/
    obj = [obj];
  }

  if (isArray(obj)) {
    // Iterate over array values
    for (var i = 0, l = obj.length; i < l; i++) {
      fn.call(null, obj[i], i, obj);
    }
  } else {
    // Iterate over object keys
    for (var key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        fn.call(null, obj[key], key, obj);
      }
    }
  }
}

/**
 * Accepts varargs expecting each argument to be an object, then
 * immutably merges the properties of each object and returns result.
 *
 * When multiple objects contain the same key the later object in
 * the arguments list will take precedence.
 *
 * Example:
 *
 * ```js
 * var result = merge({foo: 123}, {foo: 456});
 * console.log(result.foo); // outputs 456
 * ```
 *
 * @param {Object} obj1 Object to merge
 * @returns {Object} Result of all merge properties
 */
function merge(/* obj1, obj2, obj3, ... */) {
  var result = {};
  function assignValue(val, key) {
    if (typeof result[key] === 'object' && typeof val === 'object') {
      result[key] = merge(result[key], val);
    } else {
      result[key] = val;
    }
  }

  for (var i = 0, l = arguments.length; i < l; i++) {
    forEach(arguments[i], assignValue);
  }
  return result;
}

/**
 * Function equal to merge with the difference being that no reference
 * to original objects is kept.
 *
 * @see merge
 * @param {Object} obj1 Object to merge
 * @returns {Object} Result of all merge properties
 */
function deepMerge(/* obj1, obj2, obj3, ... */) {
  var result = {};
  function assignValue(val, key) {
    if (typeof result[key] === 'object' && typeof val === 'object') {
      result[key] = deepMerge(result[key], val);
    } else if (typeof val === 'object') {
      result[key] = deepMerge({}, val);
    } else {
      result[key] = val;
    }
  }

  for (var i = 0, l = arguments.length; i < l; i++) {
    forEach(arguments[i], assignValue);
  }
  return result;
}

/**
 * Extends object a by mutably adding to it the properties of object b.
 *
 * @param {Object} a The object to be extended
 * @param {Object} b The object to copy properties from
 * @param {Object} thisArg The object to bind function to
 * @return {Object} The resulting value of object a
 */
function extend(a, b, thisArg) {
  forEach(b, function assignValue(val, key) {
    if (thisArg && typeof val === 'function') {
      a[key] = bind(val, thisArg);
    } else {
      a[key] = val;
    }
  });
  return a;
}

module.exports = {
  isArray: isArray,
  isArrayBuffer: isArrayBuffer,
  isBuffer: isBuffer,
  isFormData: isFormData,
  isArrayBufferView: isArrayBufferView,
  isString: isString,
  isNumber: isNumber,
  isObject: isObject,
  isUndefined: isUndefined,
  isDate: isDate,
  isFile: isFile,
  isBlob: isBlob,
  isFunction: isFunction,
  isStream: isStream,
  isURLSearchParams: isURLSearchParams,
  isStandardBrowserEnv: isStandardBrowserEnv,
  forEach: forEach,
  merge: merge,
  deepMerge: deepMerge,
  extend: extend,
  trim: trim
};


/***/ }),

/***/ "./node_modules/process/browser.js":
/*!*****************************************!*\
  !*** ./node_modules/process/browser.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),

/***/ "./node_modules/storedsafe/dist/index.js":
/*!***********************************************!*\
  !*** ./node_modules/storedsafe/dist/index.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable @typescript-eslint/member-delimiter-style */
var axios_1 = __importDefault(__webpack_require__(/*! axios */ "./node_modules/axios/index.js"));
var LoginType;
(function (LoginType) {
    LoginType["TOTP"] = "totp";
    LoginType["SMARTCARD"] = "smc_rest";
})(LoginType = exports.LoginType || (exports.LoginType = {}));
var StoredSafe = /** @class */ (function () {
    function StoredSafe(_a, version) {
        var host = _a.host, apikey = _a.apikey, token = _a.token;
        if (version === void 0) { version = '1.0'; }
        this.axios = axios_1.default.create({
            baseURL: "https://" + host + "/api/" + version + "/",
            timeout: 5000
        });
        this.apikey = apikey;
        this.token = token;
    }
    StoredSafe.prototype.assertApikeyExists = function () {
        if (this.apikey === undefined) {
            throw new Error('Path requires apikey, apikey is undefined.');
        }
    };
    StoredSafe.prototype.assertTokenExists = function () {
        if (this.token === undefined) {
            throw new Error('Path requires token, token is undefined.');
        }
    };
    StoredSafe.prototype.loginYubikey = function (username, passphrase, otp) {
        var _this = this;
        this.assertApikeyExists();
        return this.axios
            .post('/auth', {
            username: username,
            keys: "" + passphrase + this.apikey + otp
        })
            .then(function (response) {
            _this.token = response.data.CALLINFO.token;
            return response;
        });
    };
    StoredSafe.prototype.loginTotp = function (username, passphrase, otp) {
        var _this = this;
        this.assertApikeyExists();
        return this.axios
            .post('/auth', {
            username: username,
            passphrase: passphrase,
            otp: otp,
            logintype: LoginType.TOTP,
            apikey: this.apikey
        })
            .then(function (response) {
            _this.token = response.data.CALLINFO.token;
            return response;
        });
    };
    StoredSafe.prototype.logout = function () {
        var _this = this;
        this.assertTokenExists();
        return this.axios
            .get('/auth/logout', {
            headers: { 'X-Http-Token': this.token }
        })
            .then(function (response) {
            _this.token = undefined;
            return response;
        });
    };
    StoredSafe.prototype.check = function () {
        this.assertTokenExists();
        return this.axios.post('/auth/check', {}, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.listVaults = function () {
        this.assertTokenExists();
        return this.axios.get('/vault', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.vaultObjects = function (id) {
        this.assertTokenExists();
        return this.axios.get("/vault/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.vaultMembers = function (id) {
        this.assertTokenExists();
        return this.axios.get("/vault/" + id + "/members", {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.createVault = function (params) {
        this.assertTokenExists();
        return this.axios.post('/vault', __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.editVault = function (id, params) {
        this.assertTokenExists();
        return this.axios.put("/vault/" + id, __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.deleteVault = function (id) {
        this.assertTokenExists();
        return this.axios.delete("/vault/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.getObject = function (id, children) {
        if (children === void 0) { children = false; }
        this.assertTokenExists();
        return this.axios.get("/object/" + id, {
            params: { children: children },
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.decryptObject = function (id) {
        this.assertTokenExists();
        return this.axios.get("/object/" + id, {
            params: { decrypt: true },
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.createObject = function (params) {
        this.assertTokenExists();
        return this.axios.post('/object', __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.editObject = function (id, params) {
        this.assertTokenExists();
        return this.axios.put("/object/" + id, __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.deleteObject = function (id) {
        this.assertTokenExists();
        return this.axios.delete("/object/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.find = function (needle) {
        this.assertTokenExists();
        return this.axios.get('/find', {
            params: { needle: needle },
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.listTemplates = function () {
        this.assertTokenExists();
        return this.axios.get('/template', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.getTemplate = function (id) {
        this.assertTokenExists();
        return this.axios.get("/template/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.statusValues = function () {
        this.assertTokenExists();
        return this.axios.get('/utils/statusvalues', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.passwordPolicies = function () {
        this.assertTokenExists();
        return this.axios.get('/utils/policies', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.version = function () {
        this.assertTokenExists();
        return this.axios.get('/utils/version', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.generatePassword = function (params) {
        if (params === void 0) { params = {}; }
        this.assertTokenExists();
        return this.axios.get('utils/pwgen', {
            headers: { 'X-Http-Token': this.token },
            params: params
        });
    };
    return StoredSafe;
}());
exports.default = StoredSafe;


/***/ }),

/***/ "./src/model/storage/Sessions.ts":
/*!***************************************!*\
  !*** ./src/model/storage/Sessions.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting StoredSafe
 * sessions as a means of indicating whether a user is logged into a site or
 * not. The extension background script is expected to set/clear this storage
 * area as a user performs a login/logout action or when a session times out.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = exports.parse = void 0;
const storageTools_1 = __webpack_require__(/*! ./storageTools */ "./src/model/storage/storageTools.ts");
/**
 * Parse serialized sessions from storage.
 * @param sessions - Serializable sessions from storage
 */
function parse(sessions) {
    return new Map(sessions === undefined ? [] : sessions);
}
exports.parse = parse;
/**
 * Get sessions from local storage.
 * @returns Promise containing all currently active sessions.
 * */
async function get() {
    const { sessions } = await browser.storage.local.get('sessions');
    return parse(sessions);
}
/**
 * Commit Sessions object to sync storage.
 * @param sessions - All currently active sessions.
 * @returns Empty promise.
 * */
async function set(sessions) {
    return await browser.storage.local.set({
        sessions: [...sessions]
    });
}
/// /////////////////////////////////////////////////////////
// Actions
/**
 * Add new session to storage.
 * @param host - Host that the session is associated with.
 * @param session - New session data.
 * @returns Updated active sessions.
 * */
async function add(host, session) {
    const sessions = await get();
    const newSessions = new Map([...sessions, [host, session]]);
    return await set(newSessions).then(get);
}
/**
 * Remove sessions from storage.
 * @param hosts - Hosts that the sessions are associated with.
 * @returns Updated active sessions.
 * */
async function remove(...hosts) {
    const sessions = await get();
    const newSessions = new Map(sessions);
    for (const host of hosts) {
        newSessions.delete(host);
    }
    return await set(newSessions).then(get);
}
const onChanged = new storageTools_1.StorageChangeListener('sessions', get, ['local']);
/**
 * Clear all sessions.
 * @returns Updated active sessions (empty).
 * */
async function clear() {
    return await set(new Map([])).then(get);
}
exports.actions = {
    add,
    remove,
    clear,
    fetch: get,
    onChanged
};


/***/ }),

/***/ "./src/model/storage/storageTools.ts":
/*!*******************************************!*\
  !*** ./src/model/storage/storageTools.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StorageChangeListener = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../../utils/Logger */ "./src/utils/Logger.ts"));
class StorageChangeListener {
    constructor(key, get, areas = ['local', 'sync', 'managed']) {
        this.listeners = [];
        // Make sure JS remembers what `this` is
        this.notify = this.notify.bind(this);
        this.onChanged = this.onChanged.bind(this);
        this.addListener = this.addListener.bind(this);
        this.removeListener = this.removeListener.bind(this);
        this.logger = new Logger_1.default(`StorageChange - ${key}`);
        this.key = key;
        this.areas = areas;
        this.get = get;
        // Subscribe to changes in storage
        browser.storage.onChanged.addListener(this.onChanged);
    }
    async notify() {
        try {
            const values = await this.get();
            for (const listener of this.listeners) {
                listener(values);
            }
        }
        catch (error) {
            this.logger.error('Error pushing `%s` change from storage. %o', this.key, error);
        }
    }
    onChanged(changes, areaName) {
        if (this.areas.includes(areaName) && changes.hasOwnProperty(this.key)) {
            void (async () => {
                await this.notify();
            })();
        }
    }
    addListener(listener) {
        if (!this.listeners.includes(listener))
            this.listeners.push(listener);
    }
    removeListener(listener) {
        const index = this.listeners.indexOf(listener);
        if (index !== -1) {
            this.listeners.splice(index, 1);
        }
    }
}
exports.StorageChangeListener = StorageChangeListener;


/***/ }),

/***/ "./src/model/storedsafe/AuthHandler.ts":
/*!*********************************************!*\
  !*** ./src/model/storedsafe/AuthHandler.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * Login to StoredSafe.
 * @param request - Request callback function.
 * @param fields - Credentials and specification of login type.
 * @returns Session created from response if successful.
 * */
async function login(request, fields) {
    const data = (await request(async (handler) => {
        let promise;
        if (fields.loginType === 'yubikey') {
            const { username, keys } = fields;
            const passphrase = keys.slice(0, -44);
            const otp = keys.slice(-44);
            promise = handler.loginYubikey(username, passphrase, otp);
        }
        else {
            // if (fields.loginType === 'totp') {
            const { username, passphrase, otp } = fields;
            promise = handler.loginTotp(username, passphrase, otp);
        }
        return await promise;
    }));
    const { token, audit, timeout } = data.CALLINFO;
    const violations = Array.isArray(audit.violations) ? {} : audit.violations;
    const warnings = Array.isArray(audit.warnings) ? {} : audit.warnings;
    return {
        token,
        createdAt: Date.now(),
        violations,
        warnings,
        timeout
    };
}
/**
 * Logout from StoredSafe
 * @param request - Request callback function.
 * @param host - Host related to the session to invalidate.
 * */
async function logout(request) {
    await request(async (handler) => await handler.logout());
}
/**
 * Check if token is still valid and refresh the token if it is.
 * @param request - Request callback function.
 * @returns True if token is still valid, otherwise false.
 * */
async function check(request) {
    try {
        await request(async (handler) => await handler.check());
        return true;
    }
    catch (error) {
        if (error.message.match('StoredSafe') !== null) {
            return false;
        }
        throw error;
    }
}
exports.actions = {
    login,
    logout,
    check
};


/***/ }),

/***/ "./src/model/storedsafe/MiscHandler.ts":
/*!*********************************************!*\
  !*** ./src/model/storedsafe/MiscHandler.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * Get the available vaults from the given site.
 * @param request - Request callback function.
 * @returns All available StoredSafe vaults on the host.
 * */
async function getVaults(request) {
    var _a, _b;
    let data;
    try {
        data = (await request(async (handler) => await handler.listVaults()));
    }
    catch (error) {
        // NOTE: If vault list is empty, StoredSafe sends 404
        if (((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) !== undefined) {
            data = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data;
        }
        else {
            throw error;
        }
    }
    return data.VAULTS.map(vault => ({
        id: vault.id,
        name: vault.groupname,
        canWrite: ['2', '4'].includes(vault.status) // Write or Admin
    }));
}
/**
 * Get the available templates from the given site.
 * @param request - Request callback function.
 * @returns All available StoredSafe templates on the host.
 * */
async function getTemplates(request) {
    const data = (await request(async (handler) => await handler.listTemplates()));
    const templates = [];
    for (const template of data.TEMPLATE) {
        if (template.INFO.file !== undefined)
            continue;
        templates.push({
            id: template.INFO.id,
            name: template.INFO.name,
            icon: template.INFO.ico,
            structure: Object.keys(template.STRUCTURE).map(fieldName => {
                const field = template.STRUCTURE[fieldName];
                return {
                    title: field.translation,
                    name: fieldName,
                    type: field.type,
                    isEncrypted: field.encrypted
                };
            })
        });
    }
    return templates;
}
/**
 * Generate a new password.
 * @param request - Request callback function.
 * @param params - Optional parameters for password generation.
 * @returns Generated password.
 * */
async function generatePassword(request, params) {
    const data = (await request(async (handler) => await handler.generatePassword(params)));
    return data.CALLINFO.passphrase;
}
exports.actions = {
    getVaults,
    getTemplates,
    generatePassword
};


/***/ }),

/***/ "./src/model/storedsafe/ObjectHandler.ts":
/*!***********************************************!*\
  !*** ./src/model/storedsafe/ObjectHandler.ts ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * Helper function to parse objects and templates returned from a find request.
 * @param ssObject StoredSafe object.
 * @param @ssTemplate StoredSafe template.
 * @param isDecrypted Whether the object has just been decrypted.
 * @returns Parsed representation of object and template info.
 * */
const parseSearchResult = (host, ssObject, ssTemplate, isDecrypted = false) => {
    // Extract general object info
    const name = ssObject.objectname;
    const { id, templateid: templateId, groupid: vaultId } = ssObject;
    const { name: type, ico: icon } = ssTemplate.info;
    const fields = [];
    // Extract field info from template
    ssTemplate.structure.forEach(field => {
        const { fieldname: fieldName, translation: title, encrypted: isEncrypted, policy: isPassword } = field;
        // Value may be undefined if the field is encrypted
        const value = isEncrypted
            ? isDecrypted
                ? ssObject.crypted[field.fieldname]
                : undefined
            : ssObject.public[field.fieldname];
        // Add field to object fields
        fields.push({
            name: fieldName,
            title,
            value,
            isEncrypted,
            isPassword
        });
    });
    // Compile all parsed information
    return {
        host,
        id,
        templateId,
        vaultId,
        name,
        type,
        icon,
        isDecrypted,
        fields
    };
};
// Only include templates that contain these fields
const includeFields = ['password', 'pincode'];
// Exclude templates that contain these fields
const excludeFields = ['file1'];
/**
 * Find and parse StoredSafe objects matching the provided needle.
 * @param request - Request callback function.
 * @param needle - Search string to match against in StoredSafe.
 * @returns Results matching needle.
 * */
async function find(request, needle, host) {
    const data = (await request(async (handler) => await handler.find(needle)));
    const results = [];
    for (let i = 0; i < data.OBJECT.length; i++) {
        const ssObject = data.OBJECT[i];
        const ssTemplate = data.TEMPLATES.find(template => template.id === ssObject.templateid);
        if (ssTemplate.structure.findIndex(field => includeFields.includes(field.fieldname)) === -1 ||
            ssTemplate.structure.findIndex(field => excludeFields.includes(field.fieldname)) !== -1) {
            continue;
        }
        results.push(parseSearchResult(host, ssObject, ssTemplate));
    }
    return results;
}
/**
 * Decrypt StoredSafe object.
 * @param request - Request callback function.
 * @param objectId - ID in StoredSafe of object to decrypt.
 * @returns The decrypted object.
 * */
async function decrypt(request, objectId, host) {
    const data = (await request(async (handler) => await handler.decryptObject(objectId)));
    const ssObject = data.OBJECT.find(obj => obj.id === objectId);
    const ssTemplate = data.TEMPLATES.find(template => template.id === ssObject.templateid);
    return parseSearchResult(host, ssObject, ssTemplate, true);
}
/**
 * Add object to StoredSafe.
 * @param request - Request callback function.
 * @param params - Object parameters based on the chosen StoredSafe template.
 * */
async function add(request, params) {
    await request(async (handler) => await handler.createObject(params));
}
exports.actions = {
    find,
    decrypt,
    add
};


/***/ }),

/***/ "./src/model/storedsafe/StoredSafe.ts":
/*!********************************************!*\
  !*** ./src/model/storedsafe/StoredSafe.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for the StoredSafe API wrapper to handle writing
 * relevant data to storage and parsing the raw StoredSafe response into
 * the more relevant application data structures.
 * - actions object provides the public interface for the model.
 * */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
const storedsafe_1 = __importDefault(__webpack_require__(/*! storedsafe */ "./node_modules/storedsafe/dist/index.js"));
const Sessions_1 = __webpack_require__(/*! ../storage/Sessions */ "./src/model/storage/Sessions.ts");
const ObjectHandler_1 = __webpack_require__(/*! ./ObjectHandler */ "./src/model/storedsafe/ObjectHandler.ts");
const AuthHandler_1 = __webpack_require__(/*! ./AuthHandler */ "./src/model/storedsafe/AuthHandler.ts");
const MiscHandler_1 = __webpack_require__(/*! ./MiscHandler */ "./src/model/storedsafe/MiscHandler.ts");
/**
 * Helper function to handle errors when interacting with the StoredSafe API.
 * All StoredSafe requests with errors will look similar and therefore be
 * handled the same way.
 * @param promise - Promise returned by StoredSafe request.
 * @returns Data returned by StoredSafe or promise with error.
 * */
async function handleErrors(promise) {
    var _a, _b, _c;
    try {
        const response = await promise;
        return response.data;
    }
    catch (error) {
        if (((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) !== undefined) {
            const data = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data;
            if (((_c = data.ERRORS) === null || _c === void 0 ? void 0 : _c.length) > 0) {
                const errors = data.ERRORS.join(' | ');
                throw new Error(`StoredSafe Error: ${errors}`);
            }
            if (data.ERRORCODES !== undefined && Object.keys(data.ERRORCODES).length > 0) {
                const errors = Object.values(data.ERRORCODES).join(' | ');
                throw new Error(`StoredSafe Error: ${errors}`);
            }
            // Server sent error code but no error response (see 404 for empty vaults)
            throw error;
        }
        else if (error.request !== undefined) {
            const { status, statusText } = error.request;
            console.error('StoredSafe network error: ', error);
            throw new Error(`Network Error, unable to connect to host.`);
        }
        const message = error.message;
        throw new Error(`Unexpected Error: ${message}`);
    }
}
/**
 * Get StoredSafe handler for the given host.
 * @param host - Host to connect to.
 * @returns StoredSafe handler or promise with error if no session was found.
 * */
async function getHandler(host) {
    const sessions = await Sessions_1.actions.fetch();
    if (sessions.get(host) === undefined) {
        throw new Error(`No active session for ${host}`);
    }
    const { token } = sessions.get(host);
    return new storedsafe_1.default({ host, token });
}
/**
 * Create and perform initial handling of request.
 * @param host - Host to create handler callback for.
 * @returns Request function to be passed to sub-handlers.
 * */
function makeRequest(host) {
    return async (cb) => await handleErrors(getHandler(host).then(async (handler) => await cb(handler)));
}
/// /////////////////////////////////////////////////////////
// auth
/**
 * Attempt login with given site.
 * @param site - Site to attempt login with.
 * @param fields - Credentials and specification of login type.
 * @returns Updated list of active sessions (if login is successful).
 * */
async function login({ host, apikey }, fields) {
    const handler = new storedsafe_1.default({ host, apikey });
    const request = async (cb) => await handleErrors(cb(handler));
    const session = await AuthHandler_1.actions.login(request, fields);
    return await Sessions_1.actions.add(host, session);
}
/**
 * Logout from given site.
 * Will silently remove session even if logout fails.
 * @param host - Host related to the session to invalidate.
 * @returns Updated list of active sessions.
 * */
async function logout(host) {
    try {
        await AuthHandler_1.actions.logout(makeRequest(host));
    }
    catch (error) {
        console.error('StoredSafe Logout Error', error);
    }
    return await Sessions_1.actions.remove(host);
}
/**
 * Logout from all sites.
 * Will silently remove sessions even if logout fails.
 * @returns Updated list of active sessions (empty).
 * */
async function logoutAll() {
    const sessions = await Sessions_1.actions.fetch();
    [...sessions.keys()].forEach(host => {
        AuthHandler_1.actions.logout(makeRequest(host)).catch(error => {
            console.error('StoredSafe Logout Error', error);
        });
    });
    return await Sessions_1.actions.clear();
}
/**
 * Check if session is still valid, remove it if it's not.
 * @param host - Host related to the session to validate.
 * @returns Updated list of active sessions.
 * */
async function check(host) {
    const isValid = await AuthHandler_1.actions.check(makeRequest(host));
    return isValid
        ? await Sessions_1.actions.fetch()
        : await Sessions_1.actions.remove(host);
}
/**
 * Check if sessions are still valid, remove those that are not.
 * @returns Updated list of active sessions.
 * */
async function checkAll() {
    const sessions = await Sessions_1.actions.fetch();
    const invalidHosts = [];
    for (const host of sessions.keys()) {
        const isValid = await AuthHandler_1.actions.check(makeRequest(host));
        if (!isValid) {
            invalidHosts.push(host);
        }
    }
    if (invalidHosts.length > 0) {
        return await Sessions_1.actions.remove(...invalidHosts);
    }
    return sessions;
}
/// /////////////////////////////////////////////////////////
// object
/**
 * Find search results from given sites.
 * @param host - Host to perform search on.
 * @param needle - Search string to match against in StoredSafe.
 * @returns Matched results from host.
 * */
async function find(host, needle) {
    return await ObjectHandler_1.actions.find(makeRequest(host), needle, host);
}
/**
 * Decrypt StoredSafe object.
 * @param host - Host to request decryption from.
 * @param objectId - ID in StoredSafe of object to decrypt.
 * @returns The decrypted object.
 * */
async function decrypt(host, objectId) {
    return await ObjectHandler_1.actions.decrypt(makeRequest(host), objectId, host);
}
/**
 * Add object to StoredSafe.
 * @param host - Host to add object to.
 * @param params - Object parameters based on the chosen StoredSafe template.
 * */
async function addObject(host, params) {
    return await ObjectHandler_1.actions.add(makeRequest(host), params);
}
/// /////////////////////////////////////////////////////////
// misc
/**
 * Get info about site structure and capabilities.
 * @param host - Host to retreive info about.
 * @returns - Info regarding the structure of the site.
 * */
async function getSiteInfo(host) {
    const handler = await getHandler(host);
    const request = async (cb) => await handleErrors(cb(handler));
    const vaults = await MiscHandler_1.actions.getVaults(request);
    const templates = await MiscHandler_1.actions.getTemplates(request);
    return { vaults, templates };
}
/**
 * Generate a new password.
 * @param host - Host to request a password from.
 * @param params - Optional parameters for password generation.
 * @returns Generated password.
 * */
async function generatePassword(host, params) {
    return await MiscHandler_1.actions.generatePassword(makeRequest(host), params);
}
exports.actions = {
    login,
    logout,
    logoutAll,
    check,
    checkAll,
    find,
    decrypt,
    addObject,
    getSiteInfo,
    generatePassword
};


/***/ }),

/***/ "./src/scripts/content_script.ts":
/*!***************************************!*\
  !*** ./src/scripts/content_script.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../utils/Logger */ "./src/utils/Logger.ts"));
exports.logger = new Logger_1.default('Content');
const MessageHandler_1 = __webpack_require__(/*! ./content_script/messages/MessageHandler */ "./src/scripts/content_script/messages/MessageHandler.ts");
const PageScanner_1 = __webpack_require__(/*! ./content_script/forms/PageScanner */ "./src/scripts/content_script/forms/PageScanner.ts");
const matchers_1 = __webpack_require__(/*! ./content_script/forms/matchers */ "./src/scripts/content_script/forms/matchers.ts");
exports.logger.log('Content script initialized: ', new Date(Date.now()));
const pageScanner = new PageScanner_1.PageScanner();
const messageHandler = new MessageHandler_1.MessageHandler(pageScanner);
// TODO: Create SubmitHandler for code below
/**
 * Set up submit events when the forms update.
 * TODO: Cleanup events
 * @param forms Newly updated forms.
 */
function onPageScan(forms) {
    let hasFillType = false;
    for (const [element, values] of forms) {
        if (matchers_1.FILL_TYPES.includes(values.type))
            hasFillType = true;
        const inputs = values.inputElements;
        let submitted = false; // lock for onSubmit
        /**
         * Send submit message to background script to see if a save flow should
         * be started.
         * Locks the onSubmit for 100ms to prevent multiple submit events being
         * pushed as a consequence of having to track click events on buttons in
         * addition to submit events because some sites do not use actual forms
         * and submit events.
         *
         * NOTE: This could be done in a way such that all submit handlers are
         * disconnected on submit, but this would block new events from triggering
         * in the case where a user entered the wrong password and then tries again.
         */
        function onSubmit() {
            // Check lock status
            if (submitted)
                return;
            submitted = true;
            // Check if form is of a type that should be saved
            if (!matchers_1.SAVE_TYPES.includes(values.type))
                return;
            const submitLogger = new Logger_1.default(`Submit - ${values.type}`, exports.logger);
            // TODO: Check cases where overlapping inputs exist (ex register confirm pass)
            let data = [];
            for (const [input, inputType] of inputs) {
                data.push([inputType, input.value]);
            }
            submitLogger.debug('Submitted data from fields %o in %o:', data.map(([field]) => field), element);
            messageHandler.sendSubmit(data);
            window.setTimeout(() => (submitted = false), 100);
        }
        element.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                onSubmit();
            }
        });
        const formsLogger = new Logger_1.default(`Form - ${values.type}`, exports.logger);
        formsLogger.debug('Form: %o, Type: %s, Inputs: %o, Buttons: %o', element, values.type, values.inputElements, values.submitElements);
        if (element instanceof HTMLFormElement) {
            element.addEventListener('submit', () => {
                onSubmit();
            });
        }
        for (const submitElement of values.submitElements) {
            submitElement.addEventListener('click', () => {
                onSubmit();
            });
        }
    }
    if (hasFillType) {
        messageHandler.sendOfferAutoFill();
    }
}
onPageScan(pageScanner.forms);
pageScanner.subscribeToMutations(onPageScan);


/***/ }),

/***/ "./src/scripts/content_script/forms/PageScanner.ts":
/*!*********************************************************!*\
  !*** ./src/scripts/content_script/forms/PageScanner.ts ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PageScanner = void 0;
const _1 = __webpack_require__(/*! . */ "./src/scripts/content_script/forms/index.ts");
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const matchers_1 = __webpack_require__(/*! ./matchers */ "./src/scripts/content_script/forms/matchers.ts");
const constants_1 = __webpack_require__(/*! ./constants */ "./src/scripts/content_script/forms/constants.ts");
const formsTools_1 = __webpack_require__(/*! ./formsTools */ "./src/scripts/content_script/forms/formsTools.ts");
const logger = new Logger_1.default('Page Scanner', _1.logger);
const ELEMENT_SELECTORS = [
    'input',
    'button' // type=submit query doesn't work on default type
].join(',');
const SUBMIT_MATCHER = /login|signin|submit/i;
class StoredSafePageScannerError extends StoredSafeError_1.default {
}
/**
 * Scans page to find all forms or pseudo-forms (forms not encased in a form-element).
 * Also uses a MutationObserver to detect changes in the DOM so that forms that are
 * loaded late can be found.
 */
class PageScanner {
    constructor() {
        this.forms = new Map();
        this.observer = null;
        // Make sure JS remembers what `this` is
        this.filterSubmits = this.filterSubmits.bind(this);
        this.findForms = this.findForms.bind(this);
        this.findPseudoForms = this.findPseudoForms.bind(this);
        this.mapCommonElements = this.mapCommonElements.bind(this);
        this.mapParentForm = this.mapParentForm.bind(this);
        this.getInputs = this.getInputs.bind(this);
        this.hasForm = this.hasForm.bind(this);
        this.mapParentForm = this.mapParentForm.bind(this);
        this.onMutation = this.onMutation.bind(this);
        this.scan = this.scan.bind(this);
        this.shouldScan = this.shouldScan.bind(this);
        this.subscribeToMutations = this.subscribeToMutations.bind(this);
        this.unsubscribeFromMutations = this.unsubscribeFromMutations.bind(this);
        this.fill = this.fill.bind(this);
        this.forms = this.scan();
    }
    fill(result) {
        formsTools_1.parseResult(result)
            .then(values => {
            for (const [form, { inputElements, type: formType }] of this.forms) {
                if (matchers_1.FILL_TYPES.includes(formType)) {
                    let lastElement;
                    for (const [input, inputType] of inputElements) {
                        if (values.has(inputType))
                            lastElement = input;
                        input.value = values.get(inputType);
                        // input.dispatchEvent(new Event('input', { bubbles: true }))
                        input.dispatchEvent(new Event('input'));
                    }
                    // Focus the last element
                    const elements = [
                        ...form.querySelectorAll('input,button,select,textarea')
                    ].filter(input => input instanceof HTMLInputElement && input.type === 'hidden'
                        ? false
                        : true);
                    const lastIndex = elements.indexOf(lastElement);
                    const index = lastIndex === -1 ? elements.length - 1 : lastIndex + 1;
                    if (elements[index] !== undefined)
                        elements[index].focus();
                }
            }
        });
    }
    /**
     * Get all relevant inputs and buttons (or button-like elements) contained in the element.
     */
    getInputs(root) {
        const inputs = [];
        const submits = [];
        for (const element of root.querySelectorAll(ELEMENT_SELECTORS)) {
            // Pre-filter
            if (element instanceof HTMLButtonElement && element.type !== 'submit')
                continue;
            // Assign groups
            if (element instanceof HTMLInputElement) {
                if (element.type === 'submit' || element.type === 'image') {
                    submits.push(element);
                }
                else {
                    inputs.push(element);
                }
            }
            else if (element instanceof HTMLButtonElement) {
                submits.push(element);
            }
        }
        return [inputs, submits];
    }
    mapParentForm(forms, elements) {
        const mappedElements = new Map();
        const unmatchedElements = [];
        for (const element of elements) {
            let hasForm = false;
            for (const form of forms) {
                let formElements = mappedElements.get(form);
                if (formElements === undefined) {
                    formElements = [];
                    mappedElements.set(form, formElements);
                }
                if (form.contains(element)) {
                    hasForm = true;
                    formElements.push(element);
                }
            }
            if (!hasForm)
                unmatchedElements.push(element);
        }
        return [mappedElements, unmatchedElements];
    }
    filterSubmits(submits) {
        var _a, _b;
        const scores = new Map();
        for (const submitElement of submits) {
            let score = 0;
            if ((_b = (_a = submitElement.outerHTML.match(/(<[^>]*>)/)) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.match(SUBMIT_MATCHER)) {
                score += 3;
            }
            if (submitElement instanceof HTMLButtonElement) {
                score++;
                if (submitElement.type === 'submit') {
                    score++;
                }
            }
            scores.set(submitElement, score);
        }
        // Collect the elements with the highest scores
        const bestMatches = [...scores].reduce(([maxScore, elements], [element, score]) => score > maxScore
            ? [score, [element]] // Replace max score
            : score === maxScore
                ? [maxScore, [element, ...elements]]
                : [maxScore, elements], [0, []]);
        return bestMatches[1];
    }
    mapInputTypes(inputs) {
        return new Map(inputs
            .map(element => [
            element,
            matchers_1.getInputType(element)
        ])
            .filter(([element, elementType]) => elementType !== constants_1.InputType.Hidden &&
            elementType !== constants_1.InputType.Unknown));
    }
    mapForms(formInputs, formSubmits) {
        const forms = new Map();
        // Merge inputs and submits into forms
        for (const [form, inputs] of formInputs) {
            // Should be same forms as inputs, either way a form without inputs isn't interesting
            const submitElements = formSubmits.has(form)
                ? this.filterSubmits(formSubmits.get(form))
                : [];
            const inputElements = this.mapInputTypes(inputs);
            // if (inputElements.size === 0) continue
            forms.set(form, {
                type: matchers_1.getFormType(form, inputs, submitElements),
                inputElements,
                submitElements
            });
        }
        return forms;
    }
    /**
     * Find all forms on the page relative to the root element provided.
     * Returns a map of forms to associated inputs where the null key is
     * used to store all unassociated inputs.
     * @param root Element to start search from.
     * @param elements Elements to be associated with the forms.
     */
    findForms(root, inputs, submits) {
        const formElements = root.querySelectorAll('form');
        const [formInputs, unmatchedInputs] = this.mapParentForm(formElements, inputs);
        const [formSubmits, unmatchedSubmits] = this.mapParentForm(formElements, submits);
        const forms = this.mapForms(formInputs, formSubmits);
        return [forms, unmatchedInputs, unmatchedSubmits];
    }
    mapCommonElements(elements, otherElements, root) {
        const groups = new Map();
        for (const element of elements) {
            let parent = element.parentElement;
            let others = [...otherElements];
            // Loop until all elements are matched through a common element.
            while (others.length > 0 && parent !== root.parentElement) {
                // Check if the current parent is a common node
                let foundMatch = false;
                const unmatched = others.filter((other, index) => {
                    const isMatch = element !== other && parent.contains(other);
                    if (isMatch)
                        foundMatch = true;
                    return element !== other && !isMatch;
                });
                others = unmatched;
                // Update the group list if the current parent is a common node
                // NOTE: It's possible a more efficient solution could be found where both ends
                // of the match are added. In the current state however, it is unknown which
                // elements are in both lists (since the split of inputs and submits)
                if (foundMatch) {
                    let group = groups.get(parent);
                    if (group === undefined) {
                        groups.set(parent, [element]);
                    }
                    else {
                        group.push(element);
                    }
                }
                parent = parent.parentElement;
            }
            // A situation where unmatched elements exist should not occur and indicates a programming error
            if (others.length > 0) {
                throw new StoredSafePageScannerError('Reached top node without finding all common input elements.');
            }
        }
        return groups;
    }
    findPseudoForms(root, inputs, submits) {
        const inputGroups = this.mapCommonElements(inputs, [...inputs, ...submits], root);
        const submitGroups = this.mapCommonElements(submits, [...inputs, ...submits], root);
        const forms = this.mapForms(inputGroups, submitGroups);
        // Sort by least amount of elements
        return new Map([...forms].sort(([k1, v1], [k2, v2]) => v1.inputElements.size +
            v1.submitElements.length -
            (v2.inputElements.size + v2.submitElements.length)));
    }
    /**
     * Perform a second pass with extended selectors for submit buttons.
     * @param forms Forms that were previously filtered out.
     */
    secondPass(forms) {
        var _a;
        for (const [form, formValues] of forms) {
            if (formValues.type !== constants_1.FormType.Unknown)
                continue;
            // const selector = `*:not(${ELEMENT_SELECTORS.split(',').join('):not(')})`
            const selector = 'a';
            for (const element of form.querySelectorAll(selector)) {
                const isMatch = SUBMIT_MATCHER.test(((_a = element.outerHTML.match(/(<[^>]*>)/)) === null || _a === void 0 ? void 0 : _a[0]) + element.innerText); // Only match opening tag and text
                if (isMatch)
                    formValues.submitElements.push(element);
            }
            formValues.type = matchers_1.getFormType(form, [...formValues.inputElements.keys()], formValues.submitElements);
        }
        return forms;
    }
    scan(root = document.body) {
        const [inputs, submits] = this.getInputs(root);
        // Get forms contained in form elements
        let [forms, unmatchedInputs, unmatchedSubmits] = this.findForms(root, inputs, submits);
        // Assemble pseudo-forms from remaining inputs
        let pseudoForms = this.findPseudoForms(root, unmatchedInputs, unmatchedSubmits);
        const secondPass = this.secondPass(new Map([...forms, ...pseudoForms]));
        // Filter out duplicates and unknown forms
        const matchedForms = new Map();
        for (const [form, formValues] of secondPass) {
            if (formValues.type !== constants_1.FormType.Unknown &&
                formValues.type !== constants_1.FormType.Hidden) {
                // Whether the form is a pseudo-form containing another identified form.
                let isPseudoParent = false;
                for (const [matchedForm] of matchedForms) {
                    if (form.contains(matchedForm))
                        isPseudoParent = true;
                }
                if (!isPseudoParent)
                    matchedForms.set(form, formValues);
            }
        }
        return matchedForms;
    }
    /**
     * Whether or not a node is or contains one or more forms/pseudo-forms.
     * @param node Node potentially containing form/pseudo-form.
     */
    hasForm(node) {
        return (node instanceof HTMLFormElement ||
            (node instanceof HTMLElement && node.querySelector('form') !== null));
    }
    hasInput(node) {
        return (node instanceof HTMLInputElement ||
            node instanceof HTMLButtonElement ||
            (node instanceof HTMLElement &&
                node.querySelector('input,button,a') !== null));
    }
    /**
     * Decide whether or not the update nodes should trigger a re-scan of the page.
     * @param nodes Nodes which were updated in DOM.
     */
    shouldScan(node) {
        return this.hasForm(node);
    }
    shouldScanFull(node) {
        return this.hasInput(node);
    }
    onMutation(mutationsList) {
        let shouldScanFull = false;
        const scanQueue = [];
        for (const mutation of mutationsList) {
            for (const node of mutation.addedNodes) {
                if (this.shouldScan(node)) {
                    scanQueue.push(node);
                }
                else if (this.shouldScanFull(node)) {
                    shouldScanFull = true;
                }
            }
            // TODO: Handle removed nodes
        }
        // If parts of forms have been loaded dynamically, re-scan the entire
        // page since we don't know which added nodes belong to which form.
        // It's possible a cheaper solution could be found but for now a full
        // re-scan is cheap enough. See skype.com login for example of lots of
        // partial mutations.
        if (shouldScanFull) {
            this.forms = this.scan();
            return this.forms;
        }
        // If no partial forms are found, scan only new forms.
        let forms = new Map();
        for (const node of scanQueue) {
            forms = new Map([...forms, ...this.scan(node)]);
        }
        this.forms = new Map([...this.forms, ...forms]);
        return forms;
    }
    subscribeToMutations(listener) {
        if (this.observer === null) {
            this.observer = new MutationObserver(mutations => {
                listener === null || listener === void 0 ? void 0 : listener(this.onMutation(mutations));
            });
        }
        this.observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
    unsubscribeFromMutations() {
        this.observer.disconnect();
    }
}
exports.PageScanner = PageScanner;


/***/ }),

/***/ "./src/scripts/content_script/forms/constants.ts":
/*!*******************************************************!*\
  !*** ./src/scripts/content_script/forms/constants.ts ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.FormType = exports.InputType = void 0;
/**
 * Typed version of StoredSafe template fields.
 * The fields at the bottom are not StoredSafe fields but are used for filtering.
 */
var InputType;
(function (InputType) {
    InputType["Username"] = "username";
    InputType["Password"] = "password";
    InputType["PinCode"] = "pincode";
    InputType["CardNo"] = "cardno";
    InputType["Expires"] = "expires";
    InputType["CVC"] = "cvc";
    // Fields used for filtering
    InputType["Hidden"] = "hidden";
    InputType["Unknown"] = "unknown";
})(InputType = exports.InputType || (exports.InputType = {}));
/**
 * Describes the purpose of the form. Some forms should be filled while others
 * should be ignored or handled as special cases.
 * */
var FormType;
(function (FormType) {
    FormType["Login"] = "Login";
    FormType["Card"] = "Card";
    FormType["Search"] = "Search";
    FormType["ContactInfo"] = "Contactinfo";
    FormType["NewsLetter"] = "Newsletter";
    FormType["Register"] = "Register";
    FormType["Menu"] = "Menu";
    FormType["Hidden"] = "Hidden";
    FormType["Unknown"] = "Unknown";
})(FormType = exports.FormType || (exports.FormType = {}));


/***/ }),

/***/ "./src/scripts/content_script/forms/formsTools.ts":
/*!********************************************************!*\
  !*** ./src/scripts/content_script/forms/formsTools.ts ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseResult = void 0;
const StoredSafe_1 = __webpack_require__(/*! ../../../model/storedsafe/StoredSafe */ "./src/model/storedsafe/StoredSafe.ts");
/**
 * Decrypt result fields and returned fill-friendly version of result.
 * @param result Encrypted StoredSafe result
 */
async function parseResult(result) {
    let isEncrypted = result.isDecrypted || result.fields.reduce((acc, field) => acc || (field.isEncrypted && field.value === undefined), false);
    if (isEncrypted) {
        result = await StoredSafe_1.actions.decrypt(result.host, result.id);
    }
    return new Map(result.fields.map(field => [field.name, field.value]));
}
exports.parseResult = parseResult;


/***/ }),

/***/ "./src/scripts/content_script/forms/index.ts":
/*!***************************************************!*\
  !*** ./src/scripts/content_script/forms/index.ts ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const content_script_1 = __webpack_require__(/*! ../../content_script */ "./src/scripts/content_script.ts");
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
exports.logger = new Logger_1.default('Forms', content_script_1.logger);


/***/ }),

/***/ "./src/scripts/content_script/forms/matchers.ts":
/*!******************************************************!*\
  !*** ./src/scripts/content_script/forms/matchers.ts ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SAVE_TYPES = exports.FILL_TYPES = exports.getFormType = exports.getInputType = exports.matchName = void 0;
const _1 = __webpack_require__(/*! . */ "./src/scripts/content_script/forms/index.ts");
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const constants_1 = __webpack_require__(/*! ./constants */ "./src/scripts/content_script/forms/constants.ts");
const logger = new Logger_1.default('Matchers', _1.logger);
/**
 * Keys should match field names in StoredSafe, form inputs should only be filled
 * with the corresponding StoredSafe data if both type and name (name or id attribute)
 * get a match.
 * */
const matchers = new Map([
    [
        constants_1.InputType.Username,
        [
            {
                attributes: { type: /text|email/ },
                name: /user|name|mail|login|namn|id|session_key/
            }
        ]
    ],
    [
        constants_1.InputType.Password,
        [
            {
                attributes: { type: /password/ },
                name: /.*/
            }
        ]
    ],
    [
        constants_1.InputType.PinCode,
        [
            {
                attributes: { type: /password/ },
                name: /.*/
            }
        ]
    ],
    [
        constants_1.InputType.CardNo,
        [
            {
                attributes: { type: /text|tel/ },
                name: /card/
            }
        ]
    ],
    [
        constants_1.InputType.Expires,
        [
            {
                attributes: { type: /text|tel/ },
                name: /exp/
            }
        ]
    ],
    [
        constants_1.InputType.CVC,
        [
            {
                attributes: { type: /text|tel/ },
                name: /sec|code|cvv|cvc/
            }
        ]
    ]
]);
/**
 * Matching should be implemented in the order as follows:
 * 1. Matching the form name is considered a definite match and should return the form type.
 * 2. Matching all the form attributes is considered a definite match and should return the form type.
 * 3. Matching all the field matchers is considered a match and should return the form type.
 *
 * The formMatchers will be checked in order of appearance and the first match if any will
 * be used, meaning more generic matchers should be placed further down in the list.
 *
 * NOTE: Changed from map to multi-dimensional array to allow duplicates.
 * */
const formMatchers = [
    [
        constants_1.FormType.Search,
        {
            name: /search/,
            attributes: { role: /search/ },
            fields: new Map([
                [
                    [
                        {
                            attributes: { type: /text|search/ },
                            name: /search/
                        }
                    ],
                    -1
                ]
            ])
        }
    ],
    [
        constants_1.FormType.Login,
        {
            name: /signin|sign-in/
        }
    ],
    [
        constants_1.FormType.Register,
        {
            name: /createaccount|reg|signup/,
            fields: new Map([
                [
                    [
                        {
                            attributes: { type: /password/ },
                            name: /.*/
                        }
                    ],
                    2
                ],
                [
                    [
                        {
                            attributes: { type: /password/ },
                            name: /confirm|register|retype/
                        }
                    ],
                    -1
                ]
            ])
        }
    ],
    [
        constants_1.FormType.Login,
        {
            fields: new Map([
                [matchers.get(constants_1.InputType.Username), -1],
                [matchers.get(constants_1.InputType.Password), 1]
            ])
        }
    ],
    [
        constants_1.FormType.Login,
        {
            fields: new Map([
                [matchers.get(constants_1.InputType.Username), -1],
                [matchers.get(constants_1.InputType.PinCode), 1]
            ])
        }
    ],
    [
        constants_1.FormType.NewsLetter,
        {
            name: /news|letter/
        }
    ],
    [
        constants_1.FormType.Menu,
        {
            name: /nav|menu/
        }
    ],
    [constants_1.FormType.Unknown, {}]
];
/**
 * Form types that should be filled by the extension.
 * */
const fillFormTypes = [constants_1.FormType.Login, constants_1.FormType.Card];
/**
 * Form types that should be saved by the extension when the form is submitted.
 * */
const saveFormTypes = [constants_1.FormType.Login, constants_1.FormType.Register];
////////////////////////////////////////////////////////////
// Start matching helper functions
/**
 * All input fields are of the hidden type.
 */
const isHidden = (element) => (element.type === 'hidden' || element.hidden === true);
const isHiddenForm = (inputElements) => inputElements.reduce((hidden, inputElement) => hidden && isHidden(inputElement), true);
/**
 * Test a name against all attributes of the element.
 * @param element Element to test for presence of name.
 * @param name Name to be matched against element.
 */
function matchName(element, name) {
    const nameRegExp = new RegExp(name, 'i');
    for (const attr of element.attributes) {
        if (nameRegExp.test(attr.value))
            return true;
    }
    return false;
}
exports.matchName = matchName;
/**
 * Test an element for the presence of attribute values.
 * @param element Element to test for presence of attribute values.
 * @param attributeMatchers Mapping from attribute to matcher.
 */
function matchAttributes(element, attributeMatchers) {
    for (const attribute in attributeMatchers) {
        const attributeMatcher = new RegExp(attributeMatchers[attribute], 'i');
        if (!attributeMatcher.test(element.getAttribute(attribute)))
            return false;
    }
    return true;
}
/**
 * Test the types of a group of input elements against a list of matchers.
 * If the amount of matches is the same as the matchCount parameter,
 * the function should return true. Negative numbers are used for special cases
 * where -1 will return true if there is any match and -2 will return true only
 * if all elements match.
 *
 * NOTE: This is separate from regular input matching because form identification
 * sometimes requires more specific matchers to differentiate for example a register
 * password field from a login password field, whereas the regular input matchers are
 * only relevant when filling StoredSafe data to know which data goes into which field.
 * @param inputTypes List of the types of all inputs.
 * @param matchers List of expressions considered to be a match.
 * @param matchCount Desired number of matches (-1 = Any, -2 = All)
 */
function matchField(inputs, matchers, matchCount = -1) {
    let count = 0;
    for (const input of inputs) {
        let isMatch = false;
        for (const matcher of matchers) {
            isMatch = matchName(input, matcher.name) && matchAttributes(input, matcher.attributes);
        }
        if (isMatch)
            count++;
    }
    if (matchCount === -2) {
        return count === inputs.length;
    }
    else if (matchCount === -1) {
        return count > 0;
    }
    else if (matchCount >= 0) {
        return count === matchCount;
    }
    return false;
}
function matchFields(inputs, fieldMatchers) {
    for (const [matchers, matchCount] of fieldMatchers) {
        if (!matchField(inputs, matchers, matchCount))
            return false;
    }
    return true;
}
function getInputType(input) {
    if (isHidden(input))
        return constants_1.InputType.Hidden;
    for (const [inputType, inputMatchers] of matchers) {
        for (const matcher of inputMatchers) {
            if (matchName(input, matcher.name) &&
                matchAttributes(input, matcher.attributes))
                return inputType;
        }
    }
    return constants_1.InputType.Unknown;
}
exports.getInputType = getInputType;
function getFormType(element, inputElements, submitElements) {
    // Cull hidden forms as they're not made for user interaction.
    if (isHiddenForm(inputElements))
        return constants_1.FormType.Hidden;
    // Forms without submits are regarded as unknown as they can't be
    // submitted by a user. These forms may be caught in the second pass
    // when the search is extended beyond button types.
    if (submitElements.length === 0)
        return constants_1.FormType.Unknown;
    // 1. Check for form element name matches
    for (const [formType, formMatcher] of formMatchers) {
        if (formMatcher.name === undefined)
            continue;
        if (matchName(element, formMatcher.name)) {
            logger.debug('Identified form %o as %s by name', element, formType);
            return formType;
        }
    }
    // 2. Check for form attributes matches
    for (const [formType, formMatcher] of formMatchers) {
        if (formMatcher.attributes === undefined)
            continue;
        if (matchAttributes(element, formMatcher.attributes)) {
            logger.debug('Identified form %o as %s by attributes', element, formType);
            return formType;
        }
    }
    // 3. Check if the form fields match
    for (const [formType, formMatcher] of formMatchers) {
        if (formMatcher.fields === undefined)
            continue;
        if (matchFields(inputElements, formMatcher.fields)) {
            logger.debug('Identified form %o as %s by fields', element, formType);
            return formType;
        }
    }
    return constants_1.FormType.Unknown;
}
exports.getFormType = getFormType;
exports.FILL_TYPES = [constants_1.FormType.Login];
exports.SAVE_TYPES = [constants_1.FormType.Login, constants_1.FormType.Register];


/***/ }),

/***/ "./src/scripts/content_script/inject/FrameManager.ts":
/*!***********************************************************!*\
  !*** ./src/scripts/content_script/inject/FrameManager.ts ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FrameManager = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const _1 = __webpack_require__(/*! . */ "./src/scripts/content_script/inject/index.ts");
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const logger = new Logger_1.default('Frames', _1.logger);
const ROOT_ID = 'com-storedsafe-root';
const BASE_STYLE = {
    border: '0',
    padding: '0',
    margin: '0',
    position: 'fixed',
    top: '10px',
    right: '10px',
    width: '100px',
    height: '100px',
    background: 'transparent',
    'z-index': '2147483646'
};
class StoredSafeFrameManagerError extends StoredSafeError_1.default {
}
class FrameManager {
    static OpenFrame(frameId, style) {
        // Create iframe at max z-index
        const root = FrameManager.getFrame(ROOT_ID, document.body, ROOT_ID, {
            'z-index': '2147483646'
        });
        FrameManager.getFrame(frameId, root, 'iframe', Object.assign(Object.assign({}, BASE_STYLE), style));
    }
    static CloseFrame(frameId) {
        FrameManager.removeFrame(frameId);
        const root = document.getElementById(ROOT_ID);
        if (root.childElementCount === 0) {
            logger.debug('Root frame is empty, removing %o.', root);
            root.remove();
        }
    }
    static ResizeFrame(frameId, width, height) {
        const frame = document.getElementById(frameId);
        if (frame === null) {
            throw new StoredSafeFrameManagerError(`Can't resize frame, #${frameId} doesn't exist.`);
        }
        frame.style.width = `${width}px`;
        frame.style.height = `${height}px`;
    }
    /**
     * Get the element with the matching ID or create it if it doesn't exist.
     * @param frameId ID attribute of the frame.
     */
    static getFrame(frameId, parent, frameType, style = {}) {
        let frame = document.getElementById(frameId);
        if (frame === null) {
            frame = document.createElement(frameType);
            frame.id = frameId;
            for (const prop in style) {
                frame.style.setProperty(prop, style[prop]);
            }
            if (frame instanceof HTMLIFrameElement) {
                frame.src = browser.runtime.getURL('index.html') + `#${frameId}`;
            }
            parent.appendChild(frame);
            logger.debug('Creating frame %o', frame);
        }
        return frame;
    }
    /**
     * Remove the element with the matching ID. Noop if element doesn't exist.
     * @param frameId ID attribute of the frame to be removed.
     */
    static removeFrame(frameId = ROOT_ID) {
        const frame = document.getElementById(frameId);
        if (frame !== null) {
            logger.debug('Removing frame %o', frame);
            frame.remove();
        }
    }
}
exports.FrameManager = FrameManager;


/***/ }),

/***/ "./src/scripts/content_script/inject/index.ts":
/*!****************************************************!*\
  !*** ./src/scripts/content_script/inject/index.ts ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
const content_script_1 = __webpack_require__(/*! ../../content_script */ "./src/scripts/content_script.ts");
exports.logger = new Logger_1.default('Inject', content_script_1.logger);


/***/ }),

/***/ "./src/scripts/content_script/messages/MessageHandler.ts":
/*!***************************************************************!*\
  !*** ./src/scripts/content_script/messages/MessageHandler.ts ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageHandler = void 0;
const StoredSafeError_1 = __importDefault(__webpack_require__(/*! ../../../utils/StoredSafeError */ "./src/utils/StoredSafeError.ts"));
const _1 = __webpack_require__(/*! . */ "./src/scripts/content_script/messages/index.ts");
const constants_1 = __webpack_require__(/*! ./constants */ "./src/scripts/content_script/messages/constants.ts");
const FrameManager_1 = __webpack_require__(/*! ../inject/FrameManager */ "./src/scripts/content_script/inject/FrameManager.ts");
class StoredSafeMessageHandlerError extends StoredSafeError_1.default {
}
class MessageHandler {
    constructor(pageScanner) {
        this.port = null;
        // Make sure JS remembers what `this` is
        this.start = this.start.bind(this);
        this.stop = this.stop.bind(this);
        this.onMessage = this.onMessage.bind(this);
        this.sendSubmit = this.sendSubmit.bind(this);
        this.onDisconnect = this.onDisconnect.bind(this);
        this.pageScanner = pageScanner;
        this.start();
    }
    onDisconnect() {
        _1.logger.log('Disconnected, shutting down port.');
        this.port.onDisconnect.removeListener(this.onDisconnect);
        this.port.onMessage.removeListener(this.onMessage);
    }
    start() {
        this.port = browser.runtime.connect(browser.runtime.id, {
            name: constants_1.PORT_CONTENT
        });
        this.port.onMessage.addListener(this.onMessage);
        this.port.onDisconnect.addListener(this.onDisconnect);
    }
    stop() {
        this.port.disconnect();
        this.port = null;
    }
    onMessage({ type, data }) {
        _1.logger.log('Incoming message %s', type);
        const [flow, action] = type.split('.');
        if (flow === undefined || action === undefined) {
            throw new StoredSafeMessageHandlerError(`Invalid message: ${{
                type,
                data
            }}, message.type must be of type 'flow.action'.`);
        }
        let frameId = null;
        if (flow === constants_1.FLOW_SAVE)
            frameId = constants_1.SAVE_FRAME_ID;
        if (flow === constants_1.FLOW_FILL)
            frameId = constants_1.FILL_FRAME_ID;
        if (frameId !== null) {
            switch (action) {
                case constants_1.ACTION_OPEN: {
                    FrameManager_1.FrameManager.OpenFrame(frameId);
                    break;
                }
                case constants_1.ACTION_CLOSE: {
                    FrameManager_1.FrameManager.CloseFrame(frameId);
                    break;
                }
                case constants_1.ACTION_RESIZE: {
                    FrameManager_1.FrameManager.ResizeFrame(frameId, data.width, data.height);
                    break;
                }
                case constants_1.ACTION_FILL: {
                    this.pageScanner.fill(data);
                    break;
                }
                default: {
                    throw new StoredSafeMessageHandlerError(`Unknown message flow: ${flow}.${action}`);
                }
            }
        }
    }
    postMessage(message) {
        if (this.port === null) {
            throw new StoredSafeMessageHandlerError('Cannot send message, port is closed.');
        }
        this.port.postMessage(message);
    }
    /**
     * Send a submit message to the background script to initiate the save flow.
     * @param values Values of input fields mapped to input type.
     */
    sendSubmit(values) {
        this.postMessage({
            type: `${constants_1.FLOW_SAVE}.${constants_1.ACTION_INIT}`,
            data: values
        });
    }
    /**
     * Send an offer to automatically fill a form on the page when such a form exists.
     * The user settings will define whether the offer is accepted or not.
     */
    sendOfferAutoFill() {
        browser.runtime.sendMessage({
            type: 'autoFill'
        });
    }
}
exports.MessageHandler = MessageHandler;


/***/ }),

/***/ "./src/scripts/content_script/messages/constants.ts":
/*!**********************************************************!*\
  !*** ./src/scripts/content_script/messages/constants.ts ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.ACTION_FILL = exports.ACTION_INIT = exports.ACTION_POPULATE = exports.ACTION_RESIZE = exports.ACTION_CLOSE = exports.ACTION_OPEN = exports.FLOW_FILL = exports.FLOW_SAVE = exports.FILL_FRAME_ID = exports.SAVE_FRAME_ID = exports.PORT_CONTENT = exports.PORT_FILL_FILL = exports.PORT_FILL_RESIZE = exports.PORT_FILL_CLOSE = exports.PORT_FILL_CONNECTED = exports.PORT_FILL_PREFIX = exports.PORT_SAVE_RESIZE = exports.PORT_SAVE_CLOSE = exports.PORT_SAVE_CONNECTED = exports.PORT_SAVE_PREFIX = void 0;
// Unique IDs for identifying message origins
exports.PORT_SAVE_PREFIX = 'save_';
exports.PORT_SAVE_CONNECTED = `${exports.PORT_SAVE_PREFIX}connected`;
exports.PORT_SAVE_CLOSE = `${exports.PORT_SAVE_PREFIX}close`;
exports.PORT_SAVE_RESIZE = `${exports.PORT_SAVE_PREFIX}resize`;
exports.PORT_FILL_PREFIX = 'fill_';
exports.PORT_FILL_CONNECTED = `${exports.PORT_FILL_PREFIX}connected`;
exports.PORT_FILL_CLOSE = `${exports.PORT_FILL_PREFIX}close`;
exports.PORT_FILL_RESIZE = `${exports.PORT_FILL_PREFIX}resize`;
exports.PORT_FILL_FILL = `${exports.PORT_FILL_PREFIX}fill`;
exports.PORT_CONTENT = 'content_script';
// Unique IDs used for identifying iframes
exports.SAVE_FRAME_ID = 'com-storedsafe-save';
exports.FILL_FRAME_ID = 'com-storedsafe-fill';
// The available user flows.
// Message types should hold the form <flow>.<action>, for example save.open
exports.FLOW_SAVE = 'save';
exports.FLOW_FILL = 'fill';
//// Common actions
// background -> content_script
exports.ACTION_OPEN = 'open'; // Open iframe
// iframe -> background -> content_script
exports.ACTION_CLOSE = 'close'; // Close iframe
exports.ACTION_RESIZE = 'resize'; // Resize iframe
// background -> iframe
exports.ACTION_POPULATE = 'populate'; // Pass background data to iframe after open
// content_script -> background or popup -> background
exports.ACTION_INIT = 'init'; // Initiate flow with data
// background -> content_script
exports.ACTION_FILL = 'fill';


/***/ }),

/***/ "./src/scripts/content_script/messages/index.ts":
/*!******************************************************!*\
  !*** ./src/scripts/content_script/messages/index.ts ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const content_script_1 = __webpack_require__(/*! ../../content_script */ "./src/scripts/content_script.ts");
const Logger_1 = __importDefault(__webpack_require__(/*! ../../../utils/Logger */ "./src/utils/Logger.ts"));
exports.logger = new Logger_1.default('Messages', content_script_1.logger);


/***/ }),

/***/ "./src/utils/Logger.ts":
/*!*****************************!*\
  !*** ./src/utils/Logger.ts ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * This module provides a custom logger to be used throughout the application.
 * It adds two primary features:
 *   1. Colored messages per logger instance with assigned names for increased
 *      readability. Uses a hash value of the assigned name to generate a color
 *      so that the same name will always have the same color for consistency.
 *   2. Single point of entry for logging, allows logging levels to be adjusted
 *      more easily later on so that logging can be toggled instead of being
 *      added/removed as needed.
 *
 * The console.log function can be used in two different ways. Either in a printf-like
 * manner where the first parameter is the message and subsequent parameters are variables;
 * or in a way where each parameter gets printed after the other.
 *   Since this logger uses the printf style to achieve colors, modules that use the logger
 * are also resticted to the printf-style. Meaning the first parameter is always the message
 * and subsequent parameters are variables which are injected into special characters in the
 * messages such as %o for object, %s for string and %d for number.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.StoredSafeLogger = void 0;
// Print this in front of all log messages
const PREFIX = 'StoredSafe';
// Base style for colored messages
const baseStyle = [
    'color: #fff',
    'background-color: #526A78',
    'padding: 2px 4px',
    'border-radius: 2px'
].join(';');
// Specific coloring for special tags, extends base style
const depthStyle = [baseStyle, 'background-color: #f59815'].join(';');
const tableStyle = [baseStyle, 'background-color: #D65780'].join(';');
/**
 * Wraps logging to print more informative messages to the console.
 */
class Logger {
    constructor(name, parent = exports.StoredSafeLogger) {
        this.groupDepth = 0;
        this.parent = null;
        this.name = name;
        this.parent = parent;
        this.enabled = this.parent === null ? true : this.parent.enabled;
        if (this.parent === null) {
            this.nameStyle = baseStyle;
        }
        else {
            // Generate a color based on the name to make it easy to identify
            const hash = this.name.split('').reduce((a, x) => a + x.charCodeAt(0), 0);
            const h = `${hash % 360}`;
            const s = `${(hash % 25) + 25}%`;
            const l = `${(hash % 20) + 40}%`;
            const color = `hsl(${h}, ${s}, ${l})`;
            this.nameStyle = [baseStyle, `background-color: ${color}`].join(';');
        }
    }
    /**
     * Helper function to determine whether an open console.group is active.
     */
    _isGrouped() {
        return this.groupDepth > 0;
    }
    _namePrefix() {
        let parentPrefix = '', parentStyle = [];
        if (this.parent !== null) {
            ;
            [parentPrefix, parentStyle] = this.parent._namePrefix();
        }
        return [`${parentPrefix}%c${this.name}`, [...parentStyle, this.nameStyle]];
    }
    /**
     * Helper function to generate colored tags.
     * Prints the application name, the module name and optionally a tag name and
     * then resets the style (or applies the provided style) for the actual message.
     * @param tag Extra tag to be added before message.
     * @param tagStyle Style for extra tag.
     * @param style Style of the message.
     */
    _prefix(tag = '', tagStyle = '', style = '') {
        const [namePrefix, nameStyle] = this._namePrefix();
        return [`${namePrefix}%c${tag}%c `, [...nameStyle, tagStyle, style]];
    }
    /**
     * Start a console group, causing an indented block for subsequent log messages.
     * Cancel with Logger.groupEnd.
     * @param title Title of the group for better readability.
     */
    group(title = '') {
        if (!this.enabled)
            return;
        this.groupDepth += 1;
        const [prefix, styles] = this._prefix(`G${this.groupDepth} - ${title}`, depthStyle);
        console.group(prefix, ...styles);
    }
    /**
     * Same as Logger.group, but start the group collapsed.
     * Cancel with Logger.groupEnd.
     * @param title Title of the group for better readability.
     */
    groupCollapsed(title = '') {
        if (!this.enabled)
            return;
        this.groupDepth += 1;
        const [prefix, styles] = this._prefix(`G${this.groupDepth} - ${title}`, depthStyle);
        console.groupCollapsed(prefix, ...styles);
    }
    /**
     * End a console group, reverting indentation of Logger.group.
     */
    groupEnd() {
        if (!this.enabled)
            return;
        if (this._isGrouped()) {
            this.groupDepth -= 1;
            console.groupEnd();
        }
    }
    /**
     * Send a standard log message to the console.
     * @param message Message to be logged.
     * @param variables Values to be injected into message.
     */
    log(message, ...variables) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix();
        console.log(prefix + message, ...styles, ...variables);
    }
    /**
     * Send an info message to the console.
     * @param message Message to be logged.
     * @param variables Values to be injected into message.
     */
    info(message, ...variables) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix();
        console.info(prefix + message, ...styles, ...variables);
    }
    /**
     * Send a warning message to the console.
     * @param message Message to be logged.
     * @param variables Values to be injected into message.
     */
    warn(message, ...variables) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix();
        console.warn(prefix + message, ...styles, ...variables);
    }
    /**
     * Send an error message to the console.
     * @param message Message to be logged.
     * @param variables Values to be injected into message.
     */
    error(message, ...variables) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix();
        console.error(prefix + message, ...styles, ...variables);
    }
    /**
     * Send a debug message to the console.
     * @param message Message to be logged.
     * @param variables Values to be injected into message.
     */
    debug(message, ...variables) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix();
        console.debug(prefix + message, ...styles, ...variables);
    }
    /**
     * Present an object as a table in the console.
     * @param obj Object to be presented.
     */
    table(obj) {
        if (!this.enabled)
            return;
        const [prefix, styles] = this._prefix('table', tableStyle);
        console.log(prefix, ...styles);
        console.table(obj);
    }
    enable() {
        this.enabled = true;
    }
    disable() {
        this.enabled = false;
    }
}
exports.StoredSafeLogger = new Logger(PREFIX, null);
if (false) {}
exports.default = Logger;


/***/ }),

/***/ "./src/utils/StoredSafeError.ts":
/*!**************************************!*\
  !*** ./src/utils/StoredSafeError.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Wraps the standard Error to automatically name the error after
 * the extending class, providing more informative error messages.
 */
class StoredSafeError extends Error {
    constructor(message, error) {
        super(message);
        this.name = this.constructor.name;
        this.stack = error === null || error === void 0 ? void 0 : error.stack;
    }
}
exports.default = StoredSafeError;


/***/ })

/******/ });
//# sourceMappingURL=content_script.js.map