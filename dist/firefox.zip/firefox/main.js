/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.tsx");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./graphics/padlock-error.svg":
/*!************************************!*\
  !*** ./graphics/padlock-error.svg ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "2b60f0d00a2a0c7b50ac6e9128bde08b.svg");

/***/ }),

/***/ "./graphics/padlock-unlocked.svg":
/*!***************************************!*\
  !*** ./graphics/padlock-unlocked.svg ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "fd323c6d4aacfe69735ab7db2c98061e.svg");

/***/ }),

/***/ "./graphics/padlock-warning.svg":
/*!**************************************!*\
  !*** ./graphics/padlock-warning.svg ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "6ae1530a54fa642a54800f6591a7da03.svg");

/***/ }),

/***/ "./graphics/padlock.svg":
/*!******************************!*\
  !*** ./graphics/padlock.svg ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "90919a8b5a0b646030fc506d77841cc9.svg");

/***/ }),

/***/ "./node_modules/axios/index.js":
/*!*************************************!*\
  !*** ./node_modules/axios/index.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./lib/axios */ "./node_modules/axios/lib/axios.js");

/***/ }),

/***/ "./node_modules/axios/lib/adapters/xhr.js":
/*!************************************************!*\
  !*** ./node_modules/axios/lib/adapters/xhr.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var settle = __webpack_require__(/*! ./../core/settle */ "./node_modules/axios/lib/core/settle.js");
var buildURL = __webpack_require__(/*! ./../helpers/buildURL */ "./node_modules/axios/lib/helpers/buildURL.js");
var buildFullPath = __webpack_require__(/*! ../core/buildFullPath */ "./node_modules/axios/lib/core/buildFullPath.js");
var parseHeaders = __webpack_require__(/*! ./../helpers/parseHeaders */ "./node_modules/axios/lib/helpers/parseHeaders.js");
var isURLSameOrigin = __webpack_require__(/*! ./../helpers/isURLSameOrigin */ "./node_modules/axios/lib/helpers/isURLSameOrigin.js");
var createError = __webpack_require__(/*! ../core/createError */ "./node_modules/axios/lib/core/createError.js");

module.exports = function xhrAdapter(config) {
  return new Promise(function dispatchXhrRequest(resolve, reject) {
    var requestData = config.data;
    var requestHeaders = config.headers;

    if (utils.isFormData(requestData)) {
      delete requestHeaders['Content-Type']; // Let the browser set it
    }

    var request = new XMLHttpRequest();

    // HTTP basic authentication
    if (config.auth) {
      var username = config.auth.username || '';
      var password = config.auth.password || '';
      requestHeaders.Authorization = 'Basic ' + btoa(username + ':' + password);
    }

    var fullPath = buildFullPath(config.baseURL, config.url);
    request.open(config.method.toUpperCase(), buildURL(fullPath, config.params, config.paramsSerializer), true);

    // Set the request timeout in MS
    request.timeout = config.timeout;

    // Listen for ready state
    request.onreadystatechange = function handleLoad() {
      if (!request || request.readyState !== 4) {
        return;
      }

      // The request errored out and we didn't get a response, this will be
      // handled by onerror instead
      // With one exception: request that using file: protocol, most browsers
      // will return status as 0 even though it's a successful request
      if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf('file:') === 0)) {
        return;
      }

      // Prepare the response
      var responseHeaders = 'getAllResponseHeaders' in request ? parseHeaders(request.getAllResponseHeaders()) : null;
      var responseData = !config.responseType || config.responseType === 'text' ? request.responseText : request.response;
      var response = {
        data: responseData,
        status: request.status,
        statusText: request.statusText,
        headers: responseHeaders,
        config: config,
        request: request
      };

      settle(resolve, reject, response);

      // Clean up request
      request = null;
    };

    // Handle browser request cancellation (as opposed to a manual cancellation)
    request.onabort = function handleAbort() {
      if (!request) {
        return;
      }

      reject(createError('Request aborted', config, 'ECONNABORTED', request));

      // Clean up request
      request = null;
    };

    // Handle low level network errors
    request.onerror = function handleError() {
      // Real errors are hidden from us by the browser
      // onerror should only fire if it's a network error
      reject(createError('Network Error', config, null, request));

      // Clean up request
      request = null;
    };

    // Handle timeout
    request.ontimeout = function handleTimeout() {
      var timeoutErrorMessage = 'timeout of ' + config.timeout + 'ms exceeded';
      if (config.timeoutErrorMessage) {
        timeoutErrorMessage = config.timeoutErrorMessage;
      }
      reject(createError(timeoutErrorMessage, config, 'ECONNABORTED',
        request));

      // Clean up request
      request = null;
    };

    // Add xsrf header
    // This is only done if running in a standard browser environment.
    // Specifically not if we're in a web worker, or react-native.
    if (utils.isStandardBrowserEnv()) {
      var cookies = __webpack_require__(/*! ./../helpers/cookies */ "./node_modules/axios/lib/helpers/cookies.js");

      // Add xsrf header
      var xsrfValue = (config.withCredentials || isURLSameOrigin(fullPath)) && config.xsrfCookieName ?
        cookies.read(config.xsrfCookieName) :
        undefined;

      if (xsrfValue) {
        requestHeaders[config.xsrfHeaderName] = xsrfValue;
      }
    }

    // Add headers to the request
    if ('setRequestHeader' in request) {
      utils.forEach(requestHeaders, function setRequestHeader(val, key) {
        if (typeof requestData === 'undefined' && key.toLowerCase() === 'content-type') {
          // Remove Content-Type if data is undefined
          delete requestHeaders[key];
        } else {
          // Otherwise add header to the request
          request.setRequestHeader(key, val);
        }
      });
    }

    // Add withCredentials to request if needed
    if (!utils.isUndefined(config.withCredentials)) {
      request.withCredentials = !!config.withCredentials;
    }

    // Add responseType to request if needed
    if (config.responseType) {
      try {
        request.responseType = config.responseType;
      } catch (e) {
        // Expected DOMException thrown by browsers not compatible XMLHttpRequest Level 2.
        // But, this can be suppressed for 'json' type as it can be parsed by default 'transformResponse' function.
        if (config.responseType !== 'json') {
          throw e;
        }
      }
    }

    // Handle progress if needed
    if (typeof config.onDownloadProgress === 'function') {
      request.addEventListener('progress', config.onDownloadProgress);
    }

    // Not all browsers support upload events
    if (typeof config.onUploadProgress === 'function' && request.upload) {
      request.upload.addEventListener('progress', config.onUploadProgress);
    }

    if (config.cancelToken) {
      // Handle cancellation
      config.cancelToken.promise.then(function onCanceled(cancel) {
        if (!request) {
          return;
        }

        request.abort();
        reject(cancel);
        // Clean up request
        request = null;
      });
    }

    if (requestData === undefined) {
      requestData = null;
    }

    // Send the request
    request.send(requestData);
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/axios.js":
/*!*****************************************!*\
  !*** ./node_modules/axios/lib/axios.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./utils */ "./node_modules/axios/lib/utils.js");
var bind = __webpack_require__(/*! ./helpers/bind */ "./node_modules/axios/lib/helpers/bind.js");
var Axios = __webpack_require__(/*! ./core/Axios */ "./node_modules/axios/lib/core/Axios.js");
var mergeConfig = __webpack_require__(/*! ./core/mergeConfig */ "./node_modules/axios/lib/core/mergeConfig.js");
var defaults = __webpack_require__(/*! ./defaults */ "./node_modules/axios/lib/defaults.js");

/**
 * Create an instance of Axios
 *
 * @param {Object} defaultConfig The default config for the instance
 * @return {Axios} A new instance of Axios
 */
function createInstance(defaultConfig) {
  var context = new Axios(defaultConfig);
  var instance = bind(Axios.prototype.request, context);

  // Copy axios.prototype to instance
  utils.extend(instance, Axios.prototype, context);

  // Copy context to instance
  utils.extend(instance, context);

  return instance;
}

// Create the default instance to be exported
var axios = createInstance(defaults);

// Expose Axios class to allow class inheritance
axios.Axios = Axios;

// Factory for creating new instances
axios.create = function create(instanceConfig) {
  return createInstance(mergeConfig(axios.defaults, instanceConfig));
};

// Expose Cancel & CancelToken
axios.Cancel = __webpack_require__(/*! ./cancel/Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");
axios.CancelToken = __webpack_require__(/*! ./cancel/CancelToken */ "./node_modules/axios/lib/cancel/CancelToken.js");
axios.isCancel = __webpack_require__(/*! ./cancel/isCancel */ "./node_modules/axios/lib/cancel/isCancel.js");

// Expose all/spread
axios.all = function all(promises) {
  return Promise.all(promises);
};
axios.spread = __webpack_require__(/*! ./helpers/spread */ "./node_modules/axios/lib/helpers/spread.js");

module.exports = axios;

// Allow use of default import syntax in TypeScript
module.exports.default = axios;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/Cancel.js":
/*!*************************************************!*\
  !*** ./node_modules/axios/lib/cancel/Cancel.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * A `Cancel` is an object that is thrown when an operation is canceled.
 *
 * @class
 * @param {string=} message The message.
 */
function Cancel(message) {
  this.message = message;
}

Cancel.prototype.toString = function toString() {
  return 'Cancel' + (this.message ? ': ' + this.message : '');
};

Cancel.prototype.__CANCEL__ = true;

module.exports = Cancel;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/CancelToken.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/cancel/CancelToken.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var Cancel = __webpack_require__(/*! ./Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");

/**
 * A `CancelToken` is an object that can be used to request cancellation of an operation.
 *
 * @class
 * @param {Function} executor The executor function.
 */
function CancelToken(executor) {
  if (typeof executor !== 'function') {
    throw new TypeError('executor must be a function.');
  }

  var resolvePromise;
  this.promise = new Promise(function promiseExecutor(resolve) {
    resolvePromise = resolve;
  });

  var token = this;
  executor(function cancel(message) {
    if (token.reason) {
      // Cancellation has already been requested
      return;
    }

    token.reason = new Cancel(message);
    resolvePromise(token.reason);
  });
}

/**
 * Throws a `Cancel` if cancellation has been requested.
 */
CancelToken.prototype.throwIfRequested = function throwIfRequested() {
  if (this.reason) {
    throw this.reason;
  }
};

/**
 * Returns an object that contains a new `CancelToken` and a function that, when called,
 * cancels the `CancelToken`.
 */
CancelToken.source = function source() {
  var cancel;
  var token = new CancelToken(function executor(c) {
    cancel = c;
  });
  return {
    token: token,
    cancel: cancel
  };
};

module.exports = CancelToken;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/isCancel.js":
/*!***************************************************!*\
  !*** ./node_modules/axios/lib/cancel/isCancel.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function isCancel(value) {
  return !!(value && value.__CANCEL__);
};


/***/ }),

/***/ "./node_modules/axios/lib/core/Axios.js":
/*!**********************************************!*\
  !*** ./node_modules/axios/lib/core/Axios.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var buildURL = __webpack_require__(/*! ../helpers/buildURL */ "./node_modules/axios/lib/helpers/buildURL.js");
var InterceptorManager = __webpack_require__(/*! ./InterceptorManager */ "./node_modules/axios/lib/core/InterceptorManager.js");
var dispatchRequest = __webpack_require__(/*! ./dispatchRequest */ "./node_modules/axios/lib/core/dispatchRequest.js");
var mergeConfig = __webpack_require__(/*! ./mergeConfig */ "./node_modules/axios/lib/core/mergeConfig.js");

/**
 * Create a new instance of Axios
 *
 * @param {Object} instanceConfig The default config for the instance
 */
function Axios(instanceConfig) {
  this.defaults = instanceConfig;
  this.interceptors = {
    request: new InterceptorManager(),
    response: new InterceptorManager()
  };
}

/**
 * Dispatch a request
 *
 * @param {Object} config The config specific for this request (merged with this.defaults)
 */
Axios.prototype.request = function request(config) {
  /*eslint no-param-reassign:0*/
  // Allow for axios('example/url'[, config]) a la fetch API
  if (typeof config === 'string') {
    config = arguments[1] || {};
    config.url = arguments[0];
  } else {
    config = config || {};
  }

  config = mergeConfig(this.defaults, config);

  // Set config.method
  if (config.method) {
    config.method = config.method.toLowerCase();
  } else if (this.defaults.method) {
    config.method = this.defaults.method.toLowerCase();
  } else {
    config.method = 'get';
  }

  // Hook up interceptors middleware
  var chain = [dispatchRequest, undefined];
  var promise = Promise.resolve(config);

  this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
    chain.unshift(interceptor.fulfilled, interceptor.rejected);
  });

  this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
    chain.push(interceptor.fulfilled, interceptor.rejected);
  });

  while (chain.length) {
    promise = promise.then(chain.shift(), chain.shift());
  }

  return promise;
};

Axios.prototype.getUri = function getUri(config) {
  config = mergeConfig(this.defaults, config);
  return buildURL(config.url, config.params, config.paramsSerializer).replace(/^\?/, '');
};

// Provide aliases for supported request methods
utils.forEach(['delete', 'get', 'head', 'options'], function forEachMethodNoData(method) {
  /*eslint func-names:0*/
  Axios.prototype[method] = function(url, config) {
    return this.request(utils.merge(config || {}, {
      method: method,
      url: url
    }));
  };
});

utils.forEach(['post', 'put', 'patch'], function forEachMethodWithData(method) {
  /*eslint func-names:0*/
  Axios.prototype[method] = function(url, data, config) {
    return this.request(utils.merge(config || {}, {
      method: method,
      url: url,
      data: data
    }));
  };
});

module.exports = Axios;


/***/ }),

/***/ "./node_modules/axios/lib/core/InterceptorManager.js":
/*!***********************************************************!*\
  !*** ./node_modules/axios/lib/core/InterceptorManager.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

function InterceptorManager() {
  this.handlers = [];
}

/**
 * Add a new interceptor to the stack
 *
 * @param {Function} fulfilled The function to handle `then` for a `Promise`
 * @param {Function} rejected The function to handle `reject` for a `Promise`
 *
 * @return {Number} An ID used to remove interceptor later
 */
InterceptorManager.prototype.use = function use(fulfilled, rejected) {
  this.handlers.push({
    fulfilled: fulfilled,
    rejected: rejected
  });
  return this.handlers.length - 1;
};

/**
 * Remove an interceptor from the stack
 *
 * @param {Number} id The ID that was returned by `use`
 */
InterceptorManager.prototype.eject = function eject(id) {
  if (this.handlers[id]) {
    this.handlers[id] = null;
  }
};

/**
 * Iterate over all the registered interceptors
 *
 * This method is particularly useful for skipping over any
 * interceptors that may have become `null` calling `eject`.
 *
 * @param {Function} fn The function to call for each interceptor
 */
InterceptorManager.prototype.forEach = function forEach(fn) {
  utils.forEach(this.handlers, function forEachHandler(h) {
    if (h !== null) {
      fn(h);
    }
  });
};

module.exports = InterceptorManager;


/***/ }),

/***/ "./node_modules/axios/lib/core/buildFullPath.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/core/buildFullPath.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var isAbsoluteURL = __webpack_require__(/*! ../helpers/isAbsoluteURL */ "./node_modules/axios/lib/helpers/isAbsoluteURL.js");
var combineURLs = __webpack_require__(/*! ../helpers/combineURLs */ "./node_modules/axios/lib/helpers/combineURLs.js");

/**
 * Creates a new URL by combining the baseURL with the requestedURL,
 * only when the requestedURL is not already an absolute URL.
 * If the requestURL is absolute, this function returns the requestedURL untouched.
 *
 * @param {string} baseURL The base URL
 * @param {string} requestedURL Absolute or relative URL to combine
 * @returns {string} The combined full path
 */
module.exports = function buildFullPath(baseURL, requestedURL) {
  if (baseURL && !isAbsoluteURL(requestedURL)) {
    return combineURLs(baseURL, requestedURL);
  }
  return requestedURL;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/createError.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/core/createError.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var enhanceError = __webpack_require__(/*! ./enhanceError */ "./node_modules/axios/lib/core/enhanceError.js");

/**
 * Create an Error with the specified message, config, error code, request and response.
 *
 * @param {string} message The error message.
 * @param {Object} config The config.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 * @returns {Error} The created error.
 */
module.exports = function createError(message, config, code, request, response) {
  var error = new Error(message);
  return enhanceError(error, config, code, request, response);
};


/***/ }),

/***/ "./node_modules/axios/lib/core/dispatchRequest.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/core/dispatchRequest.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var transformData = __webpack_require__(/*! ./transformData */ "./node_modules/axios/lib/core/transformData.js");
var isCancel = __webpack_require__(/*! ../cancel/isCancel */ "./node_modules/axios/lib/cancel/isCancel.js");
var defaults = __webpack_require__(/*! ../defaults */ "./node_modules/axios/lib/defaults.js");

/**
 * Throws a `Cancel` if cancellation has been requested.
 */
function throwIfCancellationRequested(config) {
  if (config.cancelToken) {
    config.cancelToken.throwIfRequested();
  }
}

/**
 * Dispatch a request to the server using the configured adapter.
 *
 * @param {object} config The config that is to be used for the request
 * @returns {Promise} The Promise to be fulfilled
 */
module.exports = function dispatchRequest(config) {
  throwIfCancellationRequested(config);

  // Ensure headers exist
  config.headers = config.headers || {};

  // Transform request data
  config.data = transformData(
    config.data,
    config.headers,
    config.transformRequest
  );

  // Flatten headers
  config.headers = utils.merge(
    config.headers.common || {},
    config.headers[config.method] || {},
    config.headers
  );

  utils.forEach(
    ['delete', 'get', 'head', 'post', 'put', 'patch', 'common'],
    function cleanHeaderConfig(method) {
      delete config.headers[method];
    }
  );

  var adapter = config.adapter || defaults.adapter;

  return adapter(config).then(function onAdapterResolution(response) {
    throwIfCancellationRequested(config);

    // Transform response data
    response.data = transformData(
      response.data,
      response.headers,
      config.transformResponse
    );

    return response;
  }, function onAdapterRejection(reason) {
    if (!isCancel(reason)) {
      throwIfCancellationRequested(config);

      // Transform response data
      if (reason && reason.response) {
        reason.response.data = transformData(
          reason.response.data,
          reason.response.headers,
          config.transformResponse
        );
      }
    }

    return Promise.reject(reason);
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/core/enhanceError.js":
/*!*****************************************************!*\
  !*** ./node_modules/axios/lib/core/enhanceError.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Update an Error with the specified config, error code, and response.
 *
 * @param {Error} error The error to update.
 * @param {Object} config The config.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 * @returns {Error} The error.
 */
module.exports = function enhanceError(error, config, code, request, response) {
  error.config = config;
  if (code) {
    error.code = code;
  }

  error.request = request;
  error.response = response;
  error.isAxiosError = true;

  error.toJSON = function() {
    return {
      // Standard
      message: this.message,
      name: this.name,
      // Microsoft
      description: this.description,
      number: this.number,
      // Mozilla
      fileName: this.fileName,
      lineNumber: this.lineNumber,
      columnNumber: this.columnNumber,
      stack: this.stack,
      // Axios
      config: this.config,
      code: this.code
    };
  };
  return error;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/mergeConfig.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/core/mergeConfig.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");

/**
 * Config-specific merge-function which creates a new config-object
 * by merging two configuration objects together.
 *
 * @param {Object} config1
 * @param {Object} config2
 * @returns {Object} New object resulting from merging config2 to config1
 */
module.exports = function mergeConfig(config1, config2) {
  // eslint-disable-next-line no-param-reassign
  config2 = config2 || {};
  var config = {};

  var valueFromConfig2Keys = ['url', 'method', 'params', 'data'];
  var mergeDeepPropertiesKeys = ['headers', 'auth', 'proxy'];
  var defaultToConfig2Keys = [
    'baseURL', 'url', 'transformRequest', 'transformResponse', 'paramsSerializer',
    'timeout', 'withCredentials', 'adapter', 'responseType', 'xsrfCookieName',
    'xsrfHeaderName', 'onUploadProgress', 'onDownloadProgress',
    'maxContentLength', 'validateStatus', 'maxRedirects', 'httpAgent',
    'httpsAgent', 'cancelToken', 'socketPath'
  ];

  utils.forEach(valueFromConfig2Keys, function valueFromConfig2(prop) {
    if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    }
  });

  utils.forEach(mergeDeepPropertiesKeys, function mergeDeepProperties(prop) {
    if (utils.isObject(config2[prop])) {
      config[prop] = utils.deepMerge(config1[prop], config2[prop]);
    } else if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    } else if (utils.isObject(config1[prop])) {
      config[prop] = utils.deepMerge(config1[prop]);
    } else if (typeof config1[prop] !== 'undefined') {
      config[prop] = config1[prop];
    }
  });

  utils.forEach(defaultToConfig2Keys, function defaultToConfig2(prop) {
    if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    } else if (typeof config1[prop] !== 'undefined') {
      config[prop] = config1[prop];
    }
  });

  var axiosKeys = valueFromConfig2Keys
    .concat(mergeDeepPropertiesKeys)
    .concat(defaultToConfig2Keys);

  var otherKeys = Object
    .keys(config2)
    .filter(function filterAxiosKeys(key) {
      return axiosKeys.indexOf(key) === -1;
    });

  utils.forEach(otherKeys, function otherKeysDefaultToConfig2(prop) {
    if (typeof config2[prop] !== 'undefined') {
      config[prop] = config2[prop];
    } else if (typeof config1[prop] !== 'undefined') {
      config[prop] = config1[prop];
    }
  });

  return config;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/settle.js":
/*!***********************************************!*\
  !*** ./node_modules/axios/lib/core/settle.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var createError = __webpack_require__(/*! ./createError */ "./node_modules/axios/lib/core/createError.js");

/**
 * Resolve or reject a Promise based on response status.
 *
 * @param {Function} resolve A function that resolves the promise.
 * @param {Function} reject A function that rejects the promise.
 * @param {object} response The response.
 */
module.exports = function settle(resolve, reject, response) {
  var validateStatus = response.config.validateStatus;
  if (!validateStatus || validateStatus(response.status)) {
    resolve(response);
  } else {
    reject(createError(
      'Request failed with status code ' + response.status,
      response.config,
      null,
      response.request,
      response
    ));
  }
};


/***/ }),

/***/ "./node_modules/axios/lib/core/transformData.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/core/transformData.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

/**
 * Transform the data for a request or a response
 *
 * @param {Object|String} data The data to be transformed
 * @param {Array} headers The headers for the request or response
 * @param {Array|Function} fns A single function or Array of functions
 * @returns {*} The resulting transformed data
 */
module.exports = function transformData(data, headers, fns) {
  /*eslint no-param-reassign:0*/
  utils.forEach(fns, function transform(fn) {
    data = fn(data, headers);
  });

  return data;
};


/***/ }),

/***/ "./node_modules/axios/lib/defaults.js":
/*!********************************************!*\
  !*** ./node_modules/axios/lib/defaults.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

var utils = __webpack_require__(/*! ./utils */ "./node_modules/axios/lib/utils.js");
var normalizeHeaderName = __webpack_require__(/*! ./helpers/normalizeHeaderName */ "./node_modules/axios/lib/helpers/normalizeHeaderName.js");

var DEFAULT_CONTENT_TYPE = {
  'Content-Type': 'application/x-www-form-urlencoded'
};

function setContentTypeIfUnset(headers, value) {
  if (!utils.isUndefined(headers) && utils.isUndefined(headers['Content-Type'])) {
    headers['Content-Type'] = value;
  }
}

function getDefaultAdapter() {
  var adapter;
  if (typeof XMLHttpRequest !== 'undefined') {
    // For browsers use XHR adapter
    adapter = __webpack_require__(/*! ./adapters/xhr */ "./node_modules/axios/lib/adapters/xhr.js");
  } else if (typeof process !== 'undefined' && Object.prototype.toString.call(process) === '[object process]') {
    // For node use HTTP adapter
    adapter = __webpack_require__(/*! ./adapters/http */ "./node_modules/axios/lib/adapters/xhr.js");
  }
  return adapter;
}

var defaults = {
  adapter: getDefaultAdapter(),

  transformRequest: [function transformRequest(data, headers) {
    normalizeHeaderName(headers, 'Accept');
    normalizeHeaderName(headers, 'Content-Type');
    if (utils.isFormData(data) ||
      utils.isArrayBuffer(data) ||
      utils.isBuffer(data) ||
      utils.isStream(data) ||
      utils.isFile(data) ||
      utils.isBlob(data)
    ) {
      return data;
    }
    if (utils.isArrayBufferView(data)) {
      return data.buffer;
    }
    if (utils.isURLSearchParams(data)) {
      setContentTypeIfUnset(headers, 'application/x-www-form-urlencoded;charset=utf-8');
      return data.toString();
    }
    if (utils.isObject(data)) {
      setContentTypeIfUnset(headers, 'application/json;charset=utf-8');
      return JSON.stringify(data);
    }
    return data;
  }],

  transformResponse: [function transformResponse(data) {
    /*eslint no-param-reassign:0*/
    if (typeof data === 'string') {
      try {
        data = JSON.parse(data);
      } catch (e) { /* Ignore */ }
    }
    return data;
  }],

  /**
   * A timeout in milliseconds to abort a request. If set to 0 (default) a
   * timeout is not created.
   */
  timeout: 0,

  xsrfCookieName: 'XSRF-TOKEN',
  xsrfHeaderName: 'X-XSRF-TOKEN',

  maxContentLength: -1,

  validateStatus: function validateStatus(status) {
    return status >= 200 && status < 300;
  }
};

defaults.headers = {
  common: {
    'Accept': 'application/json, text/plain, */*'
  }
};

utils.forEach(['delete', 'get', 'head'], function forEachMethodNoData(method) {
  defaults.headers[method] = {};
});

utils.forEach(['post', 'put', 'patch'], function forEachMethodWithData(method) {
  defaults.headers[method] = utils.merge(DEFAULT_CONTENT_TYPE);
});

module.exports = defaults;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../process/browser.js */ "./node_modules/process/browser.js")))

/***/ }),

/***/ "./node_modules/axios/lib/helpers/bind.js":
/*!************************************************!*\
  !*** ./node_modules/axios/lib/helpers/bind.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function bind(fn, thisArg) {
  return function wrap() {
    var args = new Array(arguments.length);
    for (var i = 0; i < args.length; i++) {
      args[i] = arguments[i];
    }
    return fn.apply(thisArg, args);
  };
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/buildURL.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/helpers/buildURL.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

function encode(val) {
  return encodeURIComponent(val).
    replace(/%40/gi, '@').
    replace(/%3A/gi, ':').
    replace(/%24/g, '$').
    replace(/%2C/gi, ',').
    replace(/%20/g, '+').
    replace(/%5B/gi, '[').
    replace(/%5D/gi, ']');
}

/**
 * Build a URL by appending params to the end
 *
 * @param {string} url The base of the url (e.g., http://www.google.com)
 * @param {object} [params] The params to be appended
 * @returns {string} The formatted url
 */
module.exports = function buildURL(url, params, paramsSerializer) {
  /*eslint no-param-reassign:0*/
  if (!params) {
    return url;
  }

  var serializedParams;
  if (paramsSerializer) {
    serializedParams = paramsSerializer(params);
  } else if (utils.isURLSearchParams(params)) {
    serializedParams = params.toString();
  } else {
    var parts = [];

    utils.forEach(params, function serialize(val, key) {
      if (val === null || typeof val === 'undefined') {
        return;
      }

      if (utils.isArray(val)) {
        key = key + '[]';
      } else {
        val = [val];
      }

      utils.forEach(val, function parseValue(v) {
        if (utils.isDate(v)) {
          v = v.toISOString();
        } else if (utils.isObject(v)) {
          v = JSON.stringify(v);
        }
        parts.push(encode(key) + '=' + encode(v));
      });
    });

    serializedParams = parts.join('&');
  }

  if (serializedParams) {
    var hashmarkIndex = url.indexOf('#');
    if (hashmarkIndex !== -1) {
      url = url.slice(0, hashmarkIndex);
    }

    url += (url.indexOf('?') === -1 ? '?' : '&') + serializedParams;
  }

  return url;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/combineURLs.js":
/*!*******************************************************!*\
  !*** ./node_modules/axios/lib/helpers/combineURLs.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Creates a new URL by combining the specified URLs
 *
 * @param {string} baseURL The base URL
 * @param {string} relativeURL The relative URL
 * @returns {string} The combined URL
 */
module.exports = function combineURLs(baseURL, relativeURL) {
  return relativeURL
    ? baseURL.replace(/\/+$/, '') + '/' + relativeURL.replace(/^\/+/, '')
    : baseURL;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/cookies.js":
/*!***************************************************!*\
  !*** ./node_modules/axios/lib/helpers/cookies.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

module.exports = (
  utils.isStandardBrowserEnv() ?

  // Standard browser envs support document.cookie
    (function standardBrowserEnv() {
      return {
        write: function write(name, value, expires, path, domain, secure) {
          var cookie = [];
          cookie.push(name + '=' + encodeURIComponent(value));

          if (utils.isNumber(expires)) {
            cookie.push('expires=' + new Date(expires).toGMTString());
          }

          if (utils.isString(path)) {
            cookie.push('path=' + path);
          }

          if (utils.isString(domain)) {
            cookie.push('domain=' + domain);
          }

          if (secure === true) {
            cookie.push('secure');
          }

          document.cookie = cookie.join('; ');
        },

        read: function read(name) {
          var match = document.cookie.match(new RegExp('(^|;\\s*)(' + name + ')=([^;]*)'));
          return (match ? decodeURIComponent(match[3]) : null);
        },

        remove: function remove(name) {
          this.write(name, '', Date.now() - 86400000);
        }
      };
    })() :

  // Non standard browser env (web workers, react-native) lack needed support.
    (function nonStandardBrowserEnv() {
      return {
        write: function write() {},
        read: function read() { return null; },
        remove: function remove() {}
      };
    })()
);


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isAbsoluteURL.js":
/*!*********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isAbsoluteURL.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Determines whether the specified URL is absolute
 *
 * @param {string} url The URL to test
 * @returns {boolean} True if the specified URL is absolute, otherwise false
 */
module.exports = function isAbsoluteURL(url) {
  // A URL is considered absolute if it begins with "<scheme>://" or "//" (protocol-relative URL).
  // RFC 3986 defines scheme name as a sequence of characters beginning with a letter and followed
  // by any combination of letters, digits, plus, period, or hyphen.
  return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(url);
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isURLSameOrigin.js":
/*!***********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isURLSameOrigin.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

module.exports = (
  utils.isStandardBrowserEnv() ?

  // Standard browser envs have full support of the APIs needed to test
  // whether the request URL is of the same origin as current location.
    (function standardBrowserEnv() {
      var msie = /(msie|trident)/i.test(navigator.userAgent);
      var urlParsingNode = document.createElement('a');
      var originURL;

      /**
    * Parse a URL to discover it's components
    *
    * @param {String} url The URL to be parsed
    * @returns {Object}
    */
      function resolveURL(url) {
        var href = url;

        if (msie) {
        // IE needs attribute set twice to normalize properties
          urlParsingNode.setAttribute('href', href);
          href = urlParsingNode.href;
        }

        urlParsingNode.setAttribute('href', href);

        // urlParsingNode provides the UrlUtils interface - http://url.spec.whatwg.org/#urlutils
        return {
          href: urlParsingNode.href,
          protocol: urlParsingNode.protocol ? urlParsingNode.protocol.replace(/:$/, '') : '',
          host: urlParsingNode.host,
          search: urlParsingNode.search ? urlParsingNode.search.replace(/^\?/, '') : '',
          hash: urlParsingNode.hash ? urlParsingNode.hash.replace(/^#/, '') : '',
          hostname: urlParsingNode.hostname,
          port: urlParsingNode.port,
          pathname: (urlParsingNode.pathname.charAt(0) === '/') ?
            urlParsingNode.pathname :
            '/' + urlParsingNode.pathname
        };
      }

      originURL = resolveURL(window.location.href);

      /**
    * Determine if a URL shares the same origin as the current location
    *
    * @param {String} requestURL The URL to test
    * @returns {boolean} True if URL shares the same origin, otherwise false
    */
      return function isURLSameOrigin(requestURL) {
        var parsed = (utils.isString(requestURL)) ? resolveURL(requestURL) : requestURL;
        return (parsed.protocol === originURL.protocol &&
            parsed.host === originURL.host);
      };
    })() :

  // Non standard browser envs (web workers, react-native) lack needed support.
    (function nonStandardBrowserEnv() {
      return function isURLSameOrigin() {
        return true;
      };
    })()
);


/***/ }),

/***/ "./node_modules/axios/lib/helpers/normalizeHeaderName.js":
/*!***************************************************************!*\
  !*** ./node_modules/axios/lib/helpers/normalizeHeaderName.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");

module.exports = function normalizeHeaderName(headers, normalizedName) {
  utils.forEach(headers, function processHeader(value, name) {
    if (name !== normalizedName && name.toUpperCase() === normalizedName.toUpperCase()) {
      headers[normalizedName] = value;
      delete headers[name];
    }
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/parseHeaders.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/parseHeaders.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

// Headers whose duplicates are ignored by node
// c.f. https://nodejs.org/api/http.html#http_message_headers
var ignoreDuplicateOf = [
  'age', 'authorization', 'content-length', 'content-type', 'etag',
  'expires', 'from', 'host', 'if-modified-since', 'if-unmodified-since',
  'last-modified', 'location', 'max-forwards', 'proxy-authorization',
  'referer', 'retry-after', 'user-agent'
];

/**
 * Parse headers into an object
 *
 * ```
 * Date: Wed, 27 Aug 2014 08:58:49 GMT
 * Content-Type: application/json
 * Connection: keep-alive
 * Transfer-Encoding: chunked
 * ```
 *
 * @param {String} headers Headers needing to be parsed
 * @returns {Object} Headers parsed into an object
 */
module.exports = function parseHeaders(headers) {
  var parsed = {};
  var key;
  var val;
  var i;

  if (!headers) { return parsed; }

  utils.forEach(headers.split('\n'), function parser(line) {
    i = line.indexOf(':');
    key = utils.trim(line.substr(0, i)).toLowerCase();
    val = utils.trim(line.substr(i + 1));

    if (key) {
      if (parsed[key] && ignoreDuplicateOf.indexOf(key) >= 0) {
        return;
      }
      if (key === 'set-cookie') {
        parsed[key] = (parsed[key] ? parsed[key] : []).concat([val]);
      } else {
        parsed[key] = parsed[key] ? parsed[key] + ', ' + val : val;
      }
    }
  });

  return parsed;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/spread.js":
/*!**************************************************!*\
  !*** ./node_modules/axios/lib/helpers/spread.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Syntactic sugar for invoking a function and expanding an array for arguments.
 *
 * Common use case would be to use `Function.prototype.apply`.
 *
 *  ```js
 *  function f(x, y, z) {}
 *  var args = [1, 2, 3];
 *  f.apply(null, args);
 *  ```
 *
 * With `spread` this example can be re-written.
 *
 *  ```js
 *  spread(function(x, y, z) {})([1, 2, 3]);
 *  ```
 *
 * @param {Function} callback
 * @returns {Function}
 */
module.exports = function spread(callback) {
  return function wrap(arr) {
    return callback.apply(null, arr);
  };
};


/***/ }),

/***/ "./node_modules/axios/lib/utils.js":
/*!*****************************************!*\
  !*** ./node_modules/axios/lib/utils.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var bind = __webpack_require__(/*! ./helpers/bind */ "./node_modules/axios/lib/helpers/bind.js");

/*global toString:true*/

// utils is a library of generic helper functions non-specific to axios

var toString = Object.prototype.toString;

/**
 * Determine if a value is an Array
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Array, otherwise false
 */
function isArray(val) {
  return toString.call(val) === '[object Array]';
}

/**
 * Determine if a value is undefined
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if the value is undefined, otherwise false
 */
function isUndefined(val) {
  return typeof val === 'undefined';
}

/**
 * Determine if a value is a Buffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Buffer, otherwise false
 */
function isBuffer(val) {
  return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor)
    && typeof val.constructor.isBuffer === 'function' && val.constructor.isBuffer(val);
}

/**
 * Determine if a value is an ArrayBuffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an ArrayBuffer, otherwise false
 */
function isArrayBuffer(val) {
  return toString.call(val) === '[object ArrayBuffer]';
}

/**
 * Determine if a value is a FormData
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an FormData, otherwise false
 */
function isFormData(val) {
  return (typeof FormData !== 'undefined') && (val instanceof FormData);
}

/**
 * Determine if a value is a view on an ArrayBuffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a view on an ArrayBuffer, otherwise false
 */
function isArrayBufferView(val) {
  var result;
  if ((typeof ArrayBuffer !== 'undefined') && (ArrayBuffer.isView)) {
    result = ArrayBuffer.isView(val);
  } else {
    result = (val) && (val.buffer) && (val.buffer instanceof ArrayBuffer);
  }
  return result;
}

/**
 * Determine if a value is a String
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a String, otherwise false
 */
function isString(val) {
  return typeof val === 'string';
}

/**
 * Determine if a value is a Number
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Number, otherwise false
 */
function isNumber(val) {
  return typeof val === 'number';
}

/**
 * Determine if a value is an Object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Object, otherwise false
 */
function isObject(val) {
  return val !== null && typeof val === 'object';
}

/**
 * Determine if a value is a Date
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Date, otherwise false
 */
function isDate(val) {
  return toString.call(val) === '[object Date]';
}

/**
 * Determine if a value is a File
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a File, otherwise false
 */
function isFile(val) {
  return toString.call(val) === '[object File]';
}

/**
 * Determine if a value is a Blob
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Blob, otherwise false
 */
function isBlob(val) {
  return toString.call(val) === '[object Blob]';
}

/**
 * Determine if a value is a Function
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Function, otherwise false
 */
function isFunction(val) {
  return toString.call(val) === '[object Function]';
}

/**
 * Determine if a value is a Stream
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Stream, otherwise false
 */
function isStream(val) {
  return isObject(val) && isFunction(val.pipe);
}

/**
 * Determine if a value is a URLSearchParams object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a URLSearchParams object, otherwise false
 */
function isURLSearchParams(val) {
  return typeof URLSearchParams !== 'undefined' && val instanceof URLSearchParams;
}

/**
 * Trim excess whitespace off the beginning and end of a string
 *
 * @param {String} str The String to trim
 * @returns {String} The String freed of excess whitespace
 */
function trim(str) {
  return str.replace(/^\s*/, '').replace(/\s*$/, '');
}

/**
 * Determine if we're running in a standard browser environment
 *
 * This allows axios to run in a web worker, and react-native.
 * Both environments support XMLHttpRequest, but not fully standard globals.
 *
 * web workers:
 *  typeof window -> undefined
 *  typeof document -> undefined
 *
 * react-native:
 *  navigator.product -> 'ReactNative'
 * nativescript
 *  navigator.product -> 'NativeScript' or 'NS'
 */
function isStandardBrowserEnv() {
  if (typeof navigator !== 'undefined' && (navigator.product === 'ReactNative' ||
                                           navigator.product === 'NativeScript' ||
                                           navigator.product === 'NS')) {
    return false;
  }
  return (
    typeof window !== 'undefined' &&
    typeof document !== 'undefined'
  );
}

/**
 * Iterate over an Array or an Object invoking a function for each item.
 *
 * If `obj` is an Array callback will be called passing
 * the value, index, and complete array for each item.
 *
 * If 'obj' is an Object callback will be called passing
 * the value, key, and complete object for each property.
 *
 * @param {Object|Array} obj The object to iterate
 * @param {Function} fn The callback to invoke for each item
 */
function forEach(obj, fn) {
  // Don't bother if no value provided
  if (obj === null || typeof obj === 'undefined') {
    return;
  }

  // Force an array if not already something iterable
  if (typeof obj !== 'object') {
    /*eslint no-param-reassign:0*/
    obj = [obj];
  }

  if (isArray(obj)) {
    // Iterate over array values
    for (var i = 0, l = obj.length; i < l; i++) {
      fn.call(null, obj[i], i, obj);
    }
  } else {
    // Iterate over object keys
    for (var key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        fn.call(null, obj[key], key, obj);
      }
    }
  }
}

/**
 * Accepts varargs expecting each argument to be an object, then
 * immutably merges the properties of each object and returns result.
 *
 * When multiple objects contain the same key the later object in
 * the arguments list will take precedence.
 *
 * Example:
 *
 * ```js
 * var result = merge({foo: 123}, {foo: 456});
 * console.log(result.foo); // outputs 456
 * ```
 *
 * @param {Object} obj1 Object to merge
 * @returns {Object} Result of all merge properties
 */
function merge(/* obj1, obj2, obj3, ... */) {
  var result = {};
  function assignValue(val, key) {
    if (typeof result[key] === 'object' && typeof val === 'object') {
      result[key] = merge(result[key], val);
    } else {
      result[key] = val;
    }
  }

  for (var i = 0, l = arguments.length; i < l; i++) {
    forEach(arguments[i], assignValue);
  }
  return result;
}

/**
 * Function equal to merge with the difference being that no reference
 * to original objects is kept.
 *
 * @see merge
 * @param {Object} obj1 Object to merge
 * @returns {Object} Result of all merge properties
 */
function deepMerge(/* obj1, obj2, obj3, ... */) {
  var result = {};
  function assignValue(val, key) {
    if (typeof result[key] === 'object' && typeof val === 'object') {
      result[key] = deepMerge(result[key], val);
    } else if (typeof val === 'object') {
      result[key] = deepMerge({}, val);
    } else {
      result[key] = val;
    }
  }

  for (var i = 0, l = arguments.length; i < l; i++) {
    forEach(arguments[i], assignValue);
  }
  return result;
}

/**
 * Extends object a by mutably adding to it the properties of object b.
 *
 * @param {Object} a The object to be extended
 * @param {Object} b The object to copy properties from
 * @param {Object} thisArg The object to bind function to
 * @return {Object} The resulting value of object a
 */
function extend(a, b, thisArg) {
  forEach(b, function assignValue(val, key) {
    if (thisArg && typeof val === 'function') {
      a[key] = bind(val, thisArg);
    } else {
      a[key] = val;
    }
  });
  return a;
}

module.exports = {
  isArray: isArray,
  isArrayBuffer: isArrayBuffer,
  isBuffer: isBuffer,
  isFormData: isFormData,
  isArrayBufferView: isArrayBufferView,
  isString: isString,
  isNumber: isNumber,
  isObject: isObject,
  isUndefined: isUndefined,
  isDate: isDate,
  isFile: isFile,
  isBlob: isBlob,
  isFunction: isFunction,
  isStream: isStream,
  isURLSearchParams: isURLSearchParams,
  isStandardBrowserEnv: isStandardBrowserEnv,
  forEach: forEach,
  merge: merge,
  deepMerge: deepMerge,
  extend: extend,
  trim: trim
};


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Add/Add.scss":
/*!****************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Add/Add.scss ***!
  \****************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".add {\n  padding: 8px;\n  background-color: #f9f9f9;\n  box-sizing: border-box;\n  display: grid;\n  grid-template-rows: auto;\n  row-gap: 8px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Add/layout/AddObject.scss":
/*!*****************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Add/layout/AddObject.scss ***!
  \*****************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".add-object {\n  box-sizing: border-box;\n  display: grid;\n  grid-template-rows: auto;\n  row-gap: 8px;\n}\n.add-object .add-object-form {\n  display: grid;\n  grid-template-rows: auto;\n  row-gap: 8px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/Auth.scss":
/*!******************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/Auth.scss ***!
  \******************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".auth {\n  background-color: #f9f9f9;\n  padding: 8px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/layout/SiteTitle.scss":
/*!******************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/layout/SiteTitle.scss ***!
  \******************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".site-title {\n  width: 100%;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: space-between;\n  color: #526a78;\n  font-weight: bold;\n  fill: #526a78;\n}\n.site-title .site-title-host {\n  flex-grow: 1;\n  overflow: hidden;\n}\n.site-title.online {\n  fill: #03a388;\n}\n.site-title .site-title-icons {\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  margin-left: 8px;\n}\n.site-title .site-title-icons .icon {\n  height: 24px;\n  width: 24px;\n}\n.site-title .icon:not(:last-child) {\n  margin-right: 8px;\n}\n.site-title .icon.icon-warning {\n  fill: #f59815;\n}\n.site-title .icon.icon-error {\n  fill: #c5283e;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/login/Login.scss":
/*!*************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/login/Login.scss ***!
  \*************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".login {\n  display: grid;\n  grid-template-rows: 1fr auto;\n  height: 100%;\n  overflow: hidden auto;\n}\n.login .login-form {\n  overflow: hidden auto;\n}\n.login .form {\n  display: flex;\n  flex-direction: column;\n}\n.login label:not(:last-child),\n.login .button:not(:last-child),\n.login .message:not(:last-child) {\n  margin-bottom: 8px;\n}\n.login .message {\n  margin-top: 8px;\n}\n.login .label-inline {\n  justify-content: space-between;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/sessionStatus/SessionStatus.scss":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/sessionStatus/SessionStatus.scss ***!
  \*****************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".session-status {\n  display: grid;\n  row-gap: 8px;\n}\n.session-status .warnings-title {\n  color: #f59815;\n}\n.session-status .errors-title {\n  color: #c5283e;\n}\n.session-status .button {\n  width: 100%;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/DebugStorage/DebugStorage.scss":
/*!**********************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/DebugStorage/DebugStorage.scss ***!
  \**********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".debug-storage ul {\n  margin-left: 40px;\n}\n.debug-storage ul,\n.debug-storage li {\n  list-style: disc;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/Options.scss":
/*!************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/Options.scss ***!
  \************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".options {\n  background-color: #f9f9f9;\n  padding: 8px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/layout/BlacklistOptions.scss":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/layout/BlacklistOptions.scss ***!
  \****************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".blacklist-options {\n  background-color: #f9f9f9;\n  display: flex;\n  flex-direction: column;\n}\n.blacklist-options .blacklist-options-article {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  background-color: #fff;\n}\n.blacklist-options .blacklist-options-article:nth-child(odd) {\n  background-color: #f3f7f8;\n}\n.blacklist-options .blacklist-options-article .blacklist-options-host {\n  padding: 8px;\n  overflow: hidden;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/layout/GeneralOptions.scss":
/*!**************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/layout/GeneralOptions.scss ***!
  \**************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".general-options {\n  background-color: #f9f9f9;\n}\n.general-options .general-options-form {\n  display: grid;\n  grid-template-rows: auto;\n  row-gap: 8px;\n}\n.general-options .general-options-field:hover {\n  background-color: #fff;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/layout/SiteOptions.scss":
/*!***********************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/layout/SiteOptions.scss ***!
  \***********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".site-options {\n  background-color: #f9f9f9;\n  display: grid;\n  grid-template-rows: auto;\n  row-gap: 8px;\n}\n.site-options .site-options-add form {\n  display: grid;\n  grid-template-rows: auto;\n  row-gap: 8px;\n}\n.site-options .site-options-site {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  background-color: #fff;\n}\n.site-options .site-options-site:nth-child(odd) {\n  background-color: #f3f7f8;\n}\n.site-options .site-options-site .site-options-host {\n  padding: 8px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Popup/Popup.scss":
/*!********************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Popup/Popup.scss ***!
  \********************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".popup {\n  background-color: #526a78;\n  width: 360px;\n  overflow: hidden;\n}\n.popup .banner {\n  padding-bottom: 0;\n}\n.popup .logo {\n  text-align: center;\n  max-width: 100%;\n  max-height: 32px;\n  margin: 0 auto;\n}\n.popup .popup-page {\n  margin: 8px;\n  margin-top: 0;\n  overflow: hidden auto;\n  box-sizing: border-box;\n  max-height: 400px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Popup/layout/TopMenu.scss":
/*!*****************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Popup/layout/TopMenu.scss ***!
  \*****************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".top-menu {\n  display: grid;\n  grid-template-columns: 1fr auto;\n  grid-column-gap: 8px;\n  row-gap: 8px;\n  align-items: center;\n  padding: 8px;\n  height: 100%;\n}\n.top-menu .menu-button.selected {\n  border-radius: 8px 8px 0 0;\n}\n.top-menu .menu {\n  grid-column-start: 1;\n  grid-column-end: 3;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Popup/layout/Welcome.scss":
/*!*****************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Popup/layout/Welcome.scss ***!
  \*****************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".welcome {\n  display: grid;\n  grid-template-rows: auto;\n  row-gap: 8px;\n  box-sizing: border-box;\n  width: 100%;\n}\n.welcome .welcome-article {\n  padding: 8px;\n  background-color: #fff;\n  box-sizing: border-box;\n}\n.welcome .welcome-message {\n  display: grid;\n  grid-template-rows: auto;\n  row-gap: 8px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Save/Save.scss":
/*!******************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Save/Save.scss ***!
  \******************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".save {\n  background-color: #526a78;\n  padding: 8px;\n  box-sizing: border-box;\n  display: grid;\n  grid-template-rows: auto;\n  row-gap: 8px;\n  height: 100vh;\n}\n.save .save-form {\n  height: 100%;\n  display: grid;\n  grid-template-rows: auto;\n  row-gap: 8px;\n  overflow: hidden;\n}\n.save .save-fields {\n  background-color: #f9f9f9;\n  padding: 8px;\n  overflow: auto scroll;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Search/layout/ObjectView.scss":
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Search/layout/ObjectView.scss ***!
  \*********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".object-view {\n  height: 100%;\n  overflow: hidden auto;\n  max-height: 100%;\n}\n.object-view .object-view-container {\n  overflow: hidden auto;\n  max-height: 100%;\n}\n.object-view .object-view-host {\n  text-align: center;\n  color: #526a78;\n}\n.object-view .object-view-field {\n  padding: 8px;\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  transition: background-color 0.1s;\n}\n.object-view .object-view-field:hover {\n  background-color: #f3f7f8;\n}\n.object-view .object-view-field:hover .object-view-field-copy {\n  opacity: 1;\n}\n.object-view .object-view-fill {\n  width: 100%;\n}\n.object-view .object-view-field-text {\n  display: flex;\n  flex-direction: column;\n}\n.object-view .object-view-field-copy {\n  padding: 8px;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  border: 0;\n  outline: 0;\n  background: transparent;\n  color: #03a388;\n  font-weight: bold;\n  cursor: pointer;\n  transition: 0.1s;\n  transition-property: opacity, background-color, color;\n  opacity: 0;\n}\n.object-view .object-view-field-copy:active {\n  background-color: #03a388;\n  color: #fff;\n}\n.object-view .field-title {\n  font-size: 0.8em;\n  color: #526a78;\n}\n.object-view .field-value .number {\n  color: #c5283e;\n}\n.object-view .field-value .uppercase {\n  color: #03a388;\n  font-weight: bold;\n}\n.object-view .field-value .lowercase {\n  color: #526a78;\n}\n.object-view .field-value .symbol {\n  color: #f59815;\n}\n.object-view .field-value .show {\n  border: 0;\n  outline: 0;\n  background: none;\n  color: #c5283e;\n  cursor: pointer;\n  font-size: 1em;\n  font-weight: normal;\n  padding: 0 inherit 0 0;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Search/layout/SearchTitle.scss":
/*!**********************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/Search/layout/SearchTitle.scss ***!
  \**********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".search-title {\n  background-repeat: no-repeat;\n  background-size: 24px;\n  background-position: left center;\n  padding-left: 40px;\n}\n.search-title .search-title-host {\n  color: #526a78;\n  font-size: 0.9em;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Button.scss":
/*!****************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Button.scss ***!
  \****************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".button {\n  border: 0;\n  outline: 0;\n  background: none;\n}\n\n.button {\n  position: relative;\n  display: inline-flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: center;\n  transition: 0.1s;\n  transition-property: border-color, background-color, color, width;\n  font-family: \"Roboto\", sans-serif;\n  padding: 8px;\n  border: 1px solid #526a78;\n  background-color: #526a78;\n  color: #fff;\n  cursor: pointer;\n  font-weight: bold;\n  font-size: 12pt;\n  transition: padding-right 0.1s;\n}\n.button.button-loading {\n  padding-right: 32px;\n}\n.button .button-spinner {\n  position: absolute;\n  right: 8px;\n  margin-left: 8px;\n  width: 12pt;\n  height: 12pt;\n  opacity: 0;\n  transition: opacity 0.1s;\n}\n.button .button-spinner::after {\n  position: absolute;\n  content: \"\";\n  border-radius: 100%;\n  box-sizing: border-box;\n  left: 0;\n  top: 0;\n  height: 100%;\n  width: 100%;\n  border: 2pt solid #fff;\n  border-top-color: #03a388;\n  -webkit-animation: spin 1s infinite;\n          animation: spin 1s infinite;\n  transition: all 0.3s;\n}\n.button.button-loading .button-spinner {\n  opacity: 1;\n}\n@-webkit-keyframes spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n}\n@keyframes spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n}\n.button:disabled {\n  cursor: arrow;\n}\n.button:hover:not(:disabled) {\n  background-color: #fff;\n  color: #526a78;\n}\n.button:focus:not(:disabled) {\n  background-color: #fff;\n  color: #526a78;\n}\n.button:active:not(:disabled) {\n  background-color: #f3f7f8;\n}\n.button.button-accent {\n  background-color: #03a388;\n  border-color: #03a388;\n}\n.button.button-accent:hover {\n  color: #03a388;\n}\n.button.button-accent:focus {\n  color: #03a388;\n}\n.button.button-accent:active {\n  background-color: #bff8ef;\n}\n.button.button-warning {\n  background-color: #f59815;\n  border-color: #f59815;\n}\n.button.button-warning:hover {\n  color: #f59815;\n}\n.button.button-warning:focus {\n  color: #f59815;\n}\n.button.button-warning:active {\n  background-color: #fff3e2;\n}\n.button.button-danger {\n  background-color: #c5283e;\n  border-color: #c5283e;\n}\n.button.button-danger:hover {\n  color: #c5283e;\n}\n.button.button-danger:focus {\n  color: #c5283e;\n}\n.button.button-danger:active {\n  background-color: #fdd2d8;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Checkbox.scss":
/*!******************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Checkbox.scss ***!
  \******************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".checkbox input {\n  height: 0;\n  opacity: 0;\n  position: absolute;\n  width: 0;\n}\n.checkbox .custom-checkbox {\n  padding: 2px;\n  position: relative;\n  border: 1px solid #d4d7d8;\n  border-radius: 2px;\n  box-shadow: 0 0 3px 0 rgba(0, 0, 0, 0.1) inset;\n  width: 20px;\n  height: 20px;\n  cursor: pointer;\n  box-sizing: border-box;\n}\n.checkbox .custom-checkbox::before {\n  display: none;\n  position: absolute;\n  content: \"\";\n  width: 14px;\n  height: 14px;\n  background-color: #03a388;\n  box-shadow: 0 0 3px 0 rgba(0, 0, 0, 0.1);\n  border-radius: 2px;\n}\n.checkbox input:checked ~ .custom-checkbox::before {\n  display: block;\n}\n.checkbox input:hover ~ .custom-checkbox,\n.checkbox input:active ~ .custom-checkbox,\n.checkbox input:focus ~ .custom-checkbox {\n  box-shadow: 0 0 3px 0 rgba(0, 0, 0, 0.1) inset, 0 0 3px 0 rgba(0, 0, 0, 0.1);\n}\n.checkbox input:hover ~ .custom-checkbox {\n  border-color: #c7cacc;\n  background-color: #f9fbfc;\n}\n.checkbox input:focus ~ .custom-checkbox {\n  border-color: #03a388;\n  background-color: #f9fbfc;\n}\n.checkbox input:active ~ .custom-checkbox {\n  border-color: #d4d7d8;\n  background-color: #ebeef0;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/MenuButton.scss":
/*!********************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/MenuButton.scss ***!
  \********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".menu-button {\n  border: 0;\n  outline: 0;\n  background-color: #2e424f;\n  cursor: pointer;\n  height: 40px;\n  width: 40px;\n  padding: 8px;\n  transition: background-color 0.1s;\n  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);\n  border-radius: 0 8px 8px 8px;\n  box-sizing: border-box;\n}\n.menu-button > * {\n  height: 100%;\n  width: 100%;\n}\n.menu-button > svg {\n  fill: #fff;\n  transition: fill 0.1s;\n}\n.menu-button:hover, .menu-button:focus {\n  background-color: #fff;\n}\n.menu-button:hover > svg, .menu-button:focus > svg {\n  fill: #2e424f;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Radio.scss":
/*!***************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Radio.scss ***!
  \***************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".radio input {\n  height: 0;\n  opacity: 0;\n  position: absolute;\n  width: 0;\n}\n.radio .custom-radio {\n  padding: 2px;\n  position: relative;\n  border-radius: 100%;\n  border: 1px solid #d4d7d8;\n  box-shadow: 0 0 3px 0 rgba(0, 0, 0, 0.1) inset;\n  width: 16px;\n  height: 16px;\n  box-sizing: border-box;\n}\n.radio .custom-radio::after {\n  display: none;\n  position: absolute;\n  border-radius: 100%;\n  content: \"\";\n  width: 10px;\n  height: 10px;\n  background-color: #03a388;\n}\n.radio input:checked ~ .custom-radio::after {\n  display: block;\n}\n.radio input:hover ~ .custom-radio,\n.radio input:active ~ .custom-radio,\n.radio input:focus ~ .custom-radio {\n  box-shadow: 0 0 3px 0 rgba(0, 0, 0, 0.1) inset, 0 0 3px 0 rgba(0, 0, 0, 0.1);\n}\n.radio input:hover ~ .custom-radio {\n  border-color: #c7cacc;\n  background-color: #f9fbfc;\n}\n.radio input:focus ~ .custom-radio {\n  border-color: #03a388;\n  background-color: #f9fbfc;\n}\n.radio input:active ~ .custom-radio {\n  border-color: #028c73;\n  background-color: #ebeef0;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/SearchBar.scss":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/SearchBar.scss ***!
  \*******************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".search-bar .search-form {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n}\n.search-bar .search-bar-input {\n  flex-grow: 1;\n  height: 40px;\n  background: #2e424f;\n  color: #fff;\n  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);\n  border-bottom-color: #2e424f;\n}\n.search-bar .search-bar-input:focus {\n  border-bottom-color: #03a388;\n}\n.search-bar .search-bar-input:active {\n  border-bottom-color: #006352;\n}\n.search-bar .search-bar-input:disabled {\n  background-color: #3c4145 !important;\n  color: #ad9f9f !important;\n  border-color: #3c4145;\n}\n.search-bar .search-button {\n  background-color: #03a388;\n  border-bottom-left-radius: 0;\n  height: 40px;\n  width: 40px;\n  transition: 0.1s;\n}\n.search-bar .search-button:hover, .search-bar .search-button:focus {\n  background-color: #fff;\n}\n.search-bar .search-button:hover > svg, .search-bar .search-button:focus > svg {\n  fill: #03a388;\n}\n.search-bar .search-button.loading > svg {\n  fill: transparent;\n  stroke: #fff;\n  stroke-width: 0.5;\n  stroke-dasharray: 32;\n  -webkit-animation: loading 2s ease-in-out alternate infinite;\n          animation: loading 2s ease-in-out alternate infinite;\n}\n.search-bar .search-button:hover.loading > svg, .search-bar .search-button:focus.loading > svg {\n  fill: transparent;\n  stroke: #03a388;\n}\n.search-bar .search-button:disabled {\n  background-color: #3c4145 !important;\n  color: #ad9f9f !important;\n}\n.search-bar .search-button:disabled > svg {\n  fill: #ad9f9f !important;\n}\n\n@-webkit-keyframes loading {\n  0% {\n    stroke-dashoffset: 0;\n  }\n  10% {\n    stroke-dashoffset: 0;\n  }\n  90% {\n    stroke-dashoffset: 64;\n  }\n  100% {\n    stroke-dashoffset: 64;\n  }\n}\n\n@keyframes loading {\n  0% {\n    stroke-dashoffset: 0;\n  }\n  10% {\n    stroke-dashoffset: 0;\n  }\n  90% {\n    stroke-dashoffset: 64;\n  }\n  100% {\n    stroke-dashoffset: 64;\n  }\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Select.scss":
/*!****************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Select.scss ***!
  \****************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".select .custom-select::after {\n  border: solid transparent;\n  border-top-color: #2e424f;\n  border-width: 8px 5px;\n  box-sizing: border-box;\n  content: \"\";\n  height: 16px;\n  margin-top: -0.2em;\n  position: absolute;\n  right: 8px;\n  top: 50%;\n  transform-origin: 4px 2.5px;\n  width: 10px;\n  pointer-events: none;\n}\n\n.select .custom-select select {\n  -moz-appearance: none;\n  -webkit-appearance: none;\n  appearance: none;\n  padding-right: 24px;\n  width: 100%;\n  border: 1px solid #d4d7d8;\n  cursor: pointer;\n  transition: border-color 0.1s;\n}\n.select .custom-select select:hover {\n  border-color: #c7cacc;\n}\n.select .custom-select select:focus {\n  border-color: #03a388;\n}\n.select .custom-select {\n  position: relative;\n  width: 100%;\n}\n.select .custom-select::after {\n  transition: 0.1s;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Banner.scss":
/*!*****************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Banner.scss ***!
  \*****************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".banner {\n  background-color: #526a78;\n  padding: 12px;\n  width: 100%;\n  box-sizing: border-box;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/ListView.scss":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/ListView.scss ***!
  \*******************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".list-view {\n  height: 100%;\n  overflow: hidden auto;\n}\n.list-view.has-selected {\n  overflow: hidden;\n}\n.list-view .list-view-item-title {\n  padding: 8px;\n  background-color: #f9f9f9;\n  color: #232d33;\n  cursor: pointer;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.1);\n}\n.list-view .list-view-item-title:hover {\n  background-color: #fff;\n}\n.list-view .list-view-item-content {\n  display: none;\n  background-color: #f9f9f9;\n  color: #232d33;\n  padding: 8px;\n  overflow: hidden auto;\n  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.1);\n}\n.list-view .list-view-item.selected {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n}\n.list-view .list-view-item.selected .list-view-item-title {\n  position: relative;\n  padding-left: 16px;\n}\n.list-view .list-view-item.selected .list-view-item-title::before {\n  position: absolute;\n  left: 0;\n  top: 50%;\n  content: \"\";\n  border: solid #526a78;\n  border-width: 2px 0 0 2px;\n  display: inline-block;\n  width: 6px;\n  height: 6px;\n  transform: rotate(-45deg);\n  margin: -4px 0 0 5.5px;\n}\n.list-view .list-view-item.selected .list-view-item-content {\n  display: block;\n  flex-grow: 1;\n}\n.list-view .list-view-item.hidden .list-view-item-title {\n  display: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/LoadingComponent.scss":
/*!***************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/LoadingComponent.scss ***!
  \***************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".loading-component {\n  display: grid;\n  width: 100%;\n  height: 100%;\n  justify-content: center;\n  align-items: center;\n  box-sizing: border-box;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/LoadingSpinner.scss":
/*!*************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/LoadingSpinner.scss ***!
  \*************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(/*! ../../../../graphics/padlock.svg */ "./graphics/padlock.svg");
var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(/*! ../../../../graphics/padlock-error.svg */ "./graphics/padlock-error.svg");
var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(/*! ../../../../graphics/padlock-warning.svg */ "./graphics/padlock-warning.svg");
var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(/*! ../../../../graphics/padlock-unlocked.svg */ "./graphics/padlock-unlocked.svg");
exports = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
// Module
exports.push([module.i, ".loading-spinner {\n  position: relative;\n  height: 3em;\n  width: 3em;\n}\n.loading-spinner .spinner::after, .loading-spinner .spinner::before {\n  position: absolute;\n  content: \"\";\n  border-radius: 100%;\n  box-sizing: border-box;\n  left: 0;\n  top: 0;\n  height: 100%;\n  width: 100%;\n}\n.loading-spinner .spinner::after {\n  border: 0.3em solid #fff;\n  border-top-color: #03a388;\n  -webkit-animation: spin 1s infinite;\n          animation: spin 1s infinite;\n  transition: all 0.3s;\n  z-index: 100;\n}\n.loading-spinner .spinner::before {\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");\n  background-size: contain;\n  border: 0;\n  transition: all 0.3s;\n}\n.loading-spinner .spinner.error::after, .loading-spinner .spinner.warning::after, .loading-spinner .spinner.success::after {\n  -webkit-animation: none;\n          animation: none;\n  border: 0;\n}\n.loading-spinner .spinner.error::before {\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");\n  border-color: #c5283e;\n}\n.loading-spinner .spinner.warning::before {\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ");\n  border-color: #f59815;\n}\n.loading-spinner .spinner.success::before {\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ");\n  border-color: #03a388;\n}\n\n@-webkit-keyframes spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n}\n\n@keyframes spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Logo.scss":
/*!***************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Logo.scss ***!
  \***************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".logo {\n  display: block;\n  max-height: 100%;\n  max-width: 100%;\n  box-sizing: border-box;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Menu.scss":
/*!***************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Menu.scss ***!
  \***************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".menu {\n  max-height: 0;\n  width: 100%;\n  z-index: 1;\n  overflow: hidden;\n}\n.menu.show {\n  width: 100%;\n  max-height: 100%;\n  transition: 0.1s;\n}\n.menu .menu-box {\n  position: relative;\n  overflow: hidden;\n  background-color: #2e424f;\n  display: flex;\n  flex-direction: column;\n}\n.menu .menu-item {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  color: #fff;\n  padding: 8px;\n  transition: 0.1s;\n}\n.menu .menu-item:hover {\n  background-color: #03a388;\n}\n.menu .menu-item > svg {\n  fill: #fff;\n  width: 24px;\n  height: 24px;\n  transition: 0.1s;\n}\n.menu .menu-item:hover > :last-child {\n  transform: scale(1.1);\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/MenuIcon.scss":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/MenuIcon.scss ***!
  \*******************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "button:hover .menu-icon .menu-icon-bar,\nbutton:focus .menu-icon .menu-icon-bar {\n  background-color: #2e424f;\n}\n\n.menu-icon {\n  display: flex;\n  width: 24px;\n  height: 24px;\n  flex-direction: column;\n  justify-content: space-between;\n}\n.menu-icon .menu-icon-bar {\n  width: 24px;\n  height: 3px;\n  background-color: #fff;\n  transition: 0.1s;\n}\n.menu-icon.selected .menu-icon-bar-1 {\n  transform: rotate(-45deg) translate(-7.2px, 7.2px);\n}\n.menu-icon.selected .menu-icon-bar-2 {\n  opacity: 0;\n}\n.menu-icon.selected .menu-icon-bar-3 {\n  transform: rotate(45deg) translate(-7.2px, -7.2px);\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Message.scss":
/*!******************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Message.scss ***!
  \******************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".message {\n  padding: 8px;\n  border: 0 solid #03a388;\n  border-left-width: 6px;\n  background-color: #bff8ef;\n  color: #006352;\n}\n.message.warning {\n  border-color: #f59815;\n  background-color: #fff3e2;\n  color: #b76b00;\n}\n.message.error {\n  border-color: #c5283e;\n  background-color: #fdd2d8;\n  color: #7e0314;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/index.scss":
/*!***************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./src/index.scss ***!
  \***************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
exports.push([module.i, "@import url(https://fonts.googleapis.com/css?family=Montserrat|Roboto&display=swap);"]);
// Module
exports.push([module.i, "/* http://meyerweb.com/eric/tools/css/reset/\nv2.0 | 20110126\nLicense: none (public domain)\n */\nhtml, body, div, span, applet, object, iframe,\nh1, h2, h3, h4, h5, h6, p, blockquote, pre,\na, abbr, acronym, address, big, cite, code,\ndel, dfn, em, img, ins, kbd, q, s, samp,\nsmall, strike, strong, sub, sup, tt, var,\nb, u, i, center,\ndl, dt, dd, ol, ul, li,\nfieldset, form, label, legend,\ntable, caption, tbody, tfoot, thead, tr, th, td,\narticle, aside, canvas, details, embed,\nfigure, figcaption, footer, header, hgroup,\nmenu, nav, output, ruby, section, summary,\ntime, mark, audio, video {\n  margin: 0;\n  padding: 0;\n  border: 0;\n  font-size: 100%;\n  font: inherit;\n  vertical-align: baseline;\n}\n\n/* HTML5 display-role reset for older browsers */\narticle, aside, details, figcaption, figure,\nfooter, header, hgroup, menu, nav, section {\n  display: block;\n}\n\nbody {\n  line-height: 1;\n}\n\nol, ul {\n  list-style: none;\n}\n\nblockquote, q {\n  quotes: none;\n}\n\nblockquote:before, blockquote:after,\nq:before, q:after {\n  content: \"\";\n  content: none;\n}\n\ntable {\n  border-collapse: collapse;\n  border-spacing: 0;\n}\n\ninput,\nselect,\ntextarea,\nfieldset {\n  border: 0;\n  outline: 0;\n  background: none;\n  transition: 0.1s;\n  transition-property: border-color, background-color, color;\n  font-family: \"Roboto\", sans-serif;\n  background-color: #fff;\n  color: #232d33;\n  padding: 8px;\n  transition-duration: 0.1s;\n  transition-property: background-color, color, border-color;\n  font-size: 1em;\n}\ninput::-moz-placeholder, select::-moz-placeholder, textarea::-moz-placeholder, fieldset::-moz-placeholder {\n  font-size: 1rem;\n}\ninput:-ms-input-placeholder, select:-ms-input-placeholder, textarea:-ms-input-placeholder, fieldset:-ms-input-placeholder {\n  font-size: 1rem;\n}\ninput::-ms-input-placeholder, select::-ms-input-placeholder, textarea::-ms-input-placeholder, fieldset::-ms-input-placeholder {\n  font-size: 1rem;\n}\ninput::placeholder,\nselect::placeholder,\ntextarea::placeholder,\nfieldset::placeholder {\n  font-size: 1rem;\n}\ninput:disabled,\nselect:disabled,\ntextarea:disabled,\nfieldset:disabled {\n  cursor: default;\n}\n\nlabel {\n  color: #526a78;\n  font-family: \"Montserrat\", sans-serif;\n  font-size: 0.9em;\n  text-transform: uppercase;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  display: flex;\n  flex-direction: column;\n}\n\n.label-disabled {\n  color: #ad9f9f;\n  background-color: #f9f9f9;\n}\n.label-disabled input,\n.label-disabled input:hover,\n.label-disabled input:focus,\n.label-disabled input:active {\n  background-color: #f9f9f9;\n  border-color: #d4d7d8;\n  color: #ad9f9f;\n}\n\n.label-altered {\n  color: #b76b00;\n}\n\n.label-inline {\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  cursor: pointer;\n}\n.label-inline > :first-child {\n  margin-right: 8px;\n}\n\ninput {\n  border: 0;\n  border-bottom: 1px solid #d4d7d8;\n}\ninput:focus {\n  border-bottom-color: #03a388;\n}\ninput:active {\n  border-bottom-color: #d4d7d8;\n}\n\nbody {\n  background-color: #f2f2f2;\n  color: #232d33;\n  font-family: \"Roboto\", sans-serif;\n  font-size: 12pt;\n}\n\nh1,\nh2 {\n  font-family: \"Montserrat\", sans-serif;\n  color: #526a78;\n}\n\nh3,\nh4,\nh5,\nh6 {\n  font-weight: 500;\n}\n\nh1 {\n  font-size: 1.8em;\n}\n\nh2 {\n  font-size: 1.3em;\n}\n\nh3 {\n  font-size: 1.2em;\n}\n\nh4 {\n  font-size: 1.1em;\n}\n\nh5 {\n  font-size: 1.05em;\n}\n\nh6 {\n  font-size: 1.02em;\n}\n\nstrong {\n  font-weight: bold;\n}\n\n.menu-item {\n  position: relative;\n  cursor: pointer;\n  padding-left: inherit;\n  transition: padding-left 0.1s ease-out;\n}\n.menu-item.selected {\n  padding-left: 8px;\n}\n\n.content {\n  display: flex;\n  flex-direction: column;\n  overflow: hidden auto;\n  width: 100%;\n  height: 100%;\n}\n.content > * {\n  height: 100%;\n  width: 100%;\n  overflow: visible auto;\n}\n\n.warning {\n  color: #f59815;\n}\n\n.danger {\n  color: #c5283e;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
// eslint-disable-next-line func-names
module.exports = function (useSourceMap) {
  var list = []; // return the list of modules as css string

  list.toString = function toString() {
    return this.map(function (item) {
      var content = cssWithMappingToString(item, useSourceMap);

      if (item[2]) {
        return "@media ".concat(item[2], " {").concat(content, "}");
      }

      return content;
    }).join('');
  }; // import a list of modules into the list
  // eslint-disable-next-line func-names


  list.i = function (modules, mediaQuery, dedupe) {
    if (typeof modules === 'string') {
      // eslint-disable-next-line no-param-reassign
      modules = [[null, modules, '']];
    }

    var alreadyImportedModules = {};

    if (dedupe) {
      for (var i = 0; i < this.length; i++) {
        // eslint-disable-next-line prefer-destructuring
        var id = this[i][0];

        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }

    for (var _i = 0; _i < modules.length; _i++) {
      var item = [].concat(modules[_i]);

      if (dedupe && alreadyImportedModules[item[0]]) {
        // eslint-disable-next-line no-continue
        continue;
      }

      if (mediaQuery) {
        if (!item[2]) {
          item[2] = mediaQuery;
        } else {
          item[2] = "".concat(mediaQuery, " and ").concat(item[2]);
        }
      }

      list.push(item);
    }
  };

  return list;
};

function cssWithMappingToString(item, useSourceMap) {
  var content = item[1] || ''; // eslint-disable-next-line prefer-destructuring

  var cssMapping = item[3];

  if (!cssMapping) {
    return content;
  }

  if (useSourceMap && typeof btoa === 'function') {
    var sourceMapping = toComment(cssMapping);
    var sourceURLs = cssMapping.sources.map(function (source) {
      return "/*# sourceURL=".concat(cssMapping.sourceRoot || '').concat(source, " */");
    });
    return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
  }

  return [content].join('\n');
} // Adapted from convert-source-map (MIT)


function toComment(sourceMap) {
  // eslint-disable-next-line no-undef
  var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
  var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
  return "/*# ".concat(data, " */");
}

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/getUrl.js":
/*!********************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/getUrl.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (url, options) {
  if (!options) {
    // eslint-disable-next-line no-param-reassign
    options = {};
  } // eslint-disable-next-line no-underscore-dangle, no-param-reassign


  url = url && url.__esModule ? url.default : url;

  if (typeof url !== 'string') {
    return url;
  } // If url is already wrapped in quotes, remove them


  if (/^['"].*['"]$/.test(url)) {
    // eslint-disable-next-line no-param-reassign
    url = url.slice(1, -1);
  }

  if (options.hash) {
    // eslint-disable-next-line no-param-reassign
    url += options.hash;
  } // Should url be wrapped?
  // See https://drafts.csswg.org/css-values-3/#urls


  if (/["'() \t\n]/.test(url) || options.needQuotes) {
    return "\"".concat(url.replace(/"/g, '\\"').replace(/\n/g, '\\n'), "\"");
  }

  return url;
};

/***/ }),

/***/ "./node_modules/process/browser.js":
/*!*****************************************!*\
  !*** ./node_modules/process/browser.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),

/***/ "./node_modules/storedsafe/dist/index.js":
/*!***********************************************!*\
  !*** ./node_modules/storedsafe/dist/index.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable @typescript-eslint/member-delimiter-style */
var axios_1 = __importDefault(__webpack_require__(/*! axios */ "./node_modules/axios/index.js"));
var LoginType;
(function (LoginType) {
    LoginType["TOTP"] = "totp";
    LoginType["SMARTCARD"] = "smc_rest";
})(LoginType = exports.LoginType || (exports.LoginType = {}));
var StoredSafe = /** @class */ (function () {
    function StoredSafe(_a, version) {
        var host = _a.host, apikey = _a.apikey, token = _a.token;
        if (version === void 0) { version = '1.0'; }
        this.axios = axios_1.default.create({
            baseURL: "https://" + host + "/api/" + version + "/",
            timeout: 5000
        });
        this.apikey = apikey;
        this.token = token;
    }
    StoredSafe.prototype.assertApikeyExists = function () {
        if (this.apikey === undefined) {
            throw new Error('Path requires apikey, apikey is undefined.');
        }
    };
    StoredSafe.prototype.assertTokenExists = function () {
        if (this.token === undefined) {
            throw new Error('Path requires token, token is undefined.');
        }
    };
    StoredSafe.prototype.loginYubikey = function (username, passphrase, otp) {
        var _this = this;
        this.assertApikeyExists();
        return this.axios
            .post('/auth', {
            username: username,
            keys: "" + passphrase + this.apikey + otp
        })
            .then(function (response) {
            _this.token = response.data.CALLINFO.token;
            return response;
        });
    };
    StoredSafe.prototype.loginTotp = function (username, passphrase, otp) {
        var _this = this;
        this.assertApikeyExists();
        return this.axios
            .post('/auth', {
            username: username,
            passphrase: passphrase,
            otp: otp,
            logintype: LoginType.TOTP,
            apikey: this.apikey
        })
            .then(function (response) {
            _this.token = response.data.CALLINFO.token;
            return response;
        });
    };
    StoredSafe.prototype.logout = function () {
        var _this = this;
        this.assertTokenExists();
        return this.axios
            .get('/auth/logout', {
            headers: { 'X-Http-Token': this.token }
        })
            .then(function (response) {
            _this.token = undefined;
            return response;
        });
    };
    StoredSafe.prototype.check = function () {
        this.assertTokenExists();
        return this.axios.post('/auth/check', {}, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.listVaults = function () {
        this.assertTokenExists();
        return this.axios.get('/vault', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.vaultObjects = function (id) {
        this.assertTokenExists();
        return this.axios.get("/vault/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.vaultMembers = function (id) {
        this.assertTokenExists();
        return this.axios.get("/vault/" + id + "/members", {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.createVault = function (params) {
        this.assertTokenExists();
        return this.axios.post('/vault', __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.editVault = function (id, params) {
        this.assertTokenExists();
        return this.axios.put("/vault/" + id, __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.deleteVault = function (id) {
        this.assertTokenExists();
        return this.axios.delete("/vault/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.getObject = function (id, children) {
        if (children === void 0) { children = false; }
        this.assertTokenExists();
        return this.axios.get("/object/" + id, {
            params: { children: children },
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.decryptObject = function (id) {
        this.assertTokenExists();
        return this.axios.get("/object/" + id, {
            params: { decrypt: true },
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.createObject = function (params) {
        this.assertTokenExists();
        return this.axios.post('/object', __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.editObject = function (id, params) {
        this.assertTokenExists();
        return this.axios.put("/object/" + id, __assign({}, params), {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.deleteObject = function (id) {
        this.assertTokenExists();
        return this.axios.delete("/object/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.find = function (needle) {
        this.assertTokenExists();
        return this.axios.get('/find', {
            params: { needle: needle },
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.listTemplates = function () {
        this.assertTokenExists();
        return this.axios.get('/template', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.getTemplate = function (id) {
        this.assertTokenExists();
        return this.axios.get("/template/" + id, {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.statusValues = function () {
        this.assertTokenExists();
        return this.axios.get('/utils/statusvalues', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.passwordPolicies = function () {
        this.assertTokenExists();
        return this.axios.get('/utils/policies', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.version = function () {
        this.assertTokenExists();
        return this.axios.get('/utils/version', {
            headers: { 'X-Http-Token': this.token }
        });
    };
    StoredSafe.prototype.generatePassword = function (params) {
        if (params === void 0) { params = {}; }
        this.assertTokenExists();
        return this.axios.get('utils/pwgen', {
            headers: { 'X-Http-Token': this.token },
            params: params
        });
    };
    return StoredSafe;
}());
exports.default = StoredSafe;


/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var isOldIE = function isOldIE() {
  var memo;
  return function memorize() {
    if (typeof memo === 'undefined') {
      // Test for IE <= 9 as proposed by Browserhacks
      // @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
      // Tests for existence of standard globals is to allow style-loader
      // to operate correctly into non-standard environments
      // @see https://github.com/webpack-contrib/style-loader/issues/177
      memo = Boolean(window && document && document.all && !window.atob);
    }

    return memo;
  };
}();

var getTarget = function getTarget() {
  var memo = {};
  return function memorize(target) {
    if (typeof memo[target] === 'undefined') {
      var styleTarget = document.querySelector(target); // Special case to return head of iframe instead of iframe itself

      if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
        try {
          // This will throw an exception if access to iframe is blocked
          // due to cross-origin restrictions
          styleTarget = styleTarget.contentDocument.head;
        } catch (e) {
          // istanbul ignore next
          styleTarget = null;
        }
      }

      memo[target] = styleTarget;
    }

    return memo[target];
  };
}();

var stylesInDom = [];

function getIndexByIdentifier(identifier) {
  var result = -1;

  for (var i = 0; i < stylesInDom.length; i++) {
    if (stylesInDom[i].identifier === identifier) {
      result = i;
      break;
    }
  }

  return result;
}

function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];

  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var index = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3]
    };

    if (index !== -1) {
      stylesInDom[index].references++;
      stylesInDom[index].updater(obj);
    } else {
      stylesInDom.push({
        identifier: identifier,
        updater: addStyle(obj, options),
        references: 1
      });
    }

    identifiers.push(identifier);
  }

  return identifiers;
}

function insertStyleElement(options) {
  var style = document.createElement('style');
  var attributes = options.attributes || {};

  if (typeof attributes.nonce === 'undefined') {
    var nonce =  true ? __webpack_require__.nc : undefined;

    if (nonce) {
      attributes.nonce = nonce;
    }
  }

  Object.keys(attributes).forEach(function (key) {
    style.setAttribute(key, attributes[key]);
  });

  if (typeof options.insert === 'function') {
    options.insert(style);
  } else {
    var target = getTarget(options.insert || 'head');

    if (!target) {
      throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
    }

    target.appendChild(style);
  }

  return style;
}

function removeStyleElement(style) {
  // istanbul ignore if
  if (style.parentNode === null) {
    return false;
  }

  style.parentNode.removeChild(style);
}
/* istanbul ignore next  */


var replaceText = function replaceText() {
  var textStore = [];
  return function replace(index, replacement) {
    textStore[index] = replacement;
    return textStore.filter(Boolean).join('\n');
  };
}();

function applyToSingletonTag(style, index, remove, obj) {
  var css = remove ? '' : obj.media ? "@media ".concat(obj.media, " {").concat(obj.css, "}") : obj.css; // For old IE

  /* istanbul ignore if  */

  if (style.styleSheet) {
    style.styleSheet.cssText = replaceText(index, css);
  } else {
    var cssNode = document.createTextNode(css);
    var childNodes = style.childNodes;

    if (childNodes[index]) {
      style.removeChild(childNodes[index]);
    }

    if (childNodes.length) {
      style.insertBefore(cssNode, childNodes[index]);
    } else {
      style.appendChild(cssNode);
    }
  }
}

function applyToTag(style, options, obj) {
  var css = obj.css;
  var media = obj.media;
  var sourceMap = obj.sourceMap;

  if (media) {
    style.setAttribute('media', media);
  } else {
    style.removeAttribute('media');
  }

  if (sourceMap && btoa) {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  } // For old IE

  /* istanbul ignore if  */


  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    while (style.firstChild) {
      style.removeChild(style.firstChild);
    }

    style.appendChild(document.createTextNode(css));
  }
}

var singleton = null;
var singletonCounter = 0;

function addStyle(obj, options) {
  var style;
  var update;
  var remove;

  if (options.singleton) {
    var styleIndex = singletonCounter++;
    style = singleton || (singleton = insertStyleElement(options));
    update = applyToSingletonTag.bind(null, style, styleIndex, false);
    remove = applyToSingletonTag.bind(null, style, styleIndex, true);
  } else {
    style = insertStyleElement(options);
    update = applyToTag.bind(null, style, options);

    remove = function remove() {
      removeStyleElement(style);
    };
  }

  update(obj);
  return function updateStyle(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap) {
        return;
      }

      update(obj = newObj);
    } else {
      remove();
    }
  };
}

module.exports = function (list, options) {
  options = options || {}; // Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
  // tags it will allow on a page

  if (!options.singleton && typeof options.singleton !== 'boolean') {
    options.singleton = isOldIE();
  }

  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];

    if (Object.prototype.toString.call(newList) !== '[object Array]') {
      return;
    }

    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDom[index].references--;
    }

    var newLastIdentifiers = modulesToDom(newList, options);

    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];

      var _index = getIndexByIdentifier(_identifier);

      if (stylesInDom[_index].references === 0) {
        stylesInDom[_index].updater();

        stylesInDom.splice(_index, 1);
      }
    }

    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ }),

/***/ "./src/components/Add/Add.scss":
/*!*************************************!*\
  !*** ./src/components/Add/Add.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/postcss-loader/src!../../../node_modules/sass-loader/dist/cjs.js!./Add.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Add/Add.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Add/Add.tsx":
/*!************************************!*\
  !*** ./src/components/Add/Add.tsx ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Add = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./Add.scss */ "./src/components/Add/Add.scss");
const AddObject_1 = __webpack_require__(/*! ./layout/AddObject */ "./src/components/Add/layout/AddObject.tsx");
const input_1 = __webpack_require__(/*! ../common/input */ "./src/components/common/input/index.ts");
const layout_1 = __webpack_require__(/*! ../common/layout */ "./src/components/common/layout/index.ts");
__exportStar(__webpack_require__(/*! ./layout/AddObject */ "./src/components/Add/layout/AddObject.tsx"), exports);
exports.Add = ({ isInitialized, addObjectProps, success, clearSuccess }) => {
    if (!isInitialized)
        return react_1.default.createElement(layout_1.LoadingComponent, null);
    return (react_1.default.createElement("section", { className: 'add' },
        react_1.default.createElement("h1", null, "Add Object"),
        success ? (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(layout_1.Message, null, "Successfully added object to StoredSafe."),
            react_1.default.createElement(input_1.Button, { onClick: clearSuccess }, "Click to add a new object"))) : (react_1.default.createElement(AddObject_1.AddObject, Object.assign({}, addObjectProps)))));
};


/***/ }),

/***/ "./src/components/Add/layout/AddObject.scss":
/*!**************************************************!*\
  !*** ./src/components/Add/layout/AddObject.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./AddObject.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Add/layout/AddObject.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Add/layout/AddObject.tsx":
/*!*************************************************!*\
  !*** ./src/components/Add/layout/AddObject.tsx ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddObject = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const useLoading_1 = __webpack_require__(/*! ../../../hooks/utils/useLoading */ "./src/hooks/utils/useLoading.ts");
const useForm_1 = __webpack_require__(/*! ../../../hooks/utils/useForm */ "./src/hooks/utils/useForm.ts");
const input_1 = __webpack_require__(/*! ../../common/input */ "./src/components/common/input/index.ts");
const layout_1 = __webpack_require__(/*! ../../common/layout */ "./src/components/common/layout/index.ts");
__webpack_require__(/*! ./AddObject.scss */ "./src/components/Add/layout/AddObject.scss");
exports.AddObject = ({ error, hosts, vaults, templates, addObject }) => {
    var _a;
    const [values, events] = useForm_1.useForm({
        parentid: '0',
    });
    const [addState, setAddPromise] = useLoading_1.useLoading();
    /// /////////////////////////////////////////////////////////
    // Set up event handlers
    function onHostChange({ target }) {
        hosts.onChange(Number(target.value));
    }
    function onVaultChange({ target }) {
        vaults.onChange(Number(target.value));
    }
    function onTemplateChange({ target }) {
        templates.onChange(Number(target.value));
    }
    /// /////////////////////////////////////////////////////////
    // Set up select boxes
    let selectHost = null;
    let selectVault = null;
    let selectTemplate = null;
    if (hosts.values.length > 1) {
        selectHost = (react_1.default.createElement("label", { htmlFor: 'host' },
            react_1.default.createElement("span", null, "Host"),
            react_1.default.createElement(input_1.Select, { value: hosts.selected, onChange: onHostChange, name: 'host', id: 'host' }, hosts.values.map((host, id) => (react_1.default.createElement("option", { key: host, value: id }, host))))));
    }
    else {
        selectHost = react_1.default.createElement("h2", null, (_a = hosts.values) === null || _a === void 0 ? void 0 : _a[hosts.selected]);
    }
    /// /////////////////////////////////////////////////////////
    // Handle error states
    if (error !== undefined) {
        return (react_1.default.createElement("section", { className: 'add-object' },
            selectHost,
            react_1.default.createElement(layout_1.Message, { type: 'error' },
                "Error: ",
                error.message)));
    }
    if (vaults.values.length === 0) {
        return (react_1.default.createElement("section", { className: 'add-object' },
            selectHost,
            react_1.default.createElement(layout_1.Message, { type: 'warning' },
                react_1.default.createElement("p", null, "No vaults with write access found for this host."),
                react_1.default.createElement("p", null, "Add a vault or ask your administrator to give you access to one."))));
    }
    if (templates.values.length === 0) {
        return (react_1.default.createElement("section", { className: 'add-object' },
            selectHost,
            react_1.default.createElement(layout_1.Message, { type: 'error' },
                react_1.default.createElement("p", null, "No templates found for this host."),
                react_1.default.createElement("p", null, "No templates are available, please contact your administrator."))));
    }
    /// /////////////////////////////////////////////////////////
    // Continue select boxes
    if (vaults.values.length > 1) {
        selectVault = (react_1.default.createElement("label", { htmlFor: 'vault' },
            react_1.default.createElement("span", null, "Vault"),
            react_1.default.createElement(input_1.Select, { value: vaults.selected, onChange: onVaultChange, name: 'vault', id: 'vault' }, vaults.values.map((vault, id) => (react_1.default.createElement("option", { key: vault.id, value: id }, vault.name))))));
    }
    if (templates.values.length > 1) {
        selectTemplate = (react_1.default.createElement("label", { htmlFor: 'template' },
            react_1.default.createElement("span", null, "Template"),
            react_1.default.createElement(input_1.Select, { value: templates.selected, onChange: onTemplateChange, name: 'template', id: 'template' }, templates.values.map((template, id) => (react_1.default.createElement("option", { key: template.id, value: id }, template.name))))));
    }
    /// /////////////////////////////////////////////////////////
    // Submit handlers
    function onAdd(event) {
        event.preventDefault();
        const host = hosts.values[hosts.selected];
        if (host === undefined) {
            setAddPromise(Promise.reject(new Error('No host selected.')));
            return;
        }
        const vault = vaults.values[vaults.selected];
        if (vault === undefined) {
            setAddPromise(Promise.reject(new Error('No vault selected.')));
            return;
        }
        const template = templates.values[templates.selected];
        if (template === undefined) {
            setAddPromise(Promise.reject(new Error('No template selected.')));
            return;
        }
        // Filter out irrelevant fields
        const { templateid, groupid, parentid } = values;
        const properties = { templateid, groupid, parentid };
        for (const { name } of template.structure) {
            if (values[name] !== undefined) {
                properties[name] = values[name];
            }
        }
        // Add global properties
        properties.groupid = vault.id;
        properties.templateid = template.id;
        setAddPromise(addObject(host, properties));
    }
    const template = templates.values[templates.selected];
    let fields = null;
    if ((template === null || template === void 0 ? void 0 : template.structure) !== undefined) {
        fields = template.structure.map(({ title, name, isEncrypted, type }) => {
            const value = values[name] !== undefined ? values[name] : '';
            return (react_1.default.createElement("label", { key: name, htmlFor: name, className: 'add-object-field' },
                react_1.default.createElement("span", null, title),
                react_1.default.createElement("input", Object.assign({ className: `add-object-field${isEncrypted ? ' encrypted' : ''}`, type: type === 'text-passwdgen' ? 'password' : 'text', id: name, name: name, value: value }, events))));
        });
    }
    return (react_1.default.createElement("section", { className: 'add-object' },
        react_1.default.createElement("form", { className: 'add-object-form', onSubmit: onAdd },
            selectHost,
            selectVault,
            selectTemplate,
            fields,
            react_1.default.createElement(input_1.Button, { color: 'accent', isLoading: addState.isLoading }, "Add to StoredSafe"),
            addState.error !== undefined && (react_1.default.createElement(layout_1.Message, { type: 'error' },
                "Error: ",
                addState.error.message)))));
};


/***/ }),

/***/ "./src/components/Auth/Auth.scss":
/*!***************************************!*\
  !*** ./src/components/Auth/Auth.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/postcss-loader/src!../../../node_modules/sass-loader/dist/cjs.js!./Auth.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/Auth.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Auth/Auth.tsx":
/*!**************************************!*\
  !*** ./src/components/Auth/Auth.tsx ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Auth = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const layout_1 = __webpack_require__(/*! ../common/layout */ "./src/components/common/layout/index.ts");
const SiteTitle_1 = __webpack_require__(/*! ./layout/SiteTitle */ "./src/components/Auth/layout/SiteTitle.tsx");
__webpack_require__(/*! ./Auth.scss */ "./src/components/Auth/Auth.scss");
const Login_1 = __webpack_require__(/*! ./login/Login */ "./src/components/Auth/login/Login.tsx");
const SessionStatus_1 = __webpack_require__(/*! ./sessionStatus/SessionStatus */ "./src/components/Auth/sessionStatus/SessionStatus.tsx");
exports.Auth = ({ isInitialized, sites, sessions, login, logout, goto, lastUsedSite, sitePreferences }) => {
    if (!isInitialized)
        return react_1.default.createElement(layout_1.LoadingComponent, null);
    const items = sites.map(site => {
        const isOnline = sessions.has(site.host);
        return {
            title: (react_1.default.createElement("article", null,
                react_1.default.createElement(SiteTitle_1.SiteTitle, { host: site.host, session: isOnline ? sessions.get(site.host) : undefined }))),
            content: isOnline ? (react_1.default.createElement(SessionStatus_1.SessionStatus, { host: site.host, session: sessions.get(site.host), logout: logout, goto: goto })) : (react_1.default.createElement(Login_1.Login, { site: site, login: login, sitePreferences: sitePreferences[site.host] })),
            key: site.host
        };
    });
    const defaultSelected = sites.length === 1 ? sites[0].host : undefined;
    return (react_1.default.createElement("section", { className: 'auth' },
        react_1.default.createElement("h1", null, "Sessions"),
        react_1.default.createElement(layout_1.ListView, { items: items, defaultSelected: defaultSelected })));
};


/***/ }),

/***/ "./src/components/Auth/index.ts":
/*!**************************************!*\
  !*** ./src/components/Auth/index.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./Auth */ "./src/components/Auth/Auth.tsx"), exports);


/***/ }),

/***/ "./src/components/Auth/layout/SiteTitle.scss":
/*!***************************************************!*\
  !*** ./src/components/Auth/layout/SiteTitle.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SiteTitle.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/layout/SiteTitle.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Auth/layout/SiteTitle.tsx":
/*!**************************************************!*\
  !*** ./src/components/Auth/layout/SiteTitle.tsx ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SiteTitle = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const layout_1 = __webpack_require__(/*! ../../common/layout */ "./src/components/common/layout/index.ts");
__webpack_require__(/*! ./SiteTitle.scss */ "./src/components/Auth/layout/SiteTitle.scss");
exports.SiteTitle = ({ host, session }) => {
    const isOnline = session !== undefined;
    return (react_1.default.createElement("article", { className: `site-title${isOnline ? ' online' : ''}` },
        react_1.default.createElement("p", { className: 'site-title-host' }, host),
        react_1.default.createElement("div", { className: 'site-title-icons' },
            isOnline && Object.values(session.warnings).length > 0 && layout_1.icons.warning,
            isOnline && Object.values(session.violations).length > 0 && layout_1.icons.error,
            isOnline && layout_1.icons.vault_unlocked,
            !isOnline && layout_1.icons.vault_locked)));
};


/***/ }),

/***/ "./src/components/Auth/login/Login.scss":
/*!**********************************************!*\
  !*** ./src/components/Auth/login/Login.scss ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Login.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/login/Login.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Auth/login/Login.tsx":
/*!*********************************************!*\
  !*** ./src/components/Auth/login/Login.tsx ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Login = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const useForm_1 = __webpack_require__(/*! ../../../hooks/utils/useForm */ "./src/hooks/utils/useForm.ts");
const input_1 = __webpack_require__(/*! ../../common/input */ "./src/components/common/input/index.ts");
const layout_1 = __webpack_require__(/*! ../../common/layout */ "./src/components/common/layout/index.ts");
const YubiKey = __importStar(__webpack_require__(/*! ./YubiKey */ "./src/components/Auth/login/YubiKey.tsx"));
const TOTP = __importStar(__webpack_require__(/*! ./TOTP */ "./src/components/Auth/login/TOTP.tsx"));
__webpack_require__(/*! ./Login.scss */ "./src/components/Auth/login/Login.scss");
const useLoading_1 = __webpack_require__(/*! ../../../hooks/utils/useLoading */ "./src/hooks/utils/useLoading.ts");
exports.Login = ({ site, login, sitePreferences, formEvents }) => {
    const username = sitePreferences === null || sitePreferences === void 0 ? void 0 : sitePreferences.username;
    const loginType = sitePreferences === null || sitePreferences === void 0 ? void 0 : sitePreferences.loginType;
    const initialValues = {
        loginType: loginType !== undefined ? loginType : 'totp',
        username: username !== undefined ? username : '',
        remember: username !== undefined,
        keys: '',
        passphrase: '',
        otp: ''
    };
    const [values, events, reset] = useForm_1.useForm(initialValues, formEvents);
    const [state, setPromise] = useLoading_1.useLoading();
    const handleSubmit = (event) => {
        event.preventDefault();
        setPromise(login(site, values));
    };
    const id = (name) => site.host + '-' + name;
    const hasError = state.error !== undefined;
    return (react_1.default.createElement("section", { className: 'login' },
        react_1.default.createElement("article", { className: 'login-form' },
            react_1.default.createElement("form", { className: 'form', onSubmit: handleSubmit },
                react_1.default.createElement("label", { htmlFor: id('loginType') },
                    react_1.default.createElement("span", null, "Login Type"),
                    react_1.default.createElement(input_1.Select, Object.assign({ id: id('loginType'), name: 'loginType', value: values.loginType }, events),
                        react_1.default.createElement("option", { value: 'totp' }, "TOTP"),
                        react_1.default.createElement("option", { value: 'yubikey' }, "YubiKey"))),
                react_1.default.createElement("label", { htmlFor: id('username') },
                    react_1.default.createElement("span", null, "Username"),
                    react_1.default.createElement("input", Object.assign({ type: 'text', id: id('username'), name: 'username', value: values.username, required: true }, events))),
                values.loginType === 'yubikey' &&
                    YubiKey.renderFields([values, events, reset], id),
                values.loginType === 'totp' &&
                    TOTP.renderFields([values, events, reset], id),
                react_1.default.createElement("label", { htmlFor: id('remember'), className: 'label-inline' },
                    react_1.default.createElement("span", null, "Remember Username"),
                    react_1.default.createElement(input_1.Checkbox, Object.assign({ id: id('remember'), name: 'remember', checked: values.remember }, events))),
                react_1.default.createElement(input_1.Button, { type: 'submit', color: 'accent', isLoading: state.isLoading }, "Login"))),
        hasError && react_1.default.createElement(layout_1.Message, { type: 'error' }, state.error.message)));
};


/***/ }),

/***/ "./src/components/Auth/login/TOTP.tsx":
/*!********************************************!*\
  !*** ./src/components/Auth/login/TOTP.tsx ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderFields = void 0;
const react_1 = __importStar(__webpack_require__(/*! react */ "react"));
exports.renderFields = ([values, events], id) => (react_1.default.createElement(react_1.Fragment, null,
    react_1.default.createElement("label", { htmlFor: 'passphrase' },
        react_1.default.createElement("span", null, "Passphrase"),
        react_1.default.createElement("input", Object.assign({ type: 'password', name: 'passphrase', id: id('passphrase'), required: true, value: values.passphrase }, events))),
    react_1.default.createElement("label", { htmlFor: 'otp' },
        react_1.default.createElement("span", null, "OTP"),
        react_1.default.createElement("input", Object.assign({ type: 'text', name: 'otp', id: id('otp'), required: true, value: values.otp }, events)))));


/***/ }),

/***/ "./src/components/Auth/login/YubiKey.tsx":
/*!***********************************************!*\
  !*** ./src/components/Auth/login/YubiKey.tsx ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderFields = void 0;
const react_1 = __importStar(__webpack_require__(/*! react */ "react"));
exports.renderFields = ([values, events], id) => (react_1.default.createElement(react_1.Fragment, null,
    react_1.default.createElement("label", { htmlFor: 'keys' },
        react_1.default.createElement("span", null, "Passphrase + YubiKey"),
        react_1.default.createElement("input", Object.assign({ type: 'password', name: 'keys', id: id('password'), required: true, title: 'Passphrase + YubiKey', value: values.keys }, events)))));


/***/ }),

/***/ "./src/components/Auth/sessionStatus/SessionStatus.scss":
/*!**************************************************************!*\
  !*** ./src/components/Auth/sessionStatus/SessionStatus.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SessionStatus.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Auth/sessionStatus/SessionStatus.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Auth/sessionStatus/SessionStatus.tsx":
/*!*************************************************************!*\
  !*** ./src/components/Auth/sessionStatus/SessionStatus.tsx ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionStatus = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const input_1 = __webpack_require__(/*! ../../common/input */ "./src/components/common/input/index.ts");
const layout_1 = __webpack_require__(/*! ../../common/layout */ "./src/components/common/layout/index.ts");
__webpack_require__(/*! ./SessionStatus.scss */ "./src/components/Auth/sessionStatus/SessionStatus.scss");
const useLoading_1 = __webpack_require__(/*! ../../../hooks/utils/useLoading */ "./src/hooks/utils/useLoading.ts");
exports.SessionStatus = ({ host, session, logout, goto }) => {
    const [state, setPromise] = useLoading_1.useLoading();
    function onLogout(host) {
        setPromise(logout(host), host);
    }
    const warningMessages = (react_1.default.createElement("article", { className: 'session-status-warnings' },
        react_1.default.createElement("h3", { className: 'warnings-title' }, "Warnings"),
        Object.values(session.warnings).map((warning, index) => (react_1.default.createElement(layout_1.Message, { key: index, type: 'warning' }, warning)))));
    const errorMessages = (react_1.default.createElement("article", { className: 'session-status-errors' },
        react_1.default.createElement("h3", { className: 'errors-title' }, "Violations"),
        Object.values(session.violations).map((error, index) => (react_1.default.createElement(layout_1.Message, { key: index, type: 'error' }, error)))));
    const minutesActive = Math.floor((Date.now() - session.createdAt) / (1000 * 60));
    const dateStamp = new Date(session.createdAt).toLocaleTimeString('sv');
    return (react_1.default.createElement("section", { className: 'session-status' },
        react_1.default.createElement("article", { className: 'session-status-online' },
            react_1.default.createElement("h3", null, "Session status"),
            react_1.default.createElement("p", { className: 'session-status-active' },
                "Online since ",
                dateStamp,
                " (",
                minutesActive,
                " minutes).")),
        Object.values(session.violations).length > 0 && errorMessages,
        Object.values(session.warnings).length > 0 && warningMessages,
        react_1.default.createElement(input_1.Button, { type: 'button', onClick: () => goto(host) },
            "Go to ",
            host),
        react_1.default.createElement(input_1.Button, { type: 'button', color: 'danger', onClick: () => onLogout(host), isLoading: state.isLoading && state.key === host }, "Logout")));
};


/***/ }),

/***/ "./src/components/DebugStorage/DebugStorage.scss":
/*!*******************************************************!*\
  !*** ./src/components/DebugStorage/DebugStorage.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/postcss-loader/src!../../../node_modules/sass-loader/dist/cjs.js!./DebugStorage.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/DebugStorage/DebugStorage.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/DebugStorage/DebugStorage.tsx":
/*!******************************************************!*\
  !*** ./src/components/DebugStorage/DebugStorage.tsx ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DebugStorage = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./DebugStorage.scss */ "./src/components/DebugStorage/DebugStorage.scss");
function debugStorage(storage) {
    function isMap(storage) {
        return storage.reduce((acc, element) => acc && element instanceof Array && element.length === 2, true);
    }
    function drawMap(storage) {
        return [...storage].map(([key, value]) => {
            return (react_1.default.createElement("li", { key: key },
                react_1.default.createElement("span", null,
                    "(map) ",
                    react_1.default.createElement("b", null, key),
                    ": ",
                    debugStorage(value))));
        });
    }
    function drawArray(storage) {
        return storage.map((value, id) => (react_1.default.createElement("li", { key: id },
            react_1.default.createElement("span", null,
                "(array) ",
                debugStorage(value)))));
    }
    function drawFunction(storage) {
        return react_1.default.createElement("span", null,
            "(function) ",
            storage.toString());
    }
    function drawObject(storage) {
        return Object.keys(storage).map(key => (react_1.default.createElement("li", { key: key },
            react_1.default.createElement("span", null,
                "(object) ",
                react_1.default.createElement("b", null, key),
                ": ",
                debugStorage(storage[key])))));
    }
    if (storage === null)
        return storage;
    if (storage instanceof Map) {
        return storage.size > 0 ? react_1.default.createElement("ul", null, drawMap(storage)) : null;
    }
    else if (storage instanceof Array) {
        if (storage.length === 0)
            return '[]';
        if (isMap(storage)) {
            return react_1.default.createElement("ul", null, drawMap(new Map(storage)));
        }
        else {
            return react_1.default.createElement("ul", null, drawArray(storage));
        }
    }
    else if (storage instanceof Function) {
        return react_1.default.createElement(react_1.default.Fragment, null, drawFunction(storage));
    }
    else if (storage instanceof Object) {
        return Object.keys(storage).length > 0 ? (react_1.default.createElement("ul", null, drawObject(storage))) : null;
    }
    else {
        const value = storage;
        return react_1.default.createElement("span", null, value.toString());
    }
}
exports.DebugStorage = ({ local, sync, managed }) => {
    return (react_1.default.createElement("section", { className: 'debug-storage' },
        react_1.default.createElement("h1", null, "Debug Storage"),
        react_1.default.createElement("article", { className: 'storage-area storage-area-local' },
            react_1.default.createElement("h2", null, "Local"),
            local !== undefined && debugStorage(local)),
        react_1.default.createElement("article", { className: 'storage-area storage-area-sync' },
            react_1.default.createElement("h2", null, "Sync"),
            sync !== undefined && debugStorage(sync)),
        react_1.default.createElement("article", { className: 'storage-area storage-area-managed' },
            react_1.default.createElement("h2", null, "Managed"),
            managed !== undefined && debugStorage(managed))));
};


/***/ }),

/***/ "./src/components/DebugStorage/index.ts":
/*!**********************************************!*\
  !*** ./src/components/DebugStorage/index.ts ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var DebugStorage_1 = __webpack_require__(/*! ./DebugStorage */ "./src/components/DebugStorage/DebugStorage.tsx");
Object.defineProperty(exports, "DebugStorage", { enumerable: true, get: function () { return DebugStorage_1.DebugStorage; } });


/***/ }),

/***/ "./src/components/Options/Options.scss":
/*!*********************************************!*\
  !*** ./src/components/Options/Options.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/postcss-loader/src!../../../node_modules/sass-loader/dist/cjs.js!./Options.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/Options.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Options/Options.tsx":
/*!********************************************!*\
  !*** ./src/components/Options/Options.tsx ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Options = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const SiteOptions_1 = __webpack_require__(/*! ./layout/SiteOptions */ "./src/components/Options/layout/SiteOptions.tsx");
const layout_1 = __webpack_require__(/*! ../common/layout */ "./src/components/common/layout/index.ts");
__webpack_require__(/*! ./Options.scss */ "./src/components/Options/Options.scss");
const GeneralOptions_1 = __webpack_require__(/*! ./layout/GeneralOptions */ "./src/components/Options/layout/GeneralOptions.tsx");
const BlacklistOptions_1 = __webpack_require__(/*! ./layout/BlacklistOptions */ "./src/components/Options/layout/BlacklistOptions.tsx");
exports.Options = ({ isInitialized, generalOptionsProps, siteOptionsProps, blacklistOptionsProps }) => {
    if (!isInitialized)
        return react_1.default.createElement(layout_1.LoadingComponent, null);
    const items = [
        {
            key: 'general',
            title: react_1.default.createElement("h2", null, "General Settings"),
            content: react_1.default.createElement(GeneralOptions_1.GeneralOptions, Object.assign({}, generalOptionsProps))
        },
        {
            key: 'sites',
            title: react_1.default.createElement("h2", null, "Sites"),
            content: react_1.default.createElement(SiteOptions_1.SiteOptions, Object.assign({}, siteOptionsProps))
        },
        {
            key: 'blacklist',
            title: react_1.default.createElement("h2", null, "Blacklist"),
            content: react_1.default.createElement(BlacklistOptions_1.BlacklistOptions, Object.assign({}, blacklistOptionsProps))
        }
    ];
    return (react_1.default.createElement("section", { className: 'options' },
        react_1.default.createElement("h1", null, "Options"),
        react_1.default.createElement(layout_1.ListView, { items: items })));
};


/***/ }),

/***/ "./src/components/Options/index.ts":
/*!*****************************************!*\
  !*** ./src/components/Options/index.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./Options */ "./src/components/Options/Options.tsx"), exports);
__exportStar(__webpack_require__(/*! ./layout/SiteOptions */ "./src/components/Options/layout/SiteOptions.tsx"), exports);
__exportStar(__webpack_require__(/*! ./layout/GeneralOptions */ "./src/components/Options/layout/GeneralOptions.tsx"), exports);


/***/ }),

/***/ "./src/components/Options/layout/BlacklistOptions.scss":
/*!*************************************************************!*\
  !*** ./src/components/Options/layout/BlacklistOptions.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./BlacklistOptions.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/layout/BlacklistOptions.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Options/layout/BlacklistOptions.tsx":
/*!************************************************************!*\
  !*** ./src/components/Options/layout/BlacklistOptions.tsx ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BlacklistOptions = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const useLoading_1 = __webpack_require__(/*! ../../../hooks/utils/useLoading */ "./src/hooks/utils/useLoading.ts");
const input_1 = __webpack_require__(/*! ../../../components/common/input */ "./src/components/common/input/index.ts");
__webpack_require__(/*! ./BlacklistOptions.scss */ "./src/components/Options/layout/BlacklistOptions.scss");
exports.BlacklistOptions = ({ removeBlacklistHost, blacklist }) => {
    const [removeState, setRemovePromise] = useLoading_1.useLoading();
    function onRemove(host) {
        setRemovePromise(removeBlacklistHost(host), host);
    }
    return (react_1.default.createElement("section", { className: 'blacklist-options' },
        blacklist.length === 0 && react_1.default.createElement("p", null, "Blacklist is empty."),
        blacklist.map(host => (react_1.default.createElement("article", { key: host, className: 'blacklist-options-article' },
            react_1.default.createElement("p", { className: 'blacklist-options-host' }, host),
            react_1.default.createElement(input_1.Button, { color: 'danger', onClick: () => onRemove(host), isLoading: removeState.isLoading && removeState.key === host }, "Delete"))))));
};


/***/ }),

/***/ "./src/components/Options/layout/GeneralOptions.scss":
/*!***********************************************************!*\
  !*** ./src/components/Options/layout/GeneralOptions.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./GeneralOptions.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/layout/GeneralOptions.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Options/layout/GeneralOptions.tsx":
/*!**********************************************************!*\
  !*** ./src/components/Options/layout/GeneralOptions.tsx ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GeneralOptions = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./GeneralOptions.scss */ "./src/components/Options/layout/GeneralOptions.scss");
const useForm_1 = __webpack_require__(/*! ../../../hooks/utils/useForm */ "./src/hooks/utils/useForm.ts");
const fields_1 = __webpack_require__(/*! ./fields */ "./src/components/Options/layout/fields.ts");
const input_1 = __webpack_require__(/*! ../../common/input */ "./src/components/common/input/index.ts");
const useLoading_1 = __webpack_require__(/*! ../../../hooks/utils/useLoading */ "./src/hooks/utils/useLoading.ts");
const layout_1 = __webpack_require__(/*! ../../common/layout */ "./src/components/common/layout/index.ts");
exports.GeneralOptions = ({ settings, saveSettings }) => {
    const initialValues = {};
    for (const [field, { value }] of settings) {
        initialValues[field] = value;
    }
    const [values, events] = useForm_1.useForm(initialValues);
    const [state, setPromise] = useLoading_1.useLoading();
    function onSave(event) {
        event.preventDefault();
        const newSettings = new Map(settings);
        Object.keys(values).forEach(field => {
            newSettings.set(field, {
                value: values[field],
                managed: settings.get(field).managed
            });
        });
        setPromise(saveSettings(newSettings));
    }
    const settingsFields = Object.keys(fields_1.fields).map(field => {
        if (settings.get(field) === undefined) {
            throw new Error(`Field '${field}' is missing a default value.`);
        }
        const { label, unit, attributes } = fields_1.fields[field];
        const disabled = settings.get(field).managed;
        attributes.id = field;
        attributes.name = field;
        attributes.disabled = disabled;
        attributes.title = disabled
            ? 'This field is managed by your organization'
            : '';
        const labelClassNames = [
            'general-options-label',
            disabled ? 'label-disabled' : '',
            attributes.type === 'checkbox' ? 'label-inline' : '',
            values[field] !== settings.get(field).value ? 'label-altered' : ''
        ].join(' ');
        if (attributes.type === 'checkbox') {
            return (react_1.default.createElement("label", { key: field, htmlFor: field, className: labelClassNames },
                react_1.default.createElement("div", { className: 'general-options-field' },
                    react_1.default.createElement(input_1.Checkbox, Object.assign({ checked: values[field] }, events, attributes))),
                react_1.default.createElement("span", null, label)));
        }
        else {
            return (react_1.default.createElement("label", { key: field, htmlFor: field, className: labelClassNames },
                react_1.default.createElement("span", null, label),
                react_1.default.createElement("div", { className: 'general-options-field' },
                    react_1.default.createElement("input", Object.assign({ value: values[field] }, events, attributes)),
                    react_1.default.createElement("span", null, unit))));
        }
    });
    return (react_1.default.createElement("section", { className: 'general-options' },
        react_1.default.createElement("form", { className: 'general-options-form', onSubmit: onSave },
            settingsFields,
            react_1.default.createElement(input_1.Button, { type: 'submit', isLoading: state.isLoading }, "Save"),
            state.error !== undefined && react_1.default.createElement(layout_1.Message, { type: 'error' },
                "Error: ",
                state.error.message))));
};


/***/ }),

/***/ "./src/components/Options/layout/SiteOptions.scss":
/*!********************************************************!*\
  !*** ./src/components/Options/layout/SiteOptions.scss ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SiteOptions.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Options/layout/SiteOptions.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Options/layout/SiteOptions.tsx":
/*!*******************************************************!*\
  !*** ./src/components/Options/layout/SiteOptions.tsx ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SiteOptions = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const useForm_1 = __webpack_require__(/*! ../../../hooks/utils/useForm */ "./src/hooks/utils/useForm.ts");
const useLoading_1 = __webpack_require__(/*! ../../../hooks/utils/useLoading */ "./src/hooks/utils/useLoading.ts");
const input_1 = __webpack_require__(/*! ../../../components/common/input */ "./src/components/common/input/index.ts");
const layout_1 = __webpack_require__(/*! ../../common/layout */ "./src/components/common/layout/index.ts");
__webpack_require__(/*! ./SiteOptions.scss */ "./src/components/Options/layout/SiteOptions.scss");
exports.SiteOptions = ({ addSite, removeSite, systemSites, userSites }) => {
    const [values, events, reset] = useForm_1.useForm({ host: '', apikey: '' });
    const [addState, setAddPromise] = useLoading_1.useLoading();
    const [removeState, setRemovePromise] = useLoading_1.useLoading();
    function onAdd(event) {
        event.preventDefault();
        setAddPromise(addSite(values).then(() => reset()));
    }
    function onRemove(id) {
        setRemovePromise(removeSite(id), id);
    }
    return (react_1.default.createElement("section", { className: 'site-options' },
        react_1.default.createElement("article", { className: 'site-options-article site-options-add' },
            react_1.default.createElement("form", { onSubmit: onAdd },
                react_1.default.createElement("label", { htmlFor: 'host' },
                    react_1.default.createElement("span", null, "Host"),
                    react_1.default.createElement("input", Object.assign({ type: 'text', id: 'host', name: 'host', value: values.host, required: true }, events))),
                react_1.default.createElement("label", { htmlFor: 'apikey' },
                    react_1.default.createElement("span", null, "API Key"),
                    react_1.default.createElement("input", Object.assign({ type: 'password', id: 'apikey', name: 'apikey', value: values.apikey, required: true }, events))),
                react_1.default.createElement(input_1.Button, { color: 'accent', type: 'submit', isLoading: addState.isLoading }, "Add Site"),
                addState.error !== undefined && (react_1.default.createElement(layout_1.Message, { type: 'error' }, addState.error.message)))),
        systemSites.length !== 0 && (react_1.default.createElement("article", { className: 'site-options-article site-options-system' },
            react_1.default.createElement("h3", null, "Sites managed by organization"),
            systemSites.map(site => (react_1.default.createElement("article", { key: site.host, className: 'site-options-site' },
                react_1.default.createElement("p", { className: 'site-options-host' }, site.host)))))),
        userSites.length !== 0 && (react_1.default.createElement("article", { className: 'site-options-article site-options-user' },
            react_1.default.createElement("h3", null, "User sites"),
            userSites.map((site, id) => (react_1.default.createElement("article", { key: site.host, className: 'site-options-site' },
                react_1.default.createElement("p", { className: 'site-options-host' }, site.host),
                react_1.default.createElement(input_1.Button, { color: 'danger', onClick: () => onRemove(id), isLoading: removeState.isLoading && removeState.key === id }, "Delete"))))))));
};


/***/ }),

/***/ "./src/components/Options/layout/fields.ts":
/*!*************************************************!*\
  !*** ./src/components/Options/layout/fields.ts ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.fields = void 0;
/**
 * Description of all fields that can be adjusted by the user and.
 * */
exports.fields = {
    autoFill: {
        label: 'Auto Fill',
        attributes: {
            type: 'checkbox'
        }
    },
    idleMax: {
        label: 'Logout after being idle for',
        unit: 'minutes',
        attributes: {
            type: 'number',
            required: true,
            min: 1,
            max: 120
        }
    },
    maxTokenLife: {
        label: 'Logout after being online for',
        unit: 'hours',
        attributes: {
            type: 'number',
            required: true,
            min: 1,
            max: 24
        }
    }
};


/***/ }),

/***/ "./src/components/Popup/Popup.scss":
/*!*****************************************!*\
  !*** ./src/components/Popup/Popup.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/postcss-loader/src!../../../node_modules/sass-loader/dist/cjs.js!./Popup.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Popup/Popup.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Popup/Popup.tsx":
/*!****************************************!*\
  !*** ./src/components/Popup/Popup.tsx ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Popup = void 0;
const react_1 = __importStar(__webpack_require__(/*! react */ "react"));
const TopMenu_1 = __webpack_require__(/*! ./layout/TopMenu */ "./src/components/Popup/layout/TopMenu.tsx");
const layout_1 = __webpack_require__(/*! ../common/layout */ "./src/components/common/layout/index.ts");
const input_1 = __webpack_require__(/*! ../common/input */ "./src/components/common/input/index.ts");
__webpack_require__(/*! ./Popup.scss */ "./src/components/Popup/Popup.scss");
const useLoading_1 = __webpack_require__(/*! ../../hooks/utils/useLoading */ "./src/hooks/utils/useLoading.ts");
exports.Popup = ({ isInitialized, isOnline, menuItems, onFocus, find, page }) => {
    const [needle, setNeedle] = react_1.useState('');
    const [state, setPromise] = useLoading_1.useLoading();
    const onSearch = react_1.useCallback(() => {
        setPromise(find(needle), needle);
    }, [needle, setPromise, find]);
    react_1.useEffect(() => {
        let mounted = true;
        const search = () => {
            if ((state === null || state === void 0 ? void 0 : state.key) !== needle) {
                if (mounted)
                    onSearch();
            }
        };
        // Search when there's 500ms since the last keystroke.
        const id = setTimeout(search, 500);
        return () => {
            mounted = false;
            clearTimeout(id);
        };
    }, [needle, state === null || state === void 0 ? void 0 : state.key, onSearch]);
    if (!isInitialized)
        return react_1.default.createElement(layout_1.LoadingComponent, null);
    const searchBar = (react_1.default.createElement(input_1.SearchBar, { needle: needle, onNeedleChange: setNeedle, onSearch: onSearch, onFocus: onFocus, isLoading: state.isLoading, disabled: !isOnline }));
    return (react_1.default.createElement("section", { className: 'popup' },
        react_1.default.createElement(layout_1.Banner, null),
        react_1.default.createElement(TopMenu_1.TopMenu, { searchBar: searchBar, menuItems: menuItems }),
        react_1.default.createElement("article", { className: 'popup-page' }, page)));
};


/***/ }),

/***/ "./src/components/Popup/index.ts":
/*!***************************************!*\
  !*** ./src/components/Popup/index.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./Popup */ "./src/components/Popup/Popup.tsx"), exports);


/***/ }),

/***/ "./src/components/Popup/layout/TopMenu.scss":
/*!**************************************************!*\
  !*** ./src/components/Popup/layout/TopMenu.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./TopMenu.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Popup/layout/TopMenu.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Popup/layout/TopMenu.tsx":
/*!*************************************************!*\
  !*** ./src/components/Popup/layout/TopMenu.tsx ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TopMenu = void 0;
const react_1 = __importStar(__webpack_require__(/*! react */ "react"));
const MenuIcon_1 = __webpack_require__(/*! ../../common/layout/MenuIcon */ "./src/components/common/layout/MenuIcon.tsx");
const Menu_1 = __webpack_require__(/*! ../../common/layout/Menu */ "./src/components/common/layout/Menu.tsx");
__webpack_require__(/*! ./TopMenu.scss */ "./src/components/Popup/layout/TopMenu.scss");
const MenuButton_1 = __webpack_require__(/*! ../../common/input/MenuButton */ "./src/components/common/input/MenuButton.tsx");
exports.TopMenu = ({ searchBar, menuItems, initialShowMenu }) => {
    const [showMenu, setShowMenu] = react_1.useState(initialShowMenu);
    react_1.useEffect(() => {
        setShowMenu(initialShowMenu);
    }, [initialShowMenu]);
    const toggleMenu = () => {
        setShowMenu(prevShowMenu => !prevShowMenu);
    };
    return (react_1.default.createElement("section", { className: 'top-menu' },
        searchBar,
        react_1.default.createElement(MenuButton_1.MenuButton, { className: `top-menu-button menu-button ${showMenu ? ' selected' : ''}`, onClick: toggleMenu, icon: react_1.default.createElement(MenuIcon_1.MenuIcon, { selected: showMenu }) }),
        react_1.default.createElement(Menu_1.Menu, { show: showMenu, items: menuItems, onClick: toggleMenu })));
};


/***/ }),

/***/ "./src/components/Popup/layout/Welcome.scss":
/*!**************************************************!*\
  !*** ./src/components/Popup/layout/Welcome.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Welcome.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Popup/layout/Welcome.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Popup/layout/Welcome.tsx":
/*!*************************************************!*\
  !*** ./src/components/Popup/layout/Welcome.tsx ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Welcome = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./Welcome.scss */ "./src/components/Popup/layout/Welcome.scss");
const layout_1 = __webpack_require__(/*! ../../common/layout */ "./src/components/common/layout/index.ts");
exports.Welcome = ({ isInitialized, siteOptions }) => {
    if (!isInitialized)
        return react_1.default.createElement(layout_1.LoadingComponent, null);
    return (react_1.default.createElement("section", { className: 'welcome' },
        react_1.default.createElement("article", { className: 'welcome-article welcome-message' },
            react_1.default.createElement("h2", null, "Welcome to StoredSafe!"),
            react_1.default.createElement("p", null, "To use StoredSafe, you need to have access to a StoredSafe server."),
            react_1.default.createElement("p", null, "If you have the information for your StoredSafe server, you can add it below. If not, you should ask your administrator to set it up for you."),
            react_1.default.createElement("p", null,
                "If you are not yet a StoredSafe customer, please visit",
                ' ',
                react_1.default.createElement("a", { href: 'https://storedsafe.com/' }, "storedsafe.com"),
                " for more information.")),
        react_1.default.createElement("article", { className: 'welcome-article welcome-options' }, siteOptions)));
};


/***/ }),

/***/ "./src/components/Save/Save.scss":
/*!***************************************!*\
  !*** ./src/components/Save/Save.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/postcss-loader/src!../../../node_modules/sass-loader/dist/cjs.js!./Save.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Save/Save.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Save/Save.tsx":
/*!**************************************!*\
  !*** ./src/components/Save/Save.tsx ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Save = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const useLoading_1 = __webpack_require__(/*! ../../hooks/utils/useLoading */ "./src/hooks/utils/useLoading.ts");
const useForm_1 = __webpack_require__(/*! ../../hooks/utils/useForm */ "./src/hooks/utils/useForm.ts");
const input_1 = __webpack_require__(/*! ../common/input */ "./src/components/common/input/index.ts");
const layout_1 = __webpack_require__(/*! ../common/layout */ "./src/components/common/layout/index.ts");
__webpack_require__(/*! ./Save.scss */ "./src/components/Save/Save.scss");
exports.Save = ({ isInitialized, error, tabValues, hosts, vaults, templates, save, addToBlacklist, success, close }) => {
    var _a;
    if (!isInitialized)
        return react_1.default.createElement(layout_1.LoadingComponent, null);
    const [values, events] = useForm_1.useForm(Object.assign({ parentid: '0' }, (tabValues !== undefined ? tabValues : {})));
    const [saveState, setSavePromise] = useLoading_1.useLoading();
    const [blacklistState, setBlacklistPromise] = useLoading_1.useLoading();
    /// /////////////////////////////////////////////////////////
    // Set up event handlers
    function onHostChange({ target }) {
        hosts.onChange(Number(target.value));
    }
    function onVaultChange({ target }) {
        vaults.onChange(Number(target.value));
    }
    function onTemplateChange({ target }) {
        templates.onChange(Number(target.value));
    }
    /// /////////////////////////////////////////////////////////
    // Set up select boxes
    let selectHost = null;
    let selectVault = null;
    let selectTemplate = null;
    if (hosts.values.length > 1) {
        selectHost = (react_1.default.createElement("label", { htmlFor: 'host' },
            react_1.default.createElement("span", null, "Host"),
            react_1.default.createElement(input_1.Select, { value: hosts.selected, onChange: onHostChange, name: 'host', id: 'host' }, hosts.values.map((host, id) => (react_1.default.createElement("option", { key: host, value: id }, host))))));
    }
    else {
        selectHost = react_1.default.createElement("h2", null, (_a = hosts.values) === null || _a === void 0 ? void 0 : _a[hosts.selected]);
    }
    /// /////////////////////////////////////////////////////////
    // Handle error states
    if (error !== undefined) {
        return (react_1.default.createElement("section", { className: 'save' },
            selectHost,
            react_1.default.createElement(layout_1.Message, { type: 'error' },
                "Error: ",
                error.message)));
    }
    if (vaults.values.length === 0) {
        return (react_1.default.createElement("section", { className: 'save' },
            selectHost,
            react_1.default.createElement(layout_1.Message, { type: 'warning' },
                react_1.default.createElement("p", null, "No vaults with write access found for this host."),
                react_1.default.createElement("p", null, "Add a vault or ask your administrator to give you access to one."))));
    }
    if (templates.values.length === 0) {
        return (react_1.default.createElement("section", { className: 'save' },
            selectHost,
            react_1.default.createElement(layout_1.Message, { type: 'error' },
                react_1.default.createElement("p", null, "No templates found for this host."),
                react_1.default.createElement("p", null, "No templates are available, please contact your administrator."))));
    }
    /// /////////////////////////////////////////////////////////
    // Continue select boxes
    if (vaults.values.length > 1) {
        selectVault = (react_1.default.createElement("label", { htmlFor: 'vault' },
            react_1.default.createElement("span", null, "Vault"),
            react_1.default.createElement(input_1.Select, { value: vaults.selected, onChange: onVaultChange, name: 'vault', id: 'vault' }, vaults.values.map((vault, id) => (react_1.default.createElement("option", { key: vault.id, value: id }, vault.name))))));
    }
    if (templates.values.length > 1) {
        selectTemplate = (react_1.default.createElement("label", { htmlFor: 'template' },
            react_1.default.createElement("span", null, "Template"),
            react_1.default.createElement(input_1.Select, { value: templates.selected, onChange: onTemplateChange, name: 'template', id: 'template' }, templates.values.map((template, id) => (react_1.default.createElement("option", { key: template.id, value: id }, template.name))))));
    }
    /// /////////////////////////////////////////////////////////
    // Submit handlers
    function onSave(event) {
        event.preventDefault();
        const host = hosts.values[hosts.selected];
        if (host === undefined) {
            setSavePromise(Promise.reject(new Error('No host selected.')));
            return;
        }
        const vault = vaults.values[vaults.selected];
        if (vault === undefined) {
            setSavePromise(Promise.reject(new Error('No vault selected.')));
            return;
        }
        const template = templates.values[templates.selected];
        if (template === undefined) {
            setSavePromise(Promise.reject(new Error('No template selected.')));
            return;
        }
        // Filter out irrelevant fields
        const { templateid, groupid, parentid } = values;
        const properties = { templateid, groupid, parentid };
        for (const { name } of template.structure) {
            if (values[name] !== undefined) {
                properties[name] = values[name];
            }
        }
        // Save global properties
        properties.groupid = vault.id;
        properties.templateid = template.id;
        setSavePromise(save(host, properties));
    }
    function onAddToBlacklist() {
        if (tabValues !== undefined) {
            addToBlacklist(tabValues.url).then(() => close());
        }
    }
    const template = templates.values[templates.selected];
    let fields = null;
    if ((template === null || template === void 0 ? void 0 : template.structure) !== undefined) {
        fields = template.structure.map(({ title, name, isEncrypted, type }) => {
            const value = values[name] !== undefined ? values[name] : '';
            return (react_1.default.createElement("label", { key: name, htmlFor: name, className: 'save-field' },
                react_1.default.createElement("span", null, title),
                react_1.default.createElement("input", Object.assign({ className: `save-field${isEncrypted ? ' encrypted' : ''}`, type: type === 'text-passwdgen' ? 'password' : 'text', id: name, name: name, value: value }, events))));
        });
    }
    return (react_1.default.createElement("section", { className: 'save' }, success ? (react_1.default.createElement(layout_1.Message, null, "Successfully added object to StoredSafe.")) : (react_1.default.createElement("form", { className: 'save-form', onSubmit: onSave },
        react_1.default.createElement("div", { className: 'save-fields' },
            selectHost,
            selectVault,
            selectTemplate,
            fields),
        react_1.default.createElement("div", { className: 'save-buttons' },
            saveState.error !== undefined && (react_1.default.createElement(layout_1.Message, { type: 'error' },
                "Error: ",
                saveState.error.message)),
            react_1.default.createElement(input_1.Button, { color: 'accent', isLoading: saveState.isLoading }, "Add to StoredSafe"),
            react_1.default.createElement(input_1.Button, { color: 'danger', onClick: close }, "Close"),
            react_1.default.createElement(input_1.Button, { type: 'button', color: 'primary', onClick: onAddToBlacklist, isLoading: blacklistState.isLoading },
                "Don't ask to save for ",
                tabValues.url))))));
};


/***/ }),

/***/ "./src/components/Search/Search.tsx":
/*!******************************************!*\
  !*** ./src/components/Search/Search.tsx ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Search = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const layout_1 = __webpack_require__(/*! ../common/layout */ "./src/components/common/layout/index.ts");
const SearchTitle_1 = __webpack_require__(/*! ./layout/SearchTitle */ "./src/components/Search/layout/SearchTitle.tsx");
const ObjectView_1 = __webpack_require__(/*! ./layout/ObjectView */ "./src/components/Search/layout/ObjectView.tsx");
exports.Search = ({ isInitialized, results, errors, fill, copy, show, goto }) => {
    if (!isInitialized)
        return null;
    let numResults = 0;
    if (results !== undefined) {
        numResults = [...results.values()].reduce((acc, ssObjects) => acc + ssObjects.length, 0);
    }
    if (numResults === 0) {
        return (react_1.default.createElement("section", { className: 'search' },
            react_1.default.createElement(layout_1.Message, null, "No results found.")));
    }
    const items = [];
    for (const [host, ssObjects] of results) {
        if (errors.has(host)) {
            continue;
        }
        ssObjects.forEach((ssObject, id) => {
            items.push({
                key: `${host}-${ssObject.id}`,
                title: react_1.default.createElement(SearchTitle_1.SearchTitle, { result: ssObject, host: results.size > 1 ? host : undefined }),
                content: (react_1.default.createElement(ObjectView_1.ObjectView, { host: host, result: ssObject, resultId: id, onCopy: copy, onFill: fill, onShow: show }))
            });
        });
    }
    const defaultSelected = items.length === 1 ? items[0].key : undefined;
    return (react_1.default.createElement("section", { className: 'search' },
        react_1.default.createElement(layout_1.ListView, { items: items, defaultSelected: defaultSelected })));
};


/***/ }),

/***/ "./src/components/Search/layout/ObjectView.scss":
/*!******************************************************!*\
  !*** ./src/components/Search/layout/ObjectView.scss ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./ObjectView.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Search/layout/ObjectView.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Search/layout/ObjectView.tsx":
/*!*****************************************************!*\
  !*** ./src/components/Search/layout/ObjectView.tsx ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObjectView = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./ObjectView.scss */ "./src/components/Search/layout/ObjectView.scss");
const input_1 = __webpack_require__(/*! ../../common/input */ "./src/components/common/input/index.ts");
exports.ObjectView = ({ host, resultId, result, onShow, onCopy, onFill }) => {
    const encryptedFieldText = (field, onShow) => {
        if (!field.isShowing) {
            return (react_1.default.createElement("button", { className: 'show', onClick: onShow }, "show"));
        }
        return field.value.split('').map((c, i) => {
            let className = 'encrypted-field';
            if (/[0-9]/.test(c)) {
                className += ' number';
            }
            else if (/[a-z]/.test(c)) {
                className += ' lowercase';
            }
            else if (/[A-Z]/.test(c)) {
                className += ' uppercase';
            }
            else {
                className += ' symbol';
            }
            return (react_1.default.createElement("span", { key: i, className: className }, c));
        });
    };
    return (react_1.default.createElement("section", { className: 'object-view' },
        react_1.default.createElement("article", { className: 'object-view-container' },
            react_1.default.createElement(input_1.Button, { className: 'object-view-fill', onClick: () => onFill(host, resultId) }, "Fill"),
            result.fields.map((field, fieldId) => {
                let value;
                if (field.isEncrypted) {
                    value = encryptedFieldText(field, () => onShow(host, resultId, fieldId));
                }
                else {
                    value = field.value;
                }
                return (react_1.default.createElement("div", { className: 'object-view-field', key: field.name },
                    react_1.default.createElement("p", { className: 'object-view-field-text' },
                        react_1.default.createElement("span", { className: 'field-title' }, field.title),
                        react_1.default.createElement("span", { className: 'field-value' }, value)),
                    react_1.default.createElement("button", { className: 'object-view-field-copy', onClick: () => onCopy(host, resultId, fieldId) }, "Copy")));
            }))));
};


/***/ }),

/***/ "./src/components/Search/layout/SearchTitle.scss":
/*!*******************************************************!*\
  !*** ./src/components/Search/layout/SearchTitle.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SearchTitle.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/Search/layout/SearchTitle.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/Search/layout/SearchTitle.tsx":
/*!******************************************************!*\
  !*** ./src/components/Search/layout/SearchTitle.tsx ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchTitle = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const icons_1 = __importDefault(__webpack_require__(/*! ./icons */ "./src/components/Search/layout/icons/index.ts"));
__webpack_require__(/*! ./SearchTitle.scss */ "./src/components/Search/layout/SearchTitle.scss");
exports.SearchTitle = ({ host, result }) => (react_1.default.createElement("article", { style: { backgroundImage: `url('${icons_1.default[result.icon]}')` }, className: 'search-title' },
    react_1.default.createElement("div", { className: 'search-title-text' },
        react_1.default.createElement("p", { className: 'search-title-name' }, result.name),
        host !== undefined && react_1.default.createElement("p", { className: 'search-title-host' }, host))));


/***/ }),

/***/ "./src/components/Search/layout/icons/certfolder.svg":
/*!***********************************************************!*\
  !*** ./src/components/Search/layout/icons/certfolder.svg ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "5cc9493826be0914732ec24f7b277025.svg");

/***/ }),

/***/ "./src/components/Search/layout/icons/credit_card.svg":
/*!************************************************************!*\
  !*** ./src/components/Search/layout/icons/credit_card.svg ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "1feb6f4e634ae913bf806337936965dc.svg");

/***/ }),

/***/ "./src/components/Search/layout/icons/file.svg":
/*!*****************************************************!*\
  !*** ./src/components/Search/layout/icons/file.svg ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "680fc3288477a68cfee0803990127469.svg");

/***/ }),

/***/ "./src/components/Search/layout/icons/folder.svg":
/*!*******************************************************!*\
  !*** ./src/components/Search/layout/icons/folder.svg ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "27b0f6cb1c33b2daba67148d65d4a695.svg");

/***/ }),

/***/ "./src/components/Search/layout/icons/index.ts":
/*!*****************************************************!*\
  !*** ./src/components/Search/layout/icons/index.ts ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const server_svg_1 = __importDefault(__webpack_require__(/*! ./server.svg */ "./src/components/Search/layout/icons/server.svg"));
const certfolder_svg_1 = __importDefault(__webpack_require__(/*! ./certfolder.svg */ "./src/components/Search/layout/icons/certfolder.svg"));
const credit_card_svg_1 = __importDefault(__webpack_require__(/*! ./credit_card.svg */ "./src/components/Search/layout/icons/credit_card.svg"));
const file_svg_1 = __importDefault(__webpack_require__(/*! ./file.svg */ "./src/components/Search/layout/icons/file.svg"));
const folder_svg_1 = __importDefault(__webpack_require__(/*! ./folder.svg */ "./src/components/Search/layout/icons/folder.svg"));
const note_svg_1 = __importDefault(__webpack_require__(/*! ./note.svg */ "./src/components/Search/layout/icons/note.svg"));
const person_svg_1 = __importDefault(__webpack_require__(/*! ./person.svg */ "./src/components/Search/layout/icons/person.svg"));
const pin_svg_1 = __importDefault(__webpack_require__(/*! ./pin.svg */ "./src/components/Search/layout/icons/pin.svg"));
const quicknote_svg_1 = __importDefault(__webpack_require__(/*! ./quicknote.svg */ "./src/components/Search/layout/icons/quicknote.svg"));
const icons = {
    ico_folder: folder_svg_1.default,
    ico_person: person_svg_1.default,
    ico_server: server_svg_1.default,
    ico_quicknote: quicknote_svg_1.default,
    ico_note: note_svg_1.default,
    ico_pin: pin_svg_1.default,
    ico_ccard: credit_card_svg_1.default,
    ico_certfolder: certfolder_svg_1.default,
    ico_file: file_svg_1.default,
    ccard: credit_card_svg_1.default,
    certfolder: certfolder_svg_1.default,
    credit_card: credit_card_svg_1.default,
    file: file_svg_1.default,
    folder: folder_svg_1.default,
    note: note_svg_1.default,
    person: person_svg_1.default,
    pin: pin_svg_1.default,
    quicknote: quicknote_svg_1.default,
    server: server_svg_1.default
};
exports.default = icons;


/***/ }),

/***/ "./src/components/Search/layout/icons/note.svg":
/*!*****************************************************!*\
  !*** ./src/components/Search/layout/icons/note.svg ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "6c27f69c470aa7eed054aefae1542208.svg");

/***/ }),

/***/ "./src/components/Search/layout/icons/person.svg":
/*!*******************************************************!*\
  !*** ./src/components/Search/layout/icons/person.svg ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "6dba742b56adfa878f45c20bd10f3e6b.svg");

/***/ }),

/***/ "./src/components/Search/layout/icons/pin.svg":
/*!****************************************************!*\
  !*** ./src/components/Search/layout/icons/pin.svg ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "91b5abd284245ee5558ca7e8195ccdf0.svg");

/***/ }),

/***/ "./src/components/Search/layout/icons/quicknote.svg":
/*!**********************************************************!*\
  !*** ./src/components/Search/layout/icons/quicknote.svg ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "f50eb22c52de9b623c07e35e180e38f1.svg");

/***/ }),

/***/ "./src/components/Search/layout/icons/server.svg":
/*!*******************************************************!*\
  !*** ./src/components/Search/layout/icons/server.svg ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "1a48c382a92056b5f95a744309b7c840.svg");

/***/ }),

/***/ "./src/components/common/input/Button.scss":
/*!*************************************************!*\
  !*** ./src/components/common/input/Button.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Button.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Button.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/input/Button.tsx":
/*!************************************************!*\
  !*** ./src/components/common/input/Button.tsx ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Button = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./Button.scss */ "./src/components/common/input/Button.scss");
exports.Button = (_a) => {
    var { color, isLoading, children, className } = _a, props = __rest(_a, ["color", "isLoading", "children", "className"]);
    const classNames = [
        `button button-${color}`,
        isLoading ? 'button-loading' : '',
        className
    ].join(' ');
    return (react_1.default.createElement("button", Object.assign({ className: classNames }, props),
        react_1.default.createElement("div", { className: 'button-children' }, children),
        react_1.default.createElement("div", { className: 'button-spinner' })));
};
exports.Button.defaultProps = {
    color: 'primary',
    isLoading: false,
    children: null,
    className: ''
};


/***/ }),

/***/ "./src/components/common/input/Checkbox.scss":
/*!***************************************************!*\
  !*** ./src/components/common/input/Checkbox.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Checkbox.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Checkbox.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/input/Checkbox.tsx":
/*!**************************************************!*\
  !*** ./src/components/common/input/Checkbox.tsx ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Checkbox = void 0;
const React = __importStar(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./Checkbox.scss */ "./src/components/common/input/Checkbox.scss");
exports.Checkbox = (props) => (React.createElement(React.Fragment, null,
    React.createElement("div", { style: { display: 'inline-block' }, className: 'checkbox' },
        React.createElement("input", Object.assign({ type: 'checkbox' }, props)),
        React.createElement("div", { className: 'custom-checkbox' }))));


/***/ }),

/***/ "./src/components/common/input/MenuButton.scss":
/*!*****************************************************!*\
  !*** ./src/components/common/input/MenuButton.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./MenuButton.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/MenuButton.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/input/MenuButton.tsx":
/*!****************************************************!*\
  !*** ./src/components/common/input/MenuButton.tsx ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MenuButton = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./MenuButton.scss */ "./src/components/common/input/MenuButton.scss");
exports.MenuButton = (_a) => {
    var { icon, className } = _a, props = __rest(_a, ["icon", "className"]);
    const classNames = ['menu-button', className].join(' ');
    return (react_1.default.createElement("button", Object.assign({ className: classNames }, props), icon));
};


/***/ }),

/***/ "./src/components/common/input/Radio.scss":
/*!************************************************!*\
  !*** ./src/components/common/input/Radio.scss ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Radio.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Radio.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/input/Radio.tsx":
/*!***********************************************!*\
  !*** ./src/components/common/input/Radio.tsx ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Radio = void 0;
const React = __importStar(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./Radio.scss */ "./src/components/common/input/Radio.scss");
exports.Radio = (props) => (React.createElement(React.Fragment, null,
    React.createElement("div", { style: { display: 'inline-block' }, className: 'radio' },
        React.createElement("input", Object.assign({ type: 'radio' }, props)),
        React.createElement("div", { className: 'custom-radio' }))));


/***/ }),

/***/ "./src/components/common/input/SearchBar.scss":
/*!****************************************************!*\
  !*** ./src/components/common/input/SearchBar.scss ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./SearchBar.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/SearchBar.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/input/SearchBar.tsx":
/*!***************************************************!*\
  !*** ./src/components/common/input/SearchBar.tsx ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchBar = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./SearchBar.scss */ "./src/components/common/input/SearchBar.scss");
const MenuButton_1 = __webpack_require__(/*! ./MenuButton */ "./src/components/common/input/MenuButton.tsx");
const layout_1 = __webpack_require__(/*! ../layout */ "./src/components/common/layout/index.ts");
exports.SearchBar = (_a) => {
    var { needle, onNeedleChange, onSearch, disabled, isLoading } = _a, props = __rest(_a, ["needle", "onNeedleChange", "onSearch", "disabled", "isLoading"]);
    const onSubmit = (event) => {
        event.preventDefault();
        onSearch();
    };
    return (react_1.default.createElement("section", { className: 'search-bar' },
        react_1.default.createElement("form", { className: `search-form${disabled ? ' disabled' : ''}`, onSubmit: onSubmit },
            react_1.default.createElement("input", Object.assign({ placeholder: 'Search', title: 'Search', "aria-label": 'Search Text' }, props, { className: 'search-bar-input', type: 'search', value: needle, disabled: disabled, onChange: ({ target }) => {
                    onNeedleChange(target.value);
                } })),
            react_1.default.createElement(MenuButton_1.MenuButton, { className: `search-button${isLoading ? ' loading' : ''}`, type: 'submit', "aria-label": 'Search Submit', title: 'Search', disabled: disabled, icon: layout_1.icons.search }))));
};
exports.SearchBar.defaultProps = {
    disabled: false
};


/***/ }),

/***/ "./src/components/common/input/Select.scss":
/*!*************************************************!*\
  !*** ./src/components/common/input/Select.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Select.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/input/Select.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/input/Select.tsx":
/*!************************************************!*\
  !*** ./src/components/common/input/Select.tsx ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Select = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./Select.scss */ "./src/components/common/input/Select.scss");
exports.Select = (_a) => {
    var { children } = _a, props = __rest(_a, ["children"]);
    return (react_1.default.createElement("div", { className: 'select' },
        react_1.default.createElement("div", { className: 'custom-select' },
            react_1.default.createElement("select", Object.assign({}, props), children))));
};


/***/ }),

/***/ "./src/components/common/input/index.ts":
/*!**********************************************!*\
  !*** ./src/components/common/input/index.ts ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./Button */ "./src/components/common/input/Button.tsx"), exports);
__exportStar(__webpack_require__(/*! ./Checkbox */ "./src/components/common/input/Checkbox.tsx"), exports);
__exportStar(__webpack_require__(/*! ./MenuButton */ "./src/components/common/input/MenuButton.tsx"), exports);
__exportStar(__webpack_require__(/*! ./Radio */ "./src/components/common/input/Radio.tsx"), exports);
__exportStar(__webpack_require__(/*! ./Select */ "./src/components/common/input/Select.tsx"), exports);
__exportStar(__webpack_require__(/*! ./SearchBar */ "./src/components/common/input/SearchBar.tsx"), exports);


/***/ }),

/***/ "./src/components/common/layout/Banner.scss":
/*!**************************************************!*\
  !*** ./src/components/common/layout/Banner.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Banner.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Banner.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/layout/Banner.tsx":
/*!*************************************************!*\
  !*** ./src/components/common/layout/Banner.tsx ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Banner = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const Logo_1 = __webpack_require__(/*! ./Logo */ "./src/components/common/layout/Logo.tsx");
__webpack_require__(/*! ./Banner.scss */ "./src/components/common/layout/Banner.scss");
exports.Banner = ({ children }) => (react_1.default.createElement("div", { className: 'banner' },
    react_1.default.createElement(Logo_1.Logo, null),
    children));


/***/ }),

/***/ "./src/components/common/layout/ListView.scss":
/*!****************************************************!*\
  !*** ./src/components/common/layout/ListView.scss ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./ListView.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/ListView.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/layout/ListView.tsx":
/*!***************************************************!*\
  !*** ./src/components/common/layout/ListView.tsx ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListView = void 0;
const react_1 = __importStar(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./ListView.scss */ "./src/components/common/layout/ListView.scss");
exports.ListView = ({ items, defaultSelected }) => {
    const defaultExists = items.findIndex(({ key }) => defaultSelected) !== -1;
    const [selected, setSelected] = react_1.useState(defaultExists ? defaultSelected : undefined);
    react_1.useEffect(() => {
        const newDefaultExists = items.findIndex(({ key }) => defaultSelected) !== -1;
        setSelected(newDefaultExists ? defaultSelected : undefined);
    }, [defaultSelected]);
    const hasSelected = selected !== undefined;
    const list = items.map(item => {
        const isSelected = selected === item.key;
        const onSelect = () => {
            if (isSelected) {
                setSelected(undefined);
            }
            else {
                setSelected(item.key);
            }
        };
        const classNames = [
            'list-view-item',
            isSelected ? 'selected' : hasSelected ? 'hidden' : ''
        ].join(' ');
        return (react_1.default.createElement("article", { className: classNames, key: item.key },
            react_1.default.createElement("article", { className: 'list-view-item-title', onClick: onSelect }, item.title),
            react_1.default.createElement("article", { className: 'list-view-item-content' }, item.content)));
    });
    return (react_1.default.createElement("section", { className: `list-view${hasSelected ? ' has-selected' : ''}` }, list));
};


/***/ }),

/***/ "./src/components/common/layout/LoadingComponent.scss":
/*!************************************************************!*\
  !*** ./src/components/common/layout/LoadingComponent.scss ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./LoadingComponent.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/LoadingComponent.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/layout/LoadingComponent.tsx":
/*!***********************************************************!*\
  !*** ./src/components/common/layout/LoadingComponent.tsx ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoadingComponent = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const LoadingSpinner_1 = __webpack_require__(/*! ./LoadingSpinner */ "./src/components/common/layout/LoadingSpinner.tsx");
__webpack_require__(/*! ./LoadingComponent.scss */ "./src/components/common/layout/LoadingComponent.scss");
exports.LoadingComponent = () => (react_1.default.createElement("div", { className: 'loading-component' },
    react_1.default.createElement(LoadingSpinner_1.LoadingSpinner, null)));


/***/ }),

/***/ "./src/components/common/layout/LoadingSpinner.scss":
/*!**********************************************************!*\
  !*** ./src/components/common/layout/LoadingSpinner.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./LoadingSpinner.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/LoadingSpinner.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/layout/LoadingSpinner.tsx":
/*!*********************************************************!*\
  !*** ./src/components/common/layout/LoadingSpinner.tsx ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoadingSpinner = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./LoadingSpinner.scss */ "./src/components/common/layout/LoadingSpinner.scss");
exports.LoadingSpinner = ({ status }) => (react_1.default.createElement("div", { className: 'loading-spinner' },
    react_1.default.createElement("div", { className: `spinner ${status}` })));
exports.LoadingSpinner.defaultProps = {
    status: 'loading'
};


/***/ }),

/***/ "./src/components/common/layout/Logo.scss":
/*!************************************************!*\
  !*** ./src/components/common/layout/Logo.scss ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Logo.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Logo.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/layout/Logo.tsx":
/*!***********************************************!*\
  !*** ./src/components/common/layout/Logo.tsx ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logo = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const logo_png_1 = __importDefault(__webpack_require__(/*! ./logo.png */ "./src/components/common/layout/logo.png"));
__webpack_require__(/*! ./Logo.scss */ "./src/components/common/layout/Logo.scss");
exports.Logo = () => (react_1.default.createElement("img", { src: logo_png_1.default, alt: 'StoredSafe', className: 'logo' }));


/***/ }),

/***/ "./src/components/common/layout/Menu.scss":
/*!************************************************!*\
  !*** ./src/components/common/layout/Menu.scss ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Menu.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Menu.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/layout/Menu.tsx":
/*!***********************************************!*\
  !*** ./src/components/common/layout/Menu.tsx ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Menu = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./Menu.scss */ "./src/components/common/layout/Menu.scss");
exports.Menu = ({ show, items, onClick: closeMenu }) => {
    const onItemClick = (onClick) => {
        return () => {
            onClick();
            closeMenu === null || closeMenu === void 0 ? void 0 : closeMenu();
        };
    };
    return (react_1.default.createElement("section", { className: `menu${show ? ' show' : ''}` },
        react_1.default.createElement("div", { className: 'menu-backdrop' },
            react_1.default.createElement("div", { className: 'menu-box' }, items.map(({ title, icon, onClick }) => (react_1.default.createElement("article", { key: title, className: 'menu-item', onClick: onItemClick(onClick) },
                react_1.default.createElement("p", null, title),
                icon)))))));
};


/***/ }),

/***/ "./src/components/common/layout/MenuIcon.scss":
/*!****************************************************!*\
  !*** ./src/components/common/layout/MenuIcon.scss ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./MenuIcon.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/MenuIcon.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/layout/MenuIcon.tsx":
/*!***************************************************!*\
  !*** ./src/components/common/layout/MenuIcon.tsx ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MenuIcon = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./MenuIcon.scss */ "./src/components/common/layout/MenuIcon.scss");
exports.MenuIcon = ({ selected }) => {
    return (react_1.default.createElement("div", { className: `menu-icon${selected ? ' selected' : ''}` },
        react_1.default.createElement("div", { className: 'menu-icon-bar menu-icon-bar-1' }),
        react_1.default.createElement("div", { className: 'menu-icon-bar menu-icon-bar-2' }),
        react_1.default.createElement("div", { className: 'menu-icon-bar menu-icon-bar-3' })));
};


/***/ }),

/***/ "./src/components/common/layout/Message.scss":
/*!***************************************************!*\
  !*** ./src/components/common/layout/Message.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!./Message.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/components/common/layout/Message.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/common/layout/Message.tsx":
/*!**************************************************!*\
  !*** ./src/components/common/layout/Message.tsx ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Message = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./Message.scss */ "./src/components/common/layout/Message.scss");
exports.Message = ({ type, children }) => {
    return react_1.default.createElement("div", { className: `message ${type}` }, children);
};
exports.Message.defaultProps = {
    type: 'info'
};


/***/ }),

/***/ "./src/components/common/layout/icons.tsx":
/*!************************************************!*\
  !*** ./src/components/common/layout/icons.tsx ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.icons = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
exports.icons = {
    search: (react_1.default.createElement("svg", { className: 'icon', width: '40', height: '40', version: '1.1', viewBox: '0 0 10.583 10.583', xmlns: 'http://www.w3.org/2000/svg' },
        react_1.default.createElement("path", { d: 'm7.1231.39901a3.0579 3.0579 0 00-3.0546 3.0579 3.0579 3.0579 0 00.56619 1.7722 3.0579 3.0579 0 000 .0004778l-4.2357 4.2352.71957.71956 4.2352-4.2352a3.0579 3.0579 0 001.7726.56571 3.0579 3.0579 0 003.0579-3.0579 3.0579 3.0579 0 00-3.0579-3.0579 3.0579 3.0579 0 00-.00334 0zm-.029146.89635a2.1616 2.1616 0 01.03249 0 2.1616 2.1616 0 012.1616 2.1616 2.1616 2.1616 0 01-2.1616 2.1616 2.1616 2.1616 0 01-2.1616-2.1616 2.1616 2.1616 0 012.1291-2.1616z' }))),
    vault_locked: (react_1.default.createElement("svg", { className: 'icon', width: '40', height: '40', version: '1.1', viewBox: '0 0 10.583 10.583', xmlns: 'http://www.w3.org/2000/svg' },
        react_1.default.createElement("path", { transform: 'scale(.26458)', d: 'm5.2637 0c-2.9158 5.9212e-16-5.2637 2.288-5.2637 5.1309v28.738c5.9212e-16 2.8429 2.3479 5.1309 5.2637 5.1309h-.26367v1h3v-1h24v1h3v-1h-.26367c2.9158 0 5.2637-2.288 5.2637-5.1309v-28.738c0-2.8429-2.3479-5.1309-5.2637-5.1309h-29.473zm1.2812 1.6973h26.91c2.662 0 4.8047 2.0901 4.8047 4.6855v26.234c0 2.5955-2.1427 4.6855-4.8047 4.6855h-26.91c-2.662 0-4.8047-2.0901-4.8047-4.6855v-26.234c0-2.5955 2.1427-4.6855 4.8047-4.6855zm.83984 1.1074c-2.4963 0-4.5078 1.9607-4.5078 4.3945v24.602c0 2.4338 2.0116 4.3945 4.5078 4.3945h25.23c2.4963 0 4.5078-1.9607 4.5078-4.3945v-24.602c0-2.4338-2.0116-4.3945-4.5078-4.3945h-25.23zm20.492 11.256a5.9606 5.9606 0 01.125 0 5.9606 5.9606 0 015.959 5.959 5.9606 5.9606 0 01-5.959 5.959 5.9606 5.9606 0 01-5.9629-5.959 5.9606 5.9606 0 015.8379-5.959zm.125 1.4453a4.5134 4.5134 0 00-4.5137 4.5137 4.5134 4.5134 0 004.5137 4.5137 4.5134 4.5134 0 004.5117-4.5137 4.5134 4.5134 0 00-4.5117-4.5137zm-18.609.14844a4.3661 4.3661 0 012.2793.58398 4.3661 4.3661 0 012.0449 2.6992h3.0117c.39944 0 .7207.32127.7207.7207v.72266c0 .39944-.32126.7207-.7207.7207h-3.0117a4.3661 4.3661 0 01-.44727 1.1016 4.3661 4.3661 0 01-5.9648 1.5977 4.3661 4.3661 0 01-1.5977-5.9648 4.3661 4.3661 0 013.6855-2.1816zm18.609 1a3.3644 3.3644 0 013.3633 3.3652 3.3644 3.3644 0 01-3.3633 3.3652 3.3644 3.3644 0 01-3.3652-3.3652 3.3644 3.3644 0 013.3652-3.3652zm-18.57.58203a2.7845 2.7845 0 00-2.3555 1.3906 2.7845 2.7845 0 001.0195 3.8027 2.7845 2.7845 0 003.8027-1.0176 2.7845 2.7845 0 00-1.0176-3.8027 2.7845 2.7845 0 00-1.4492-.37305z' }))),
    vault_unlocked: (react_1.default.createElement("svg", { className: 'icon', width: '40', height: '40', version: '1.1', viewBox: '0 0 10.583 10.583', xmlns: 'http://www.w3.org/2000/svg' },
        react_1.default.createElement("path", { transform: 'scale(.26458)', d: 'm5.2637 0c-2.9158 0-5.2637 2.288-5.2637 5.1309v28.738c0 2.8429 2.3479 5.1309 5.2637 5.1309h-.26367v1h3v-1h24v1h3v-1h-.26367c2.9158 0 5.2637-2.288 5.2637-5.1309v-28.738c0-2.8429-2.3479-5.1309-5.2637-5.1309h-29.473zm1.2812 1.6973h26.91c2.662 0 4.8047 2.0901 4.8047 4.6855v26.234c0 2.5955-2.1427 4.6855-4.8047 4.6855h-26.91c-2.662 0-4.8047-2.0901-4.8047-4.6855v-26.234c0-2.5955 2.1427-4.6855 4.8047-4.6855zm15.625 1.7344c-1.2013 0-2.1699 1.8859-2.1699 4.2285v23.68c0 2.3426.9686 4.2285 2.1699 4.2285h12.143c1.2013 0 2.168-1.8859 2.168-4.2285v-23.68c0-2.3426-.96665-4.2285-2.168-4.2285h-12.143zm9.9219 10.832a2.8686 5.7371 0 012.8672 5.7363 2.8686 5.7371 0 01-2.8672 5.7363 2.8686 5.7371 0 01-2.8691-5.7363 2.8686 5.7371 0 012.8691-5.7363zm0 1.3926a2.1721 4.3442 0 00-2.1719 4.3438 2.1721 4.3442 0 002.1719 4.3438 2.1721 4.3442 0 002.1719-4.3438 2.1721 4.3442 0 00-2.1719-4.3438zm-8.9551.14258a2.1012 4.2024 0 011.0957.5625 2.1012 4.2024 0 01.98438 2.5977h1.4492c.19223 0 .34766.3089.34766.69336v.69531c0 .38446-.15542.69336-.34766.69336h-1.4492a2.1012 4.2024 0 01-.21484 1.0605 2.1012 4.2024 0 01-2.8711 1.5371 2.1012 4.2024 0 01-.76953-5.7402 2.1012 4.2024 0 011.7754-2.0996zm8.9551.96289a1.6191 3.2383 0 011.6191 3.2383 1.6191 3.2383 0 01-1.6191 3.2383 1.6191 3.2383 0 01-1.6191-3.2383 1.6191 3.2383 0 011.6191-3.2383zm-8.9375.55859a1.3401 2.6801 0 00-1.1328 1.3398 1.3401 2.6801 0 00.49024 3.6602 1.3401 2.6801 0 001.8301-.98047 1.3401 2.6801 0 00-.49024-3.6602 1.3401 2.6801 0 00-.69726-.35938z' }))),
    options: (react_1.default.createElement("svg", { className: 'icon', width: '40', height: '40', version: '1.1', viewBox: '0 0 10.583 10.583', xmlns: 'http://www.w3.org/2000/svg' },
        react_1.default.createElement("g", { transform: 'translate(0 -286.42)' },
            react_1.default.createElement("path", { d: 'm4.8943 286.42c-.1781-.002-.29665.0502-.41163.34759-.18397.47571-.35953.99273-.75923 1.1583-.3997.16555-.88962-.0761-1.3561-.28242-.46649-.20633-.49962.0325-.80554.33846-.30592.3059-.54479.33905-.33845.80553.20634.46647.44797.95638.28243 1.3561-.16555.3997-.68256.57526-1.1583.75923-.47573.18397-.32473.37635-.32473.80896s-.15099.62498.32473.80895c.47573.18397.99274.35953 1.1583.75922.16555.3997-.076087.8896-.28243 1.3561-.20634.46648.032536.49961.33845.80553.30592.30591.33906.54478.80554.33845.46649-.20634.9564-.44797 1.3561-.28242.3997.16555.57526.68255.75923 1.1583.18397.47573.37635.32474.80897.32474s.625.15099.80897-.32474c.18397-.47571.35953-.99271.75923-1.1583.3997-.16555.88961.0761 1.3561.28242.46649.20633.49962-.0325.80554-.33845.30592-.30592.54479-.33905.33845-.80553-.20634-.46648-.44797-.95638-.28243-1.3561.16555-.39969.68256-.57525 1.1583-.75922.47573-.18397.32473-.37634.32473-.80895s.15099-.62499-.32473-.80896c-.47573-.18397-.99274-.35953-1.1583-.75923-.16555-.39969.076087-.8896.28243-1.3561.20634-.46648-.032536-.49963-.33845-.80553-.30592-.30592-.33906-.54479-.80554-.33846-.46649.20634-.9564.44797-1.3561.28242-.3997-.16553-.5758-.68255-.75981-1.1583-.18401-.47573-.37593-.32473-.8084-.32473-.16223 0-.29048-.0214-.39734-.0229zm.39734 2.8208a2.4711 2.4711 0 012.4709 2.4709 2.4711 2.4711 0 01-2.4709 2.4709 2.4711 2.4711 0 01-2.4709-2.4709 2.4711 2.4711 0 012.4709-2.4709z', fill: '#fff' })))),
    warning: (react_1.default.createElement("svg", { className: 'icon icon-warning', width: '32', height: '32', version: '1.1', viewBox: '0 0 8.4667 8.4667', xmlns: 'http://www.w3.org/2000/svg' },
        react_1.default.createElement("path", { transform: 'scale(.26458)', d: 'm16.033 2.041c-.90656-.011474-1.7477.4677-2.1992 1.2539l-13.229 22.914c-.96138 1.6658.23877 3.748 2.1621 3.75h26.465c1.9233-.00201 3.1235-2.0842 2.1621-3.75l-13.229-22.914c-.43967-.76564-1.25-1.2416-2.1328-1.2539zm-.033203 5.8555c1.205 0 2.1758 1.0976 2.1758 2.4609v8.418c0 1.3633-.97083 2.4609-2.1758 2.4609s-2.1758-1.0976-2.1758-2.4609v-8.418c0-1.3633.97083-2.4609 2.1758-2.4609zm0 14.312a2.375 2.375 0 012.375 2.375 2.375 2.375 0 01-2.375 2.375 2.375 2.375 0 01-2.375-2.375 2.375 2.375 0 012.375-2.375z' }))),
    error: (react_1.default.createElement("svg", { className: 'icon icon-error', width: '32', height: '32', version: '1.1', viewBox: '0 0 8.4667 8.4667', xmlns: 'http://www.w3.org/2000/svg' },
        react_1.default.createElement("path", { transform: 'scale(.26458)', d: 'm15.992 2.9707a14.458 14.458 0 00-14.449 14.457 14.458 14.458 0 0014.457 14.459 14.458 14.458 0 0014.457-14.459 14.458 14.458 0 00-14.457-14.457 14.458 14.458 0 00-.007812 0zm.007812 4.9258c1.205 0 2.1758 1.0976 2.1758 2.4609v8.418c0 1.3633-.97083 2.4609-2.1758 2.4609s-2.1758-1.0976-2.1758-2.4609v-8.418c0-1.3633.97083-2.4609 2.1758-2.4609zm0 14.312a2.375 2.375 0 012.375 2.375 2.375 2.375 0 01-2.375 2.375 2.375 2.375 0 01-2.375-2.375 2.375 2.375 0 012.375-2.375z' }))),
    add: (react_1.default.createElement("svg", { className: 'icon icon-add', width: '32', height: '32', version: '1.1', viewBox: '0 0 8.4667 8.4667', xmlns: 'http://www.w3.org/2000/svg' },
        react_1.default.createElement("g", null,
            react_1.default.createElement("rect", { x: '3.5719', width: '1.3229', height: '8.4667' }),
            react_1.default.createElement("rect", { transform: 'rotate(90)', x: '3.5719', y: '-8.4667', width: '1.3229', height: '8.4667' }))))
};


/***/ }),

/***/ "./src/components/common/layout/index.ts":
/*!***********************************************!*\
  !*** ./src/components/common/layout/index.ts ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./icons */ "./src/components/common/layout/icons.tsx"), exports);
__exportStar(__webpack_require__(/*! ./Banner */ "./src/components/common/layout/Banner.tsx"), exports);
__exportStar(__webpack_require__(/*! ./ListView */ "./src/components/common/layout/ListView.tsx"), exports);
__exportStar(__webpack_require__(/*! ./LoadingComponent */ "./src/components/common/layout/LoadingComponent.tsx"), exports);
__exportStar(__webpack_require__(/*! ./LoadingSpinner */ "./src/components/common/layout/LoadingSpinner.tsx"), exports);
__exportStar(__webpack_require__(/*! ./Logo */ "./src/components/common/layout/Logo.tsx"), exports);
__exportStar(__webpack_require__(/*! ./Menu */ "./src/components/common/layout/Menu.tsx"), exports);
__exportStar(__webpack_require__(/*! ./MenuIcon */ "./src/components/common/layout/MenuIcon.tsx"), exports);
__exportStar(__webpack_require__(/*! ./Message */ "./src/components/common/layout/Message.tsx"), exports);


/***/ }),

/***/ "./src/components/common/layout/logo.png":
/*!***********************************************!*\
  !*** ./src/components/common/layout/logo.png ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "bd3d7d5043031cb2b1ccbe362679afc1.png");

/***/ }),

/***/ "./src/containers/Add.tsx":
/*!********************************!*\
  !*** ./src/containers/Add.tsx ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(__webpack_require__(/*! react */ "react"));
const Add_1 = __webpack_require__(/*! ../components/Add/Add */ "./src/components/Add/Add.tsx");
const useSessions_1 = __webpack_require__(/*! ../hooks/storage/useSessions */ "./src/hooks/storage/useSessions.ts");
const StoredSafe_1 = __webpack_require__(/*! ../model/storedsafe/StoredSafe */ "./src/model/storedsafe/StoredSafe.ts");
const useAdd = () => {
    const sessions = useSessions_1.useSessions();
    const [success, setSuccess] = react_1.useState(false);
    const [siteState, setSiteState] = react_1.useState();
    const isInitialized = sessions.isInitialized &&
        (siteState === null || siteState === void 0 ? void 0 : siteState.vaults) !== undefined &&
        (siteState === null || siteState === void 0 ? void 0 : siteState.templates) !== undefined;
    const addObject = async (host, values) => {
        await StoredSafe_1.actions.addObject(host, values);
        setSuccess(true);
    };
    const hostChange = react_1.useCallback(selected => {
        const host = [...sessions.sessions.keys()][selected];
        setSiteState({ host: selected });
        StoredSafe_1.actions.getSiteInfo(host)
            .then(({ vaults, templates }) => {
            vaults = vaults.filter(({ canWrite }) => canWrite);
            const vault = vaults.length > 0 ? 0 : undefined;
            const loginTemplateId = templates.findIndex(({ id }) => id === '20');
            const template = templates.length > 0
                ? loginTemplateId !== -1
                    ? loginTemplateId
                    : 0
                : undefined;
            setSiteState({ host: selected, vaults, templates, vault, template });
        })
            .catch(error => {
            setSiteState({ host: selected, error });
        });
    }, [sessions.sessions]);
    function clearSuccess() {
        setSuccess(false);
    }
    const hosts = {
        values: [...sessions.sessions.keys()],
        selected: siteState === null || siteState === void 0 ? void 0 : siteState.host,
        onChange: hostChange
    };
    const vaults = {
        values: siteState === null || siteState === void 0 ? void 0 : siteState.vaults,
        selected: siteState === null || siteState === void 0 ? void 0 : siteState.vault,
        onChange: selected => setSiteState(prevState => (Object.assign(Object.assign({}, prevState), { vault: selected })))
    };
    const templates = {
        values: siteState === null || siteState === void 0 ? void 0 : siteState.templates,
        selected: siteState === null || siteState === void 0 ? void 0 : siteState.template,
        onChange: selected => setSiteState(prevState => (Object.assign(Object.assign({}, prevState), { template: selected })))
    };
    react_1.useEffect(() => {
        if ([...sessions.sessions.keys()].length > 0) {
            hostChange(0);
        }
    }, [sessions.sessions, hostChange]);
    return {
        isInitialized,
        addObjectProps: {
            hosts,
            vaults,
            templates,
            addObject,
        },
        success,
        clearSuccess
    };
};
const AddContainer = () => {
    const addProps = useAdd();
    return react_1.default.createElement(Add_1.Add, Object.assign({}, addProps));
};
exports.default = AddContainer;


/***/ }),

/***/ "./src/containers/Auth.tsx":
/*!*********************************!*\
  !*** ./src/containers/Auth.tsx ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const useSessions_1 = __webpack_require__(/*! ../hooks/storage/useSessions */ "./src/hooks/storage/useSessions.ts");
const useSites_1 = __webpack_require__(/*! ../hooks/storage/useSites */ "./src/hooks/storage/useSites.ts");
const Auth_1 = __webpack_require__(/*! ../components/Auth */ "./src/components/Auth/index.ts");
const StoredSafe_1 = __webpack_require__(/*! ../model/storedsafe/StoredSafe */ "./src/model/storedsafe/StoredSafe.ts");
const usePreferences_1 = __webpack_require__(/*! ../hooks/storage/usePreferences */ "./src/hooks/storage/usePreferences.tsx");
const useAuth = ({ goto }) => {
    const sites = useSites_1.useSites();
    const sessions = useSessions_1.useSessions();
    const preferences = usePreferences_1.usePreferences();
    const isInitialized = sites.isInitialized && sessions.isInitialized;
    const login = async (site, fields) => {
        await StoredSafe_1.actions.login(site, fields);
        // Update preferences after successful login
        await preferences.setLastUsedSite(site.host);
        await preferences.updateSitePreferences(site.host, {
            username: fields.remember ? fields.username : undefined,
            loginType: fields.loginType
        });
    };
    const logout = async (host) => {
        await StoredSafe_1.actions.logout(host);
    };
    return {
        isInitialized,
        sites: sites.all,
        sessions: sessions.sessions,
        login,
        logout,
        goto,
        lastUsedSite: preferences.lastUsedSite,
        sitePreferences: preferences.sites
    };
};
const AuthContainer = (props) => {
    const authProps = useAuth(props);
    return react_1.default.createElement(Auth_1.Auth, Object.assign({}, authProps));
};
exports.default = AuthContainer;


/***/ }),

/***/ "./src/containers/DebugStorage.tsx":
/*!*****************************************!*\
  !*** ./src/containers/DebugStorage.tsx ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(__webpack_require__(/*! react */ "react"));
const DebugStorage_1 = __webpack_require__(/*! ../components/DebugStorage */ "./src/components/DebugStorage/index.ts");
const DebugStorageContainer = () => {
    const [local, setLocal] = react_1.useState(null);
    const [sync, setSync] = react_1.useState(null);
    const [managed, setManaged] = react_1.useState(null);
    react_1.useEffect(() => {
        let mounted = true;
        browser.storage.local
            .get()
            .then(storage => {
            if (mounted)
                setLocal(storage);
        })
            .catch(error => {
            console.error('Local storage unavailable', error);
        });
        browser.storage.sync
            .get()
            .then(storage => {
            if (mounted)
                setSync(storage);
        })
            .catch(error => {
            console.error('Sync storage unavailable', error);
        });
        browser.storage.managed
            .get()
            .then(storage => {
            if (mounted)
                setManaged(storage);
        })
            .catch(error => {
            console.error('Managed storage unavailable', error);
        });
        return () => {
            mounted = false;
        };
    }, []);
    return react_1.default.createElement(DebugStorage_1.DebugStorage, { local: local, sync: sync, managed: managed });
};
exports.default = DebugStorageContainer;


/***/ }),

/***/ "./src/containers/Extension.tsx":
/*!**************************************!*\
  !*** ./src/containers/Extension.tsx ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Entrypoint for the extension UI.
 * Performs routings based on the browser URL.
 * */
const react_1 = __importStar(__webpack_require__(/*! react */ "react"));
const DebugStorage_1 = __importDefault(__webpack_require__(/*! ./DebugStorage */ "./src/containers/DebugStorage.tsx"));
const Popup_1 = __importDefault(__webpack_require__(/*! ./Popup */ "./src/containers/Popup.tsx"));
const Save_1 = __importDefault(__webpack_require__(/*! ./Save */ "./src/containers/Save.tsx"));
var Page;
(function (Page) {
    Page["Popup"] = "popup";
    Page["Debug"] = "debug";
    Page["Save"] = "save";
    Page["Toggle"] = "toggle";
})(Page || (Page = {}));
/**
 * @returns Extension UI.
 * */
const Extension = () => {
    const [page, setPage] = react_1.useState();
    // Once the component is loaded, set the page based on the URL.
    // Defaults to Options page.
    react_1.default.useEffect(() => {
        const path = window.location.href.split('#')[1];
        switch (path) {
            case Page.Popup: {
                setPage(Page.Popup);
                break;
            }
            case Page.Debug: {
                setPage(Page.Debug);
                break;
            }
            case Page.Save: {
                setPage(Page.Save);
                break;
            }
            case Page.Toggle: {
                setPage(Page.Toggle);
                break;
            }
            default: {
                setPage(Page.Popup);
            }
        }
    }, []);
    const toggle = () => {
        browser.runtime.sendMessage({ type: 'toggle' });
    };
    return (react_1.default.createElement("section", { className: 'extension' },
        page === Page.Debug && react_1.default.createElement(DebugStorage_1.default, null),
        page === Page.Popup && react_1.default.createElement(Popup_1.default, null),
        page === Page.Save && react_1.default.createElement(Save_1.default, null),
        page === Page.Toggle && react_1.default.createElement("button", { onClick: toggle }, "Toggle")));
};
exports.default = Extension;


/***/ }),

/***/ "./src/containers/Options.tsx":
/*!************************************!*\
  !*** ./src/containers/Options.tsx ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const Options_1 = __webpack_require__(/*! ../components/Options */ "./src/components/Options/index.ts");
const useSites_1 = __webpack_require__(/*! ../hooks/storage/useSites */ "./src/hooks/storage/useSites.ts");
const useSettings_1 = __webpack_require__(/*! ../hooks/storage/useSettings */ "./src/hooks/storage/useSettings.ts");
const useBlacklist_1 = __webpack_require__(/*! ../hooks/storage/useBlacklist */ "./src/hooks/storage/useBlacklist.ts");
const useOptions = ({ addSite, removeSite }) => {
    const sites = useSites_1.useSites();
    const settings = useSettings_1.useSettings();
    const blacklist = useBlacklist_1.useBlacklist();
    const isInitialized = sites.isInitialized && settings.isInitialized;
    const saveSettings = async (newSettings) => {
        await settings.update(newSettings);
    };
    return {
        isInitialized,
        siteOptionsProps: {
            addSite,
            removeSite,
            systemSites: sites.system,
            userSites: sites.user
        },
        generalOptionsProps: {
            saveSettings,
            settings: settings.settings
        },
        blacklistOptionsProps: {
            removeBlacklistHost: blacklist.remove,
            blacklist: blacklist.blacklist
        }
    };
};
const OptionsContainer = (props) => {
    const optionsProps = useOptions(props);
    return react_1.default.createElement(Options_1.Options, Object.assign({}, optionsProps));
};
exports.default = OptionsContainer;


/***/ }),

/***/ "./src/containers/Popup.tsx":
/*!**********************************!*\
  !*** ./src/containers/Popup.tsx ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Intermediary with the purpose of injecting data from external APIs into the
 * Popup UI.
 */
const react_1 = __importStar(__webpack_require__(/*! react */ "react"));
const useSessions_1 = __webpack_require__(/*! ../hooks/storage/useSessions */ "./src/hooks/storage/useSessions.ts");
const useSites_1 = __webpack_require__(/*! ../hooks/storage/useSites */ "./src/hooks/storage/useSites.ts");
const StoredSafe_1 = __webpack_require__(/*! ../model/storedsafe/StoredSafe */ "./src/model/storedsafe/StoredSafe.ts");
const Auth_1 = __importDefault(__webpack_require__(/*! ./Auth */ "./src/containers/Auth.tsx"));
const Options_1 = __importDefault(__webpack_require__(/*! ./Options */ "./src/containers/Options.tsx"));
const Welcome_1 = __importDefault(__webpack_require__(/*! ./Welcome */ "./src/containers/Welcome.tsx"));
const Add_1 = __importDefault(__webpack_require__(/*! ./Add */ "./src/containers/Add.tsx"));
const Search_1 = __importDefault(__webpack_require__(/*! ./Search */ "./src/containers/Search.tsx"));
const Popup_1 = __webpack_require__(/*! ../components/Popup */ "./src/components/Popup/index.ts");
const layout_1 = __webpack_require__(/*! ../components/common/layout */ "./src/components/common/layout/index.ts");
const useSearch_1 = __webpack_require__(/*! ../hooks/utils/useSearch */ "./src/hooks/utils/useSearch.ts");
var Page;
(function (Page) {
    Page[Page["AUTH"] = 0] = "AUTH";
    Page[Page["OPTIONS"] = 1] = "OPTIONS";
    Page[Page["WELCOME"] = 2] = "WELCOME";
    Page[Page["ADD"] = 3] = "ADD";
    Page[Page["SEARCH"] = 4] = "SEARCH";
})(Page || (Page = {}));
const usePopup = () => {
    const sites = useSites_1.useSites();
    const sessions = useSessions_1.useSessions();
    const [page, setPage] = react_1.useState();
    const _a = useSearch_1.useSearch(), { find } = _a, searchProps = __rest(_a, ["find"]);
    const isConfigured = react_1.useMemo(() => sites.all.length !== 0, [
        sites.isInitialized,
        sites.all
    ]);
    let menuItems = [];
    if (isConfigured) {
        if (sessions.isOnline) {
            menuItems.push({
                title: 'Add',
                icon: layout_1.icons.add,
                onClick: () => setPage(Page.ADD)
            });
        }
        menuItems.push({
            title: sessions.isOnline ? 'Sessions' : 'Login',
            icon: sessions.isOnline ? layout_1.icons.vault_unlocked : layout_1.icons.vault_locked,
            onClick: () => setPage(Page.AUTH)
        });
        menuItems.push({
            title: 'Options',
            icon: layout_1.icons.options,
            onClick: () => setPage(Page.OPTIONS)
        });
    }
    else {
        menuItems = [
            {
                title: 'Setup',
                icon: layout_1.icons.options,
                onClick: () => setPage(Page.WELCOME)
            }
        ];
    }
    /**
     * Open the provided host in a new tab or focus an existing one if one
     * already exists. If a tab exists in the current window or in any other
     * window, that tab and window will be focused.
     * @param host - Host URL to go to.
     */
    const goto = (host) => {
        browser.tabs
            .query({ url: `*://${host}/*` })
            .then(async (tabs) => {
            if (tabs.length === 0) {
                return await browser.tabs.create({ url: `https://${host}/` });
            }
            let selectedTab = tabs[0];
            for (const tab of tabs) {
                if (tab.lastAccessed > selectedTab.lastAccessed) {
                    selectedTab = tab;
                }
            }
            await browser.tabs.update(selectedTab.id, { active: true });
            await browser.windows.update(selectedTab.windowId, { focused: true });
        })
            .catch(error => console.error(error));
    };
    const addSite = async (site) => {
        if (sites.all.reduce((acc, { host }) => acc || site.host === host, false)) {
            throw new Error(`${site.host} already exists.`);
        }
        await sites.add(site);
    };
    const removeSite = async (id) => {
        await sites.remove(id);
    };
    function onFocus() {
        setPage(Page.SEARCH);
    }
    const pages = new Map([
        [Page.AUTH, react_1.default.createElement(Auth_1.default, { key: 'auth', goto: goto })],
        [Page.OPTIONS, react_1.default.createElement(Options_1.default, Object.assign({ key: 'options' }, { addSite, removeSite }))],
        [Page.WELCOME, react_1.default.createElement(Welcome_1.default, Object.assign({ key: 'welcome' }, { addSite, removeSite }))],
        [
            Page.ADD,
            react_1.default.createElement(Add_1.default, { key: 'add' })
        ],
        [Page.SEARCH, react_1.default.createElement(Search_1.default, Object.assign({ key: 'search', goto: goto }, searchProps))]
    ]);
    const isInitialized = react_1.useMemo(() => sessions.isInitialized && sites.isInitialized, [sessions.isInitialized, sites.isInitialized]);
    react_1.useEffect(() => {
        let mounted = true;
        if (isInitialized) {
            if (!isConfigured) {
                if (mounted)
                    setPage(Page.WELCOME);
            }
            else if (!sessions.isOnline) {
                if (mounted)
                    setPage(Page.AUTH);
            }
            else {
                if (mounted)
                    setPage(Page.SEARCH);
            }
        }
        return () => {
            mounted = false;
        };
    }, [isInitialized, sessions.isOnline, isConfigured]);
    react_1.useEffect(() => {
        StoredSafe_1.actions.checkAll().catch(error => {
            console.error(error);
        });
    }, []);
    return {
        isInitialized,
        isOnline: sessions.isOnline,
        menuItems,
        onFocus,
        find,
        page: pages.get(page) !== undefined ? pages.get(page) : null
    };
};
const PopupContainer = () => {
    const popupProps = usePopup();
    return react_1.default.createElement(Popup_1.Popup, Object.assign({}, popupProps));
};
exports.default = PopupContainer;


/***/ }),

/***/ "./src/containers/Save.tsx":
/*!*********************************!*\
  !*** ./src/containers/Save.tsx ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(__webpack_require__(/*! react */ "react"));
const Save_1 = __webpack_require__(/*! ../components/Save/Save */ "./src/components/Save/Save.tsx");
const useBlacklist_1 = __webpack_require__(/*! ../hooks/storage/useBlacklist */ "./src/hooks/storage/useBlacklist.ts");
const useSessions_1 = __webpack_require__(/*! ../hooks/storage/useSessions */ "./src/hooks/storage/useSessions.ts");
const StoredSafe_1 = __webpack_require__(/*! ../model/storedsafe/StoredSafe */ "./src/model/storedsafe/StoredSafe.ts");
const useSave = () => {
    const sessions = useSessions_1.useSessions();
    const blacklist = useBlacklist_1.useBlacklist();
    const [tabValues, setTabValues] = react_1.useState();
    const [success, setSuccess] = react_1.useState(false);
    const [siteState, setSiteState] = react_1.useState();
    const [tabId, setTabId] = react_1.useState();
    const isInitialized = sessions.isInitialized &&
        blacklist.isInitialized &&
        (siteState === null || siteState === void 0 ? void 0 : siteState.vaults) !== undefined &&
        (siteState === null || siteState === void 0 ? void 0 : siteState.templates) !== undefined &&
        tabValues !== undefined;
    function close() {
        browser.tabs.sendMessage(tabId, { type: 'close' });
    }
    const save = async (host, values) => {
        await StoredSafe_1.actions.addObject(host, values);
        setSuccess(true);
        setTimeout(close, 1500);
    };
    const addToBlacklist = async (host) => {
        await blacklist.add(host);
    };
    const hostChange = react_1.useCallback(selected => {
        const host = [...sessions.sessions.keys()][selected];
        setSiteState({ host: selected });
        StoredSafe_1.actions.getSiteInfo(host)
            .then(({ vaults, templates }) => {
            vaults = vaults.filter(({ canWrite }) => canWrite);
            // TODO: Decide if other templates should be allowed.
            templates = templates.filter(({ id }) => id === '20');
            const vault = vaults.length > 0 ? 0 : undefined;
            const loginTemplateId = templates.findIndex(({ id }) => id === '20');
            const template = templates.length > 0
                ? loginTemplateId !== -1
                    ? loginTemplateId
                    : 0
                : undefined;
            setSiteState({ host: selected, vaults, templates, vault, template });
        })
            .catch(error => {
            setSiteState({ host: selected, error });
        });
    }, [sessions.sessions]);
    const hosts = {
        values: [...sessions.sessions.keys()],
        selected: siteState === null || siteState === void 0 ? void 0 : siteState.host,
        onChange: hostChange
    };
    const vaults = {
        values: siteState === null || siteState === void 0 ? void 0 : siteState.vaults,
        selected: siteState === null || siteState === void 0 ? void 0 : siteState.vault,
        onChange: selected => setSiteState(prevState => (Object.assign(Object.assign({}, prevState), { vault: selected })))
    };
    const templates = {
        values: siteState === null || siteState === void 0 ? void 0 : siteState.templates,
        selected: siteState === null || siteState === void 0 ? void 0 : siteState.template,
        onChange: selected => setSiteState(prevState => (Object.assign(Object.assign({}, prevState), { template: selected })))
    };
    react_1.useEffect(() => {
        if ([...sessions.sessions.keys()].length > 0) {
            hostChange(0);
        }
    }, [sessions.sessions, hostChange]);
    browser.runtime.onMessage.addListener((message, sender) => {
        if (message.type === 'save') {
            const { data } = message;
            setTabValues(data);
            setTabId(sender.tab.id);
        }
    });
    return {
        isInitialized,
        tabValues,
        hosts,
        vaults,
        templates,
        save,
        addToBlacklist,
        success,
        close
    };
};
const SaveContainer = () => {
    const SaveProps = useSave();
    return react_1.default.createElement(Save_1.Save, Object.assign({}, SaveProps));
};
exports.default = SaveContainer;


/***/ }),

/***/ "./src/containers/Search.tsx":
/*!***********************************!*\
  !*** ./src/containers/Search.tsx ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const Search_1 = __webpack_require__(/*! ../components/Search/Search */ "./src/components/Search/Search.tsx");
const SearchContainer = (props) => {
    return react_1.default.createElement(Search_1.Search, Object.assign({}, props));
};
exports.default = SearchContainer;


/***/ }),

/***/ "./src/containers/Welcome.tsx":
/*!************************************!*\
  !*** ./src/containers/Welcome.tsx ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(__webpack_require__(/*! react */ "react"));
const Welcome_1 = __webpack_require__(/*! ../components/Popup/layout/Welcome */ "./src/components/Popup/layout/Welcome.tsx");
const useSites_1 = __webpack_require__(/*! ../hooks/storage/useSites */ "./src/hooks/storage/useSites.ts");
const Options_1 = __webpack_require__(/*! ../components/Options */ "./src/components/Options/index.ts");
const useWelcome = ({ addSite, removeSite }) => {
    const sites = useSites_1.useSites();
    const siteOptions = (react_1.default.createElement(Options_1.SiteOptions, { removeSite: removeSite, addSite: addSite, userSites: sites.user, systemSites: sites.system }));
    return {
        isInitialized: sites.isInitialized,
        siteOptions
    };
};
const WelcomeContainer = (props) => {
    const welcomeProps = useWelcome(props);
    return react_1.default.createElement(Welcome_1.Welcome, Object.assign({}, welcomeProps));
};
exports.default = WelcomeContainer;


/***/ }),

/***/ "./src/hooks/storage/useBlacklist.ts":
/*!*******************************************!*\
  !*** ./src/hooks/storage/useBlacklist.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.useBlacklist = void 0;
/**
 * This module creates a hook which can be used in a React Component to
 * interact with the browser storage API. This module encapsulates the external
 * browser storage API so that implementing components can be run without
 * concerning themselves with external dependencies.
 */
const react_1 = __webpack_require__(/*! react */ "react");
const Blacklist_1 = __webpack_require__(/*! ../../model/storage/Blacklist */ "./src/model/storage/Blacklist.ts");
/**
 * Hook to access Blacklist from storage, listing all hosts that should be left
 * out of automatic save suggestions.
 */
exports.useBlacklist = () => {
    // Keep base state in single object to avoid unnecessary
    // renders when updating multiple fields at once.
    const [state, setState] = react_1.useState({
        isInitialized: false,
        blacklist: []
    });
    /**
     * Manually fetch blacklist from storage. This should only be done in situations
     * where you know the hook state is out of sync with the storage area, for
     * example during initialization.
     */
    async function fetch() {
        const blacklist = await Blacklist_1.actions.fetch();
        setState(prevState => (Object.assign(Object.assign({}, prevState), { isInitialized: true, blacklist })));
    }
    /**
     * Add host to storage blacklist.
     * @param host - Host to blacklist.
     */
    async function add(host) {
        await Blacklist_1.actions.add(host);
    }
    /**
     * Remove host from storage blacklist.
     * @param host - Host to remove from blacklist.
     */
    async function remove(host) {
        await Blacklist_1.actions.remove(host);
    }
    /**
     * Clear all blacklist entries from storage.
     */
    async function clear() {
        await Blacklist_1.actions.clear();
    }
    // Run when mounted
    react_1.useEffect(() => {
        /**
         * Listen for changes in storage rather than updating state manually so
         * that external updates can be caught without having double updates when
         * changes come from this hook.
         * @param changes - Changes in storage area.
         * @param area - The storage area where the changes occured.
         */
        const storageListener = (changes, area) => {
            const change = changes.blacklist;
            if ((change === null || change === void 0 ? void 0 : change.newValue) !== undefined && area === 'sync') {
                setState(prevState => (Object.assign(Object.assign({}, prevState), { blacklist: change.newValue })));
            }
        };
        // Initialize state
        fetch().catch(error => console.error(error));
        // Set up listener when the component is mounted.
        browser.storage.onChanged.addListener(storageListener);
        // Remove listener when the component is unmounted.
        return () => {
            browser.storage.onChanged.removeListener(storageListener);
        };
    }, []);
    return Object.assign(Object.assign({}, state), { fetch,
        add,
        remove,
        clear });
};


/***/ }),

/***/ "./src/hooks/storage/usePreferences.tsx":
/*!**********************************************!*\
  !*** ./src/hooks/storage/usePreferences.tsx ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.usePreferences = void 0;
/**
 * This module creates a hook which can be used in a React Component to
 * interact with the browser storage API. This module encapsulates the external
 * browser storage API so that implementing components can be run without
 * concerning themselves with external dependencies.
 */
const react_1 = __webpack_require__(/*! react */ "react");
const Preferences_1 = __webpack_require__(/*! ../../model/storage/Preferences */ "./src/model/storage/Preferences.ts");
/**
 * Hook to access preferences from storage.
 */
exports.usePreferences = () => {
    // Keep base state in single object to avoid unnecessary
    // renders when updating multiple fields at once.
    const [state, setState] = react_1.useState({
        isInitialized: false,
        sites: {}
    });
    /**
     * Manually fetch preferences from storage. This should only be done in situations
     * where you know the hook state is out of sync with the storage area, for
     * example during initialization.
     */
    async function fetch() {
        const preferences = await Preferences_1.actions.fetch();
        setState(prevState => (Object.assign(Object.assign(Object.assign({}, prevState), { isInitialized: true }), preferences)));
    }
    /**
     * Update last used site for login.
     * @param host - Last used site host
     */
    async function setLastUsedSite(host) {
        await Preferences_1.actions.setLastUsedSite(host);
    }
    /**
     * Save username / 2fa preference for user.
     * @param host - Host related to saved preferences
     * @param sitePreferences - New preferences to be saved.
     */
    async function updateSitePreferences(host, sitePreferences) {
        await Preferences_1.actions.updateSitePreferences(host, sitePreferences);
    }
    /**
     * Clear all preferences from storage.
     */
    async function clear() {
        await Preferences_1.actions.clear();
    }
    // Run when mounted
    react_1.useEffect(() => {
        let mounted = true;
        /**
         * Listen for changes in storage rather than updating state manually so
         * that external updates can be caught without having double updates when
         * changes come from this hook.
         * @param changes - Changes in storage area.
         * @param area - The storage area where the changes occured.
         */
        const storageListener = (changes, area) => {
            const change = changes.preferences;
            if (mounted && (change === null || change === void 0 ? void 0 : change.newValue) !== undefined && area === 'local') {
                setState(prevState => (Object.assign(Object.assign({}, prevState), change.newValue)));
            }
        };
        // Initialize state
        fetch().catch(error => console.error(error));
        // Set up listener when the component is mounted.
        browser.storage.onChanged.addListener(storageListener);
        // Remove listener when the component is unmounted.
        return () => {
            mounted = false;
            browser.storage.onChanged.removeListener(storageListener);
        };
    }, []);
    return Object.assign(Object.assign({}, state), { setLastUsedSite,
        updateSitePreferences,
        fetch,
        clear });
};


/***/ }),

/***/ "./src/hooks/storage/useSessions.ts":
/*!******************************************!*\
  !*** ./src/hooks/storage/useSessions.ts ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.useSessions = void 0;
/**
 * This module creates a hook which can be used in a React Component to
 * interact with the browser storage API. This module encapsulates the external
 * browser storage API so that implementing components can be run without
 * concerning themselves with external dependencies.
 */
const react_1 = __webpack_require__(/*! react */ "react");
const Sessions_1 = __webpack_require__(/*! ../../model/storage/Sessions */ "./src/model/storage/Sessions.ts");
/**
 * Hook to access sessions from storage.
 */
exports.useSessions = () => {
    // Keep base state in single object to avoid unnecessary
    // renders when updating multiple fields at once.
    const [state, setState] = react_1.useState({
        isInitialized: false,
        sessions: new Map()
    });
    /**
     * Manually fetch sessions from storage. This should only be done in situations
     * where you know the hook state is out of sync with the storage area, for
     * example during initialization.
     */
    async function fetch() {
        const sessions = await Sessions_1.actions.fetch();
        setState(prevState => (Object.assign(Object.assign({}, prevState), { isInitialized: true, sessions })));
    }
    /**
     * Add session to storage.
     * @param host - Host related to the session
     * @param session - Session to be added.
     */
    async function add(host, session) {
        await Sessions_1.actions.add(host, session);
    }
    /**
     * Remove session from storage.
     * @param host - Host related to the session
     */
    async function remove(host) {
        await Sessions_1.actions.remove(host);
    }
    /**
     * Clear all sessions from storage.
     */
    async function clear() {
        await Sessions_1.actions.clear();
    }
    // Run when mounted
    react_1.useEffect(() => {
        let mounted = true;
        /**
         * Listen for changes in storage rather than updating state manually so
         * that external updates can be caught without having double updates when
         * changes come from this hook.
         * @param changes - Changes in storage area.
         * @param area - The storage area where the changes occured.
         */
        const storageListener = (changes, area) => {
            const change = changes.sessions;
            if (mounted && (change === null || change === void 0 ? void 0 : change.newValue) !== undefined && area === 'local') {
                setState(prevState => (Object.assign(Object.assign({}, prevState), { sessions: Sessions_1.parse(change.newValue) })));
            }
        };
        // Initialize state
        fetch().catch(error => console.error(error));
        // Set up listener when the component is mounted.
        browser.storage.onChanged.addListener(storageListener);
        // Remove listener when the component is unmounted.
        return () => {
            mounted = false;
            browser.storage.onChanged.removeListener(storageListener);
        };
    }, []);
    const numberOfSessions = [...state.sessions.keys()].length;
    return Object.assign(Object.assign({}, state), { numberOfSessions, isOnline: numberOfSessions !== 0, fetch,
        add,
        remove,
        clear });
};


/***/ }),

/***/ "./src/hooks/storage/useSettings.ts":
/*!******************************************!*\
  !*** ./src/hooks/storage/useSettings.ts ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.useSettings = void 0;
/**
 * This module creates a hook which can be used in a React Component to
 * interact with the browser storage API. This module encapsulates the external
 * browser storage API so that implementing components can be run without
 * concerning themselves with external dependencies.
 */
const react_1 = __webpack_require__(/*! react */ "react");
const Settings_1 = __webpack_require__(/*! ../../model/storage/Settings */ "./src/model/storage/Settings.ts");
/**
 * Hook to access settings from storage.
 */
exports.useSettings = () => {
    // Keep base state in single object to avoid unnecessary
    // renders when updating multiple fields at once.
    const [state, setState] = react_1.useState({
        isInitialized: false,
        settings: new Map()
    });
    /**
     * Manually fetch settings from storage. This should only be done in
     * situations where you know the hook state is out of sync with the
     * storage area, for example during initialization.
     */
    async function fetch() {
        const settings = await Settings_1.actions.fetch();
        setState(prevState => (Object.assign(Object.assign({}, prevState), { isInitialized: true, settings })));
    }
    /**
     * Add session to storage.
     * @param host - Host related to the session
     * @param session - Session to be added.
     */
    async function update(settings) {
        await Settings_1.actions.update(settings);
    }
    /**
     * Clear all user settings from storage, reverting to defaults.
     */
    async function clear() {
        await Settings_1.actions.clear();
    }
    // Run when mounted
    react_1.useEffect(() => {
        /**
         * Listen for changes in storage rather than updating state manually so
         * that external updates can be caught without having double updates when
         * changes come from this hook.
         * @param changes - Changes in storage area.
         * @param area - The storage area where the changes occured.
         */
        const storageListener = (changes, area) => {
            const change = changes.settings;
            if ((change === null || change === void 0 ? void 0 : change.newValue) !== undefined &&
                (area === 'sync' || area === 'managed')) {
                fetch().catch(error => console.error(error));
            }
        };
        // Initialize state
        fetch().catch(error => console.error(error));
        // Set up listener when the component is mounted.
        browser.storage.onChanged.addListener(storageListener);
        // Remove listener when the component is unmounted.
        return () => {
            browser.storage.onChanged.removeListener(storageListener);
        };
    }, []);
    return Object.assign(Object.assign({}, state), { fetch,
        update,
        clear });
};


/***/ }),

/***/ "./src/hooks/storage/useSites.ts":
/*!***************************************!*\
  !*** ./src/hooks/storage/useSites.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.useSites = void 0;
/**
 * This module creates a hook which can be used in a React Component to
 * interact with the browser storage API. This module encapsulates the external
 * browser storage API so that implementing components can be run without
 * concerning themselves with external dependencies.
 */
const react_1 = __webpack_require__(/*! react */ "react");
const Sites_1 = __webpack_require__(/*! ../../model/storage/Sites */ "./src/model/storage/Sites.ts");
const Preferences_1 = __webpack_require__(/*! ../../model/storage/Preferences */ "./src/model/storage/Preferences.ts");
const Sessions_1 = __webpack_require__(/*! ../../model/storage/Sessions */ "./src/model/storage/Sessions.ts");
const StoredSafe_1 = __webpack_require__(/*! ../../model/storedsafe/StoredSafe */ "./src/model/storedsafe/StoredSafe.ts");
/**
 * Hook to access sites from storage.
 */
exports.useSites = () => {
    // Keep base state in single object to avoid unnecessary
    // renders when updating multiple fields at once.
    const [state, setState] = react_1.useState({
        isInitialized: false,
        system: [],
        user: []
    });
    /**
     * Manually fetch sites from storage. This should only be done in situations
     * where you know the hook state is out of sync with the storage area, for
     * example during initialization.
     */
    async function fetch() {
        const sites = await Sites_1.actions.fetch();
        setState(prevState => (Object.assign(Object.assign({}, prevState), { isInitialized: true, system: sites.collections.system, user: sites.collections.user })));
    }
    /**
     * Add site to storage.
     * @param site - Site to be added.
     */
    async function add(site) {
        await Sites_1.actions.add(site);
    }
    /**
     * Remove site from storage.
     * @param id - Id in user sites list.
     */
    async function remove(id) {
        var _a;
        const host = (_a = state.user[id]) === null || _a === void 0 ? void 0 : _a.host;
        const preferences = await Preferences_1.actions.fetch();
        if (preferences.lastUsedSite === host) {
            await Preferences_1.actions.setLastUsedSite(undefined);
        }
        const sessions = await Sessions_1.actions.fetch();
        if (sessions.get(host) !== undefined) {
            await StoredSafe_1.actions.logout(host);
        }
        await Sites_1.actions.remove(id);
    }
    // Run when mounted
    react_1.useEffect(() => {
        let mounted = true;
        /**
         * Listen for changes in storage rather than updating state manually so
         * that external updates can be caught without having double updates when
         * changes come from this hook.
         * @param changes - Changes in storage area.
         * @param area - The storage area where the changes occured.
         */
        const storageListener = (changes, area) => {
            const change = changes.sites;
            if ((change === null || change === void 0 ? void 0 : change.newValue) !== undefined) {
                if (mounted && area === 'managed') {
                    setState(prevState => (Object.assign(Object.assign({}, prevState), { system: change.newValue })));
                }
                else if (mounted && area === 'sync') {
                    setState(prevState => (Object.assign(Object.assign({}, prevState), { user: change.newValue })));
                }
            }
        };
        // Initialize state
        fetch().catch(error => console.error(error));
        // Set up listener when the component is mounted.
        browser.storage.onChanged.addListener(storageListener);
        // Remove listener when the component is unmounted.
        return () => {
            mounted = false;
            browser.storage.onChanged.removeListener(storageListener);
        };
    }, []);
    return Object.assign(Object.assign({}, state), { all: [...state.system, ...state.user], fetch,
        add,
        remove });
};


/***/ }),

/***/ "./src/hooks/storage/useTabResults.tsx":
/*!*********************************************!*\
  !*** ./src/hooks/storage/useTabResults.tsx ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.useTabResults = void 0;
/**
 * This module creates a hook which can be used in a React Component to
 * interact with the browser storage API. This module encapsulates the external
 * browser storage API so that implementing components can be run without
 * concerning themselves with external dependencies.
 */
const react_1 = __webpack_require__(/*! react */ "react");
const TabResults_1 = __webpack_require__(/*! ../../model/storage/TabResults */ "./src/model/storage/TabResults.ts");
/**
 * Hook to access tab results from storage.
 */
exports.useTabResults = () => {
    // Keep base state in single object to avoid unnecessary
    // renders when updating multiple fields at once.
    const [state, setState] = react_1.useState({
        isInitialized: false,
        tabResults: new Map()
    });
    /**
     * Manually fetch tab results from storage. This should only be done in
     * situations where you know the hook state is out of sync with the storage
     * area, for example during initialization.
     */
    async function fetch() {
        const tabResults = await TabResults_1.actions.fetch();
        setState(prevState => (Object.assign(Object.assign({}, prevState), { isInitialized: true, tabResults })));
    }
    /**
     * Clear all tab results from storage.
     */
    async function clear() {
        await TabResults_1.actions.clear();
    }
    // Run when mounted
    react_1.useEffect(() => {
        /**
         * Listen for changes in storage rather than updating state manually so
         * that external updates can be caught without having double updates when
         * changes come from this hook.
         * @param changes - Changes in storage area.
         * @param area - The storage area where the changes occured.
         */
        const storageListener = (changes, area) => {
            const change = changes.tabResults;
            if ((change === null || change === void 0 ? void 0 : change.newValue) !== undefined && area === 'local') {
                setState(prevState => (Object.assign(Object.assign({}, prevState), { tabResults: TabResults_1.parse(change.newValue) })));
            }
        };
        // Initialize state
        fetch().catch(error => console.error(error));
        // Set up listener when the component is mounted.
        browser.storage.onChanged.addListener(storageListener);
        // Remove listener when the component is unmounted.
        return () => {
            browser.storage.onChanged.removeListener(storageListener);
        };
    }, []);
    return Object.assign(Object.assign({}, state), { fetch,
        clear });
};


/***/ }),

/***/ "./src/hooks/utils/useForm.ts":
/*!************************************!*\
  !*** ./src/hooks/utils/useForm.ts ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.useForm = void 0;
const react_1 = __webpack_require__(/*! react */ "react");
/**
 * Handle form state and input events.
 * @param {initialValues} Initial state of the form.
 * */
exports.useForm = (initialValues, events) => {
    const [values, setValues] = react_1.useState(initialValues);
    const parseElement = (element) => {
        // Select Element
        if (element instanceof HTMLSelectElement) {
            // Select Multiple
            if (element.multiple) {
                const values = [];
                const options = element.children;
                for (let i = 0; i < options.length; i++) {
                    const option = options.item(i);
                    if (option instanceof HTMLOptionElement) {
                        const { value, selected } = option;
                        if (selected) {
                            values.push(value);
                        }
                    }
                }
                return [values, element.name];
            }
            // Select Single
            return [element.value, element.name];
        }
        // Textarea Element
        if (element instanceof HTMLTextAreaElement) {
            return [element.value, element.name];
        }
        // Input Element
        if (element instanceof HTMLInputElement) {
            // Input Checkbox
            if (element.type === 'checkbox') {
                return [element.checked, element.name];
            }
            // Input Number
            if (element.type === 'number' || element.type === 'range') {
                if (!isNaN(element.valueAsNumber)) {
                    return [element.valueAsNumber, element.name];
                }
            }
            // Other Inputs
            return [element.value, element.name];
        }
    };
    /**
     * Update form state when an input changes, call onChange callback.
     * */
    const onChange = ({ target }) => {
        var _a;
        const [value, name] = parseElement(target);
        setValues(Object.assign(Object.assign({}, values), { [name]: value }));
        (_a = events === null || events === void 0 ? void 0 : events.onChange) === null || _a === void 0 ? void 0 : _a.call(events, value, name);
    };
    /**
     * Call onBlur callback on focus out.
     * */
    const onBlur = ({ target }) => {
        var _a;
        const [value, name] = parseElement(target);
        (_a = events === null || events === void 0 ? void 0 : events.onBlur) === null || _a === void 0 ? void 0 : _a.call(events, value, name);
    };
    /**
     * Call onFocus callback on focus in.
     * */
    const onFocus = ({ target }) => {
        var _a;
        const [value, name] = parseElement(target);
        (_a = events === null || events === void 0 ? void 0 : events.onFocus) === null || _a === void 0 ? void 0 : _a.call(events, value, name);
    };
    /**
     * Reset form with initial values or provided values.
     * */
    const reset = (values = initialValues) => {
        setValues(values);
    };
    return [values, { onChange, onBlur, onFocus }, reset];
};


/***/ }),

/***/ "./src/hooks/utils/useLoading.ts":
/*!***************************************!*\
  !*** ./src/hooks/utils/useLoading.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.useLoading = void 0;
/**
 * Handle the loading state of a promise and potential errors that arise.
 * Will return the promise and data if any when the promise resolves, however
 * it is preferred to start the chain before sending the promise to the
 * loading hook as it makes the code easier to manage.
 *
 * Example:
 * const [name, setName] = useState<string>()
 * const [state, setPromise, reset] = useLoading<string>()
 * setPromise(api.getName().then(setName))
 *
 * if (state.isLoading) return <p>Loading...</p>
 * if (state.error !== undefined) return <p>Error: {state.error.message}</p>
 * return <p>Hello, {name}</p>
 */
const react_1 = __webpack_require__(/*! react */ "react");
exports.useLoading = () => {
    const [state, setState] = react_1.useState({ isLoading: false });
    react_1.useEffect(() => {
        let mounted = true;
        if (state.promise !== undefined) {
            state.promise
                .then((data) => {
                if (mounted) {
                    setState(prevState => ({
                        key: prevState.key,
                        isLoading: false,
                        data
                    }));
                }
            })
                .catch(error => {
                if (mounted) {
                    setState(prevState => ({
                        key: prevState.key,
                        isLoading: false,
                        error
                    }));
                }
            });
        }
        return () => {
            mounted = false;
        };
    }, [state.promise]);
    function setPromise(promise, key) {
        setState({
            isLoading: true,
            promise: promise,
            key
        });
    }
    function reset() {
        setState({ isLoading: false });
    }
    return [state, setPromise, reset];
};


/***/ }),

/***/ "./src/hooks/utils/useSearch.ts":
/*!**************************************!*\
  !*** ./src/hooks/utils/useSearch.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.useSearch = void 0;
const useSessions_1 = __webpack_require__(/*! ../storage/useSessions */ "./src/hooks/storage/useSessions.ts");
const react_1 = __webpack_require__(/*! react */ "react");
const StoredSafe_1 = __webpack_require__(/*! ../../model/storedsafe/StoredSafe */ "./src/model/storedsafe/StoredSafe.ts");
const useTabResults_1 = __webpack_require__(/*! ../storage/useTabResults */ "./src/hooks/storage/useTabResults.tsx");
exports.useSearch = () => {
    const sessions = useSessions_1.useSessions();
    const tabResults = useTabResults_1.useTabResults();
    const [state, setState] = react_1.useState();
    const isInitialized = sessions.isInitialized && tabResults.isInitialized;
    async function getTabResults() {
        const [{ id }] = await browser.tabs.query({
            currentWindow: true,
            active: true
        });
        return tabResults.tabResults.get(id);
    }
    async function find(needle) {
        if (needle === '') {
            const results = await getTabResults();
            setState({ results, errors: new Map() });
            return;
        }
        const promises = [];
        const results = new Map();
        const errors = new Map();
        for (const host of sessions.sessions.keys()) {
            promises.push(StoredSafe_1.actions.find(host, needle)
                .then(ssObjects => {
                results.set(host, ssObjects);
            })
                .catch(error => {
                errors.set(host, error);
            }));
        }
        await Promise.all(promises);
        setState({ results, errors });
    }
    async function decrypt(host, objectId) {
        return await StoredSafe_1.actions.decrypt(host, objectId);
    }
    async function fill(host, id) {
        async function sendFill(result) {
            const [tab] = await browser.tabs.query({
                currentWindow: true,
                active: true
            });
            const data = result.fields.map(({ name, value }) => [name, value]);
            await browser.tabs.sendMessage(tab.id, { type: 'fill', data });
            window.close();
        }
        const ssObject = state.results.get(host)[id];
        if (ssObject.isDecrypted) {
            await sendFill(ssObject);
        }
        else {
            await sendFill(await decrypt(host, ssObject.id));
        }
    }
    async function show(host, id, fieldId, show = true) {
        let result = state.results.get(host)[id];
        if (!result.isDecrypted && result.fields[fieldId].isEncrypted) {
            result = await decrypt(host, result.id);
        }
        setState(prevState => {
            const prevResults = prevState.results.get(host);
            for (let i = 0; i < prevResults[id].fields.length; i++) {
                if (i === fieldId) {
                    result.fields[i].isShowing = show;
                }
                else {
                    result.fields[i].isShowing = prevResults[id].fields[i].isShowing;
                }
            }
            const newResults = [...prevResults];
            newResults[id] = result;
            return Object.assign(Object.assign({}, prevState), { results: new Map([...prevState.results, [host, newResults]]) });
        });
    }
    async function copy(host, id, fieldId) {
        let result = state.results.get(host)[id];
        if (!result.isDecrypted && result.fields[fieldId].isEncrypted) {
            result = await decrypt(host, result.id);
        }
        await navigator.clipboard.writeText(result.fields[fieldId].value);
    }
    react_1.useEffect(() => {
        if (state === undefined) {
            getTabResults().then(results => {
                setState({ results, errors: new Map() });
            });
        }
    }, [state, isInitialized]);
    return {
        isInitialized: isInitialized && state !== undefined,
        results: state === null || state === void 0 ? void 0 : state.results,
        errors: state === null || state === void 0 ? void 0 : state.errors,
        find,
        fill,
        copy,
        show
    };
};


/***/ }),

/***/ "./src/index.scss":
/*!************************!*\
  !*** ./src/index.scss ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js!../node_modules/postcss-loader/src!../node_modules/sass-loader/dist/cjs.js!./index.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./src/index.scss");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/index.tsx":
/*!***********************!*\
  !*** ./src/index.tsx ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Entrypoint for React, mounts React application in DOM.
 * Sets up development tools that run on UI pages.
 * */
const React = __importStar(__webpack_require__(/*! react */ "react"));
const ReactDOM = __importStar(__webpack_require__(/*! react-dom */ "react-dom"));
__webpack_require__(/*! ./index.scss */ "./src/index.scss");
const Extension_1 = __importDefault(__webpack_require__(/*! ./containers/Extension */ "./src/containers/Extension.tsx"));
/**
 * Render extension UI onto page.
 * */
ReactDOM.render(React.createElement(Extension_1.default, null), document.getElementById('app'));


/***/ }),

/***/ "./src/model/storage/Blacklist.ts":
/*!****************************************!*\
  !*** ./src/model/storage/Blacklist.ts ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting sites where
 * the extension should not offer to save login information.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
const userStorage = browser.storage.sync;
/**
 * Get blacklisted sites from user storage.
 * @returns List of blacklisted sites.
 * */
async function get() {
    const { blacklist } = await userStorage.get('blacklist');
    return blacklist === undefined ? [] : blacklist;
}
/**
 * Commit new blacklist to user storage.
 * @param blacklist - New blacklist.
 * */
async function set(blacklist) {
    return await userStorage.set({ blacklist });
}
/// /////////////////////////////////////////////////////////
// Actions
/**
 * Add new host to blacklist.
 * @param host - New blacklist entry.
 * @returns New blacklist.
 * */
async function add(host) {
    const blacklist = await get();
    if (blacklist.includes(host)) {
        return blacklist;
    }
    const newBlacklist = [...blacklist];
    newBlacklist.push(host);
    return await set(newBlacklist).then(get);
}
/**
 * Remove host from blacklist.
 * @param host - Host to remove.
 * @returns New blacklist.
 * */
async function remove(host) {
    const blacklist = await get();
    const newBlacklist = blacklist.filter(listedHost => listedHost !== host);
    return await set(newBlacklist).then(get);
}
/**
 * Clear blacklist.
 * @returns Updated blacklist (empty).
 * */
async function clear() {
    return await set([]).then(get);
}
exports.actions = {
    add,
    remove,
    clear,
    fetch: get
};


/***/ }),

/***/ "./src/model/storage/Preferences.ts":
/*!******************************************!*\
  !*** ./src/model/storage/Preferences.ts ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting user
 * preferences based on how the user interacts with the extension.
 * Examples of this is when the user decides to save a username or remembering
 * which site the user logged into last.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * @returns Promise containing the user preferences.
 * */
async function get() {
    const { preferences } = await browser.storage.local.get('preferences');
    return preferences === undefined ? { sites: {} } : preferences;
}
/**
 * Commit user preferences to local storage.
 * @param preferences - New user preferences.
 * */
async function set(preferences) {
    return await browser.storage.local.set({ preferences });
}
/// /////////////////////////////////////////////////////////
// Actions
/**
 * Set the last used site.
 * @param host - The last used site host.
 * @returns New user preferences.
 * */
async function setLastUsedSite(host) {
    const preferences = await get();
    return await set(Object.assign(Object.assign({}, preferences), { lastUsedSite: host })).then(get);
}
/**
 * Update user preferences for the given host.
 * Will create an entry for the host if one doesn't exist.
 * @param host - The host associated with the preferences.
 * @param sitePreferences - New user preferences for the specified host.
 * @returns New user preferences.
 * */
async function updateSitePreferences(host, sitePreferences) {
    const preferences = await get();
    const newSitePreferences = Object.assign(Object.assign({}, preferences), { sites: Object.assign(Object.assign({}, preferences.sites), { [host]: sitePreferences }) });
    return await set(newSitePreferences).then(get);
}
/**
 * Clear user preferences.
 * @returns New user preferences.
 * */
async function clear() {
    return await set({ sites: {} }).then(get);
}
exports.actions = {
    setLastUsedSite,
    updateSitePreferences,
    clear,
    fetch: get
};


/***/ }),

/***/ "./src/model/storage/Sessions.ts":
/*!***************************************!*\
  !*** ./src/model/storage/Sessions.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting StoredSafe
 * sessions as a means of indicating whether a user is logged into a site or
 * not. The extension background script is expected to set/clear this storage
 * area as a user performs a login/logout action or when a session times out.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = exports.parse = void 0;
/**
 * Parse serialized sessions from storage.
 * @param sessions - Serializable sessions from storage
 */
function parse(sessions) {
    return new Map(sessions === undefined ? [] : sessions);
}
exports.parse = parse;
/**
 * Get sessions from local storage.
 * @returns Promise containing all currently active sessions.
 * */
async function get() {
    const { sessions } = await browser.storage.local.get('sessions');
    return parse(sessions);
}
/**
 * Commit Sessions object to sync storage.
 * @param sessions - All currently active sessions.
 * @returns Empty promise.
 * */
async function set(sessions) {
    return await browser.storage.local.set({
        sessions: [...sessions]
    });
}
/// /////////////////////////////////////////////////////////
// Actions
/**
 * Add new session to storage.
 * @param host - Host that the session is associated with.
 * @param session - New session data.
 * @returns Updated active sessions.
 * */
async function add(host, session) {
    const sessions = await get();
    const newSessions = new Map([...sessions, [host, session]]);
    return await set(newSessions).then(get);
}
/**
 * Remove sessions from storage.
 * @param hosts - Hosts that the sessions are associated with.
 * @returns Updated active sessions.
 * */
async function remove(...hosts) {
    const sessions = await get();
    const newSessions = new Map(sessions);
    for (const host of hosts) {
        newSessions.delete(host);
    }
    return await set(newSessions).then(get);
}
/**
 * Clear all sessions.
 * @returns Updated active sessions (empty).
 * */
async function clear() {
    return await set(new Map([])).then(get);
}
exports.actions = {
    add,
    remove,
    clear,
    fetch: get
};


/***/ }),

/***/ "./src/model/storage/Settings.ts":
/*!***************************************!*\
  !*** ./src/model/storage/Settings.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting options set
 * by the user or by the system administrator. User settings are persisted in
 * sync storage which syncs with your browser account if you're logged in.
 * Administrators can add custom default or enforced values using a managed
 * storage manifest which is loaded by this module.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 *
 * Sync storage and managed storage as well as application defaults are merged
 * in this module per field using the following priority:
 * 1. Managed enforced
 * 2. Sync
 * 3. Managed defaults
 * 4. Application defaults
 *
 * When updating settings, all managed fields are silently ignored. The module
 * will however not prevent the setting of fields in sync storage that also exist
 * in managed enforced storage because when fetching settings, any such overlapping
 * fields will simply be ignored in favor of higher priority settings.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = exports.merge = exports.defaults = void 0;
const systemStorage = browser.storage.managed;
const userStorage = browser.storage.sync;
/**
 * Default values for settings.
 * @param idleMax - Number of minutes a user can be idle before being logged out.
 * @param autoFill - Whether or not to automatically fill forms when possible.
 * @param maxTokenLife - Number of hours a session is allowed to be maintained.
 * */
exports.defaults = {
    idleMax: 15,
    autoFill: false,
    maxTokenLife: 8
};
/**
 * Merge one or more unparsed settings objects into a single Settings object.
 * @param settingsObjects - Settings objects in descending order of priority.
 */
function merge(...settingsObjects) {
    const settings = new Map();
    for (const [settingsObject, managed] of settingsObjects) {
        if (settingsObject !== undefined) {
            populate(settings, settingsObject, managed);
        }
    }
    return settings;
}
exports.merge = merge;
/**
 * Populates given Settings object in-place.
 * @param settings - Existing settings to merge with.
 * @param values - Values to populate settings with.
 * @param managed - Whether or not the values are managed.
 * */
const populate = (settings, values, managed = false) => {
    Object.keys(values).forEach(key => {
        if (!settings.has(key)) {
            settings.set(key, { managed, value: values[key] });
        }
    });
};
/**
 * Get settings from managed and sync storage and convert
 * into Settings object where enforced values from managed
 * storage are set as managed.
 * @returns Merged user and system settings.
 * */
async function get() {
    var _a;
    let systemSettings = {};
    try {
        const { settings } = await systemStorage.get('settings');
        systemSettings = settings === undefined ? {} : settings;
    }
    catch (error) {
        if ((_a = error.message) === null || _a === void 0 ? void 0 : _a.includes('storage manifest')) {
            console.warn('No managed storage manifest found.');
        }
        else {
            throw error;
        }
    }
    const { settings: userSettings } = await userStorage.get('settings');
    return merge([systemSettings === null || systemSettings === void 0 ? void 0 : systemSettings.enforced, true], [userSettings, false], [systemSettings === null || systemSettings === void 0 ? void 0 : systemSettings.defaults, false], [exports.defaults, false]);
}
/**
 * Commit user settings to sync storage.
 * @param settings - New user settings.
 * */
async function set(settings) {
    const userSettings = {};
    for (const [key, field] of settings) {
        if (!field.managed) {
            userSettings[key] = field.value;
        }
    }
    return await userStorage.set({ settings: userSettings });
}
/**
 * Update user settings. Managed fields will be ignored.
 * @param settings - Updated settings.
 * @returns New merged user and system settings.
 * */
async function update(updatedSettings) {
    const settings = await get();
    const newSettings = new Map([...settings, ...updatedSettings]);
    return await set(newSettings).then(get);
}
async function clear() {
    return await set(new Map()).then(get);
}
exports.actions = {
    update,
    clear,
    fetch: get
};


/***/ }),

/***/ "./src/model/storage/Sites.ts":
/*!************************************!*\
  !*** ./src/model/storage/Sites.ts ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting StoredSafe
 * sites available to the user. The preferred way of adding sites is by a
 * managed storage manifest administered by the system administrator. If the
 * user has access to sites outside of the organization or is using a private
 * computer, sites can be added manually by the user and commited to sync
 * storage instead.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
const systemStorage = browser.storage.managed;
const userStorage = browser.storage.sync;
/**
 * Helper function to merge system and user sites into a single list.
 * @param siteCollections - Collection of system and user sites.
 * @returns List of all sites available to the user.
 * */
function sitesFromCollections(siteCollections) {
    return {
        list: siteCollections.system.concat(siteCollections.user),
        collections: siteCollections
    };
}
/**
 * Get sites from system and user storage.
 * @returns Collection of system and user sites.
 * */
async function get() {
    var _a;
    // Set up promises to run parallell
    const userPromise = userStorage.get('sites');
    const systemPromise = systemStorage.get('sites');
    const { sites: userSites } = await userPromise;
    const user = userSites === undefined ? [] : userSites;
    let system;
    try {
        const { sites: systemSites } = await systemPromise;
        system = systemSites === undefined ? [] : systemSites;
    }
    catch (error) {
        if ((_a = error.message) === null || _a === void 0 ? void 0 : _a.includes('storage manifest')) {
            console.warn('No managed storage manifest found.');
        }
        else {
            throw error;
        }
        system = [];
    }
    return { system, user };
}
/**
 * Commit Sites object to user storage (managed sites are ignored).
 * @param siteCollections - New user sites.
 * */
async function set(siteCollections) {
    return await userStorage.set({ sites: siteCollections.user });
}
/// /////////////////////////////////////////////////////////
// Actions
/**
 * Add site to storage.
 * @param site - New site.
 * @returns New user and system sites.
 * */
async function add(site) {
    const sites = await get();
    const newSites = {
        system: sites.system,
        user: [...sites.user, site]
    };
    return await set(newSites).then(async () => await get().then(() => sitesFromCollections(newSites)));
}
/**
 * Remove site from storage.
 * @param id - Index in user sites array.
 * @returns New user and system sites.
 * */
async function remove(id) {
    const sites = await get();
    const newSites = {
        system: sites.system,
        user: sites.user.filter((site, siteId) => siteId !== id)
    };
    return await set(newSites).then(async () => await get().then(sites => sitesFromCollections(sites)));
}
/**
 * Fetch sites from storage.
 * @returns User and system sites.
 * */
async function fetch() {
    return await get().then(sites => sitesFromCollections(sites));
}
exports.actions = {
    add,
    remove,
    fetch
};


/***/ }),

/***/ "./src/model/storage/TabResults.ts":
/*!*****************************************!*\
  !*** ./src/model/storage/TabResults.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for browser storage API to handle persisting search
 * results related to a browser tab as a means of caching. The extension
 * background script is expected to set/clear this storage area as needed
 * to implement the actual caching.
 * - get/set functions handle all storage interaction.
 * - actions object provides the public interface for the model.
 * */
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = exports.parse = void 0;
/**
 * Parse serializable tab results into mapped results.
 * @param serializableTabResults - Unparsed tab results from storage
 */
function parse(serializableTabResults) {
    if (serializableTabResults === undefined) {
        return new Map();
    }
    return new Map(serializableTabResults.map(([k, v]) => [k, new Map(v)]));
}
exports.parse = parse;
/**
 * Get tab search results from local storage.
 * @returns Promise containing tab search results.
 * */
async function get() {
    const { tabResults } = await browser.storage.local.get('tabResults');
    return parse(tabResults);
}
/**
 * Commit tab search results to local storage.
 * @param tabResults New tab search results.
 * */
async function set(tabResults) {
    try {
        return await browser.storage.local.set({
            // Convert nested Map objects to serializable results.
            tabResults: [...tabResults].map(([k, v]) => [k, [...v]])
        });
    }
    catch (error) {
        console.error('Error setting tabResults in storage.', error);
    }
}
/// /////////////////////////////////////////////////////////
// Actions
/**
 * Set search results for tab.
 * @param tabId - ID of tab associated with the results.
 * @param results - Results from active sites related to the tab.
 * @returns Updated cached results from all tabs.
 * */
async function setTabResults(tabId, results) {
    const prevTabResults = await get();
    const newTabResults = new Map([...prevTabResults, [tabId, results]]);
    return await set(newTabResults).then(get);
}
/**
 * Remove search results for tab.
 * @param tabId - ID of tab associated with the results.
 * @returns Updated cached results from all tabs.
 * */
async function removeTabResults(tabId) {
    const prevResults = await get();
    const newResults = new Map(prevResults);
    newResults.delete(tabId);
    return await set(newResults).then(get);
}
/**
 * Purge host from tab results.
 * @returns Updated cached results from all tabs, with values from host removed.
 * */
async function purgeHost(host) {
    const prevTabResults = await get();
    const newTabResults = new Map(prevTabResults);
    for (const results of newTabResults.values()) {
        for (const resultsHost of results.keys()) {
            if (resultsHost === host) {
                results.delete(host);
            }
        }
    }
    return await set(newTabResults).then(get);
}
/**
 * Clear all search results from storage.
 * @returns Updated cached results from all tabs (empty).
 * */
async function clear() {
    return await set(new Map()).then(get);
}
/**
 * Fetch all cached tab search results from storage.
 * @returns Cached results from all tabs.
 * */
exports.actions = {
    setTabResults,
    removeTabResults,
    purgeHost,
    clear,
    fetch: get
};


/***/ }),

/***/ "./src/model/storedsafe/AuthHandler.ts":
/*!*********************************************!*\
  !*** ./src/model/storedsafe/AuthHandler.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * Login to StoredSafe.
 * @param request - Request callback function.
 * @param fields - Credentials and specification of login type.
 * @returns Session created from response if successful.
 * */
async function login(request, fields) {
    const data = (await request(async (handler) => {
        let promise;
        if (fields.loginType === 'yubikey') {
            const { username, keys } = fields;
            const passphrase = keys.slice(0, -44);
            const otp = keys.slice(-44);
            promise = handler.loginYubikey(username, passphrase, otp);
        }
        else {
            // if (fields.loginType === 'totp') {
            const { username, passphrase, otp } = fields;
            promise = handler.loginTotp(username, passphrase, otp);
        }
        return await promise;
    }));
    const { token, audit, timeout } = data.CALLINFO;
    const violations = Array.isArray(audit.violations) ? {} : audit.violations;
    const warnings = Array.isArray(audit.warnings) ? {} : audit.warnings;
    return {
        token,
        createdAt: Date.now(),
        violations,
        warnings,
        timeout
    };
}
/**
 * Logout from StoredSafe
 * @param request - Request callback function.
 * @param host - Host related to the session to invalidate.
 * */
async function logout(request) {
    await request(async (handler) => await handler.logout());
}
/**
 * Check if token is still valid and refresh the token if it is.
 * @param request - Request callback function.
 * @returns True if token is still valid, otherwise false.
 * */
async function check(request) {
    try {
        await request(async (handler) => await handler.check());
        return true;
    }
    catch (error) {
        if (error.message.match('StoredSafe') !== null) {
            return false;
        }
        throw error;
    }
}
exports.actions = {
    login,
    logout,
    check
};


/***/ }),

/***/ "./src/model/storedsafe/MiscHandler.ts":
/*!*********************************************!*\
  !*** ./src/model/storedsafe/MiscHandler.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * Get the available vaults from the given site.
 * @param request - Request callback function.
 * @returns All available StoredSafe vaults on the host.
 * */
async function getVaults(request) {
    var _a, _b;
    let data;
    try {
        data = (await request(async (handler) => await handler.listVaults()));
    }
    catch (error) {
        // NOTE: If vault list is empty, StoredSafe sends 404
        if (((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) !== undefined) {
            data = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data;
        }
        else {
            throw error;
        }
    }
    return data.VAULTS.map(vault => ({
        id: vault.id,
        name: vault.groupname,
        canWrite: ['2', '4'].includes(vault.status) // Write or Admin
    }));
}
/**
 * Get the available templates from the given site.
 * @param request - Request callback function.
 * @returns All available StoredSafe templates on the host.
 * */
async function getTemplates(request) {
    const data = (await request(async (handler) => await handler.listTemplates()));
    const templates = [];
    for (const template of data.TEMPLATE) {
        if (template.INFO.file !== undefined)
            continue;
        templates.push({
            id: template.INFO.id,
            name: template.INFO.name,
            icon: template.INFO.ico,
            structure: Object.keys(template.STRUCTURE).map(fieldName => {
                const field = template.STRUCTURE[fieldName];
                return {
                    title: field.translation,
                    name: fieldName,
                    type: field.type,
                    isEncrypted: field.encrypted
                };
            })
        });
    }
    return templates;
}
/**
 * Generate a new password.
 * @param request - Request callback function.
 * @param params - Optional parameters for password generation.
 * @returns Generated password.
 * */
async function generatePassword(request, params) {
    const data = (await request(async (handler) => await handler.generatePassword(params)));
    return data.CALLINFO.passphrase;
}
exports.actions = {
    getVaults,
    getTemplates,
    generatePassword
};


/***/ }),

/***/ "./src/model/storedsafe/ObjectHandler.ts":
/*!***********************************************!*\
  !*** ./src/model/storedsafe/ObjectHandler.ts ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
/**
 * Helper function to parse objects and templates returned from a find request.
 * @param ssObject StoredSafe object.
 * @param @ssTemplate StoredSafe template.
 * @param isDecrypted Whether the object has just been decrypted.
 * @returns Parsed representation of object and template info.
 * */
const parseSearchResult = (ssObject, ssTemplate, isDecrypted = false) => {
    // Extract general object info
    const name = ssObject.objectname;
    const { id, templateid: templateId, groupid: vaultId } = ssObject;
    const { name: type, ico: icon } = ssTemplate.info;
    const fields = [];
    // Extract field info from template
    ssTemplate.structure.forEach(field => {
        const { fieldname: fieldName, translation: title, encrypted: isEncrypted, policy: isPassword } = field;
        // Value may be undefined if the field is encrypted
        const value = isEncrypted
            ? isDecrypted
                ? ssObject.crypted[field.fieldname]
                : undefined
            : ssObject.public[field.fieldname];
        // Add field to object fields
        fields.push({
            name: fieldName,
            title,
            value,
            isEncrypted,
            isPassword
        });
    });
    // Compile all parsed information
    return { id, templateId, vaultId, name, type, icon, isDecrypted, fields };
};
const includeFields = ['password', 'pincode'];
/**
 * Find and parse StoredSafe objects matching the provided needle.
 * @param request - Request callback function.
 * @param needle - Search string to match against in StoredSafe.
 * @returns Results matching needle.
 * */
async function find(request, needle) {
    const data = (await request(async (handler) => await handler.find(needle)));
    const results = [];
    for (let i = 0; i < data.OBJECT.length; i++) {
        const ssObject = data.OBJECT[i];
        const ssTemplate = data.TEMPLATES.find(template => template.id === ssObject.templateid);
        if (ssTemplate.structure.findIndex(field => includeFields.includes(field.fieldname)) === -1) {
            continue;
        }
        results.push(parseSearchResult(ssObject, ssTemplate));
    }
    return results;
}
/**
 * Decrypt StoredSafe object.
 * @param request - Request callback function.
 * @param objectId - ID in StoredSafe of object to decrypt.
 * @returns The decrypted object.
 * */
async function decrypt(request, objectId) {
    const data = (await request(async (handler) => await handler.decryptObject(objectId)));
    const ssObject = data.OBJECT.find(obj => obj.id === objectId);
    const ssTemplate = data.TEMPLATES.find(template => template.id === ssObject.templateid);
    return parseSearchResult(ssObject, ssTemplate, true);
}
/**
 * Add object to StoredSafe.
 * @param request - Request callback function.
 * @param params - Object parameters based on the chosen StoredSafe template.
 * */
async function add(request, params) {
    await request(async (handler) => await handler.createObject(params));
}
exports.actions = {
    find,
    decrypt,
    add
};


/***/ }),

/***/ "./src/model/storedsafe/StoredSafe.ts":
/*!********************************************!*\
  !*** ./src/model/storedsafe/StoredSafe.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Abstraction layer for the StoredSafe API wrapper to handle writing
 * relevant data to storage and parsing the raw StoredSafe response into
 * the more relevant application data structures.
 * - actions object provides the public interface for the model.
 * */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.actions = void 0;
const storedsafe_1 = __importDefault(__webpack_require__(/*! storedsafe */ "./node_modules/storedsafe/dist/index.js"));
const Sessions_1 = __webpack_require__(/*! ../storage/Sessions */ "./src/model/storage/Sessions.ts");
const TabResults_1 = __webpack_require__(/*! ../storage/TabResults */ "./src/model/storage/TabResults.ts");
const ObjectHandler_1 = __webpack_require__(/*! ./ObjectHandler */ "./src/model/storedsafe/ObjectHandler.ts");
const AuthHandler_1 = __webpack_require__(/*! ./AuthHandler */ "./src/model/storedsafe/AuthHandler.ts");
const MiscHandler_1 = __webpack_require__(/*! ./MiscHandler */ "./src/model/storedsafe/MiscHandler.ts");
/**
 * Helper function to handle errors when interacting with the StoredSafe API.
 * All StoredSafe requests with errors will look similar and therefore be
 * handled the same way.
 * @param promise - Promise returned by StoredSafe request.
 * @returns Data returned by StoredSafe or promise with error.
 * */
async function handleErrors(promise) {
    var _a, _b, _c;
    try {
        const response = await promise;
        return response.data;
    }
    catch (error) {
        if (((_a = error.response) === null || _a === void 0 ? void 0 : _a.data) !== undefined) {
            const data = (_b = error.response) === null || _b === void 0 ? void 0 : _b.data;
            if (((_c = data.ERRORS) === null || _c === void 0 ? void 0 : _c.length) > 0) {
                const errors = data.ERRORS.join(' | ');
                throw new Error(`StoredSafe Error: ${errors}`);
            }
            if (data.ERRORCODES !== undefined && Object.keys(data.ERRORCODES).length > 0) {
                const errors = Object.values(data.ERRORCODES).join(' | ');
                throw new Error(`StoredSafe Error: ${errors}`);
            }
            // Server sent error code but no error response (see 404 for empty vaults)
            throw error;
        }
        else if (error.request !== undefined) {
            const { status, statusText } = error.request;
            console.error('StoredSafe network error: ', error);
            throw new Error(`Network Error: (${status}) ${statusText}`);
        }
        const message = error.message;
        throw new Error(`Unexpected Error: ${message}`);
    }
}
/**
 * Get StoredSafe handler for the given host.
 * @param host - Host to connect to.
 * @returns StoredSafe handler or promise with error if no session was found.
 * */
async function getHandler(host) {
    const sessions = await Sessions_1.actions.fetch();
    if (sessions.get(host) === undefined) {
        throw new Error(`No active session for ${host}`);
    }
    const { token } = sessions.get(host);
    return new storedsafe_1.default({ host, token });
}
/**
 * Create and perform initial handling of request.
 * @param host - Host to create handler callback for.
 * @returns Request function to be passed to sub-handlers.
 * */
function makeRequest(host) {
    return async (cb) => await handleErrors(getHandler(host).then(async (handler) => await cb(handler)));
}
/// /////////////////////////////////////////////////////////
// auth
/**
 * Attempt login with given site.
 * @param site - Site to attempt login with.
 * @param fields - Credentials and specification of login type.
 * @returns Updated list of active sessions (if login is successful).
 * */
async function login({ host, apikey }, fields) {
    const handler = new storedsafe_1.default({ host, apikey });
    const request = async (cb) => await handleErrors(cb(handler));
    const session = await AuthHandler_1.actions.login(request, fields);
    return await Sessions_1.actions.add(host, session);
}
/**
 * Logout from given site.
 * Will silently remove session even if logout fails.
 * @param host - Host related to the session to invalidate.
 * @returns Updated list of active sessions.
 * */
async function logout(host) {
    try {
        await AuthHandler_1.actions.logout(makeRequest(host));
    }
    catch (error) {
        console.error('StoredSafe Logout Error', error);
    }
    return await Sessions_1.actions.remove(host);
}
/**
 * Logout from all sites.
 * Will silently remove sessions even if logout fails.
 * @returns Updated list of active sessions (empty).
 * */
async function logoutAll() {
    const sessions = await Sessions_1.actions.fetch();
    [...sessions.keys()].forEach(host => {
        AuthHandler_1.actions.logout(makeRequest(host)).catch(error => {
            console.error('StoredSafe Logout Error', error);
        });
    });
    return await Sessions_1.actions.clear();
}
/**
 * Check if session is still valid, remove it if it's not.
 * @param host - Host related to the session to validate.
 * @returns Updated list of active sessions.
 * */
async function check(host) {
    const isValid = await AuthHandler_1.actions.check(makeRequest(host));
    return isValid
        ? await Sessions_1.actions.fetch()
        : await Sessions_1.actions.remove(host);
}
/**
 * Check if sessions are still valid, remove those that are not.
 * @returns Updated list of active sessions.
 * */
async function checkAll() {
    const sessions = await Sessions_1.actions.fetch();
    const invalidHosts = [];
    for (const host of sessions.keys()) {
        const isValid = await AuthHandler_1.actions.check(makeRequest(host));
        if (!isValid) {
            invalidHosts.push(host);
        }
    }
    if (invalidHosts.length > 0) {
        return await Sessions_1.actions.remove(...invalidHosts);
    }
    return sessions;
}
/// /////////////////////////////////////////////////////////
// object
/**
 * Find search results from given sites.
 * @param host - Host to perform search on.
 * @param needle - Search string to match against in StoredSafe.
 * @returns Matched results from host.
 * */
async function find(host, needle) {
    return await ObjectHandler_1.actions.find(makeRequest(host), needle);
}
/**
 * Decrypt StoredSafe object.
 * @param host - Host to request decryption from.
 * @param objectId - ID in StoredSafe of object to decrypt.
 * @returns The decrypted object.
 * */
async function decrypt(host, objectId) {
    return await ObjectHandler_1.actions.decrypt(makeRequest(host), objectId);
}
/**
 * Add object to StoredSafe.
 * @param host - Host to add object to.
 * @param params - Object parameters based on the chosen StoredSafe template.
 * */
async function addObject(host, params) {
    return await ObjectHandler_1.actions.add(makeRequest(host), params);
}
/**
 * Find search results related to tab and put in storage
 * from all logged in sites.
 * @param tabId - The ID of the tab associated with the search.
 * @param needle - The search string to match against in StoredSafe.
 * @returns Updated list of all cached tab search results.
 * */
async function tabFind(tabId, needle) {
    const sessions = await Sessions_1.actions.fetch();
    const hosts = [...sessions.keys()];
    const promises = hosts.map(async (host) => {
        try {
            return await find(host, needle);
        }
        catch (error) {
            // Log error rather than failing all results in Promise.all
            console.error(error);
            // Ensure a valid response is returned
            return [];
        }
    });
    const siteResults = await Promise.all(promises);
    const results = new Map();
    for (let i = 0; i < siteResults.length; i++) {
        results.set(hosts[i], siteResults[i]);
    }
    return await TabResults_1.actions.setTabResults(tabId, results);
}
/// /////////////////////////////////////////////////////////
// misc
/**
 * Get info about site structure and capabilities.
 * @param host - Host to retreive info about.
 * @returns - Info regarding the structure of the site.
 * */
async function getSiteInfo(host) {
    const handler = await getHandler(host);
    const request = async (cb) => await handleErrors(cb(handler));
    const vaults = await MiscHandler_1.actions.getVaults(request);
    const templates = await MiscHandler_1.actions.getTemplates(request);
    return { vaults, templates };
}
/**
 * Generate a new password.
 * @param host - Host to request a password from.
 * @param params - Optional parameters for password generation.
 * @returns Generated password.
 * */
async function generatePassword(host, params) {
    return await MiscHandler_1.actions.generatePassword(makeRequest(host), params);
}
exports.actions = {
    login,
    logout,
    logoutAll,
    check,
    checkAll,
    find,
    decrypt,
    tabFind,
    addObject,
    getSiteInfo,
    generatePassword
};


/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = React;

/***/ }),

/***/ "react-dom":
/*!***************************!*\
  !*** external "ReactDOM" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ReactDOM;

/***/ })

/******/ });
//# sourceMappingURL=main.js.map